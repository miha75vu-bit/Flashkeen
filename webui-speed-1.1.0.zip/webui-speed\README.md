# webui-speed

Альтернативный WebUI (скин) для qBittorrent на базе штатного интерфейса 5.2.x  
с графиками скорости (как в µTorrent) и опциональными метриками хоста.

## Состав

| Путь | Назначение |
|------|------------|
| `public/` + `private/` | сам скин — этого достаточно для Alternative WebUI |
| `translations/` | переводы (если есть) |
| `daemon/` | **опционально** — лёгкий демон CPU/RAM (роутер / хост) |

Без демона скин полностью рабочий: торренты, графики ↓/↑, настройки.  
Пункты **CPU / RAM / web CPU / qb RAM** в статус-баре и серии CPU/RAM на графике  
появляются **только если** демон отдаёт `private/fk-sysinfo.json`.  
Пока демона нет — опроса и маяков нет, лишних запросов нет.

## Установка с GitHub (скин + демон, Keenetic/Entware)

1. Залейте репозиторий на GitHub и опубликуйте **Release** с zip-архивом  
   `webui-speed-<версия>.zip` (собрать: `.\pack-release.ps1` на Windows).
2. На роутере:

```sh
FK_WEBUI_REPO=owner/name sh install-from-github.sh
```

Или вставьте в SSH целиком блок из `install-from-github-short.sh`  
(внутри замените `USER/REPO` на свой репозиторий).

Скрипт скачает latest release, поставит Alternative WebUI и запустит демон `S90fk-sysinfo`.  
Только скин без демона: `FK_WEBUI_SKIP_DAEMON=1`.

## Установка скина вручную (любая ОС)

1. Скопируйте папку так, чтобы внутри были `public` и `private`  
   (например `~/qBittorrent/webui-speed` или `/opt/etc/.../webui-speed`).
2. В qBittorrent: **Настройки → Web UI → Use alternative Web UI**  
   укажите путь к этой папке (к корню, где лежат `public` и `private`).
3. Сохраните, обновите страницу (Ctrl+F5).

Или на устройстве с Entware (из уже распакованной папки):

```sh
sh /path/to/webui-speed/install.sh
```

## Опциональный демон метрик (отдельно)

Если скин уже стоит, а демон ещё нет:

```sh
sh /path/to/webui-speed/daemon/install.sh
```

Демон пишет JSON в `private/fk-sysinfo.json` рядом с темой (same-origin, без лишних портов).  
Остановка: `/opt/etc/init.d/S90fk-sysinfo stop`

### Что показывает демон

| Пункт | Смысл |
|--------|--------|
| CPU | общая загрузка хоста |
| RAM | занято / всего |
| web CPU | % CPU qBit + демон (от всех ядер, как CPU хоста) |
| qb RAM | сумма RSS всех процессов qbittorrent-nox на роутере |

## Сборка zip для релиза

```powershell
.\pack-release.ps1
# → dist\webui-speed-<ver>.zip
```

В GitHub Release прикрепите этот файл (в имени должно быть `webui-speed` и `.zip`).

## Версия

См. `version.txt`. В WebUI кэш сбрасывается параметром `fk=` в `private/index.html`.
