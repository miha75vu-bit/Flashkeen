#!/bin/sh
# Sampler CPU/RAM → JSON. Без set -e (чтобы не молча падать в cron).
OUT="${FK_HOSTINFO_OUT:-/opt/etc/qBittorrent_entware/webui-speed/public/fk-host.json}"
STATE="${FK_HOSTINFO_STATE:-/tmp/fk-hostinfo.state}"
LOG="${FK_HOSTINFO_LOG:-/opt/etc/qBittorrent_entware/webui-speed/public/fk-hostinfo.log}"
INTERVAL="${FK_HOSTINFO_INTERVAL:-5}"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null) $*" >> "$LOG" 2>/dev/null || true
}

read_cpu() {
    awk '/^cpu / {
        idle=$5+$6; total=0;
        for (i=2;i<=NF;i++) total+=$i;
        print total, idle;
        exit
    }' /proc/stat 2>/dev/null
}

mem_used_mb() {
    awk '
        /^MemTotal:/ {t=$2}
        /^MemAvailable:/ {a=$2}
        END {
            if (t+0 < 1) print 0;
            else printf "%.0f", (t-a)/1024;
        }
    ' /proc/meminfo 2>/dev/null
}

qbit_pid() {
    pidof qbittorrent-nox 2>/dev/null | awk '{print $1; exit}'
    pidof qbittorrent 2>/dev/null | awk '{print $1; exit}'
}

sample_once() {
    cur="$(read_cpu)"
    ct="$(echo "$cur" | awk '{print $1+0}')"
    ci="$(echo "$cur" | awk '{print $2+0}')"

    pt=0; pi=0; pp=0
    if [ -f "$STATE" ]; then
        pt="$(awk '{print $1+0}' "$STATE")"
        pi="$(awk '{print $2+0}' "$STATE")"
        pp="$(awk '{print $3+0}' "$STATE")"
    fi

    dt=$((ct - pt))
    di=$((ci - pi))
    sys_cpu=0
    if [ "$dt" -gt 0 ] 2>/dev/null; then
        sys_cpu="$(awk -v dt="$dt" -v di="$di" 'BEGIN{u=(dt-di)*100/dt; if(u<0)u=0; if(u>100)u=100; printf "%.0f",u}')"
    fi
    sys_ram="$(mem_used_mb)"
    [ -n "$sys_ram" ] || sys_ram=0

    qpid="$(qbit_pid | head -n1)"
    cp=0
    app_cpu=0
    app_ram=0
    if [ -n "$qpid" ] && [ -r "/proc/$qpid/stat" ]; then
        cp="$(awk '{print $14+$15}' "/proc/$qpid/stat")"
        rss="$(awk '/^VmRSS:/ {print $2+0; exit}' "/proc/$qpid/status")"
        app_ram="$(awk -v k="$rss" 'BEGIN{printf "%.0f", k/1024}')"
        if [ "$dt" -gt 0 ] 2>/dev/null; then
            dp=$((cp - pp))
            [ "$dp" -lt 0 ] && dp=0
            app_cpu="$(awk -v dp="$dp" -v dt="$dt" 'BEGIN{u=dp*100/dt; if(u<0)u=0; if(u>100)u=100; printf "%.0f",u}')"
        fi
    fi

    echo "$ct $ci $cp" > "$STATE" 2>/dev/null || true
    ts="$(date +%s 2>/dev/null || echo 0)"
    mkdir -p "$(dirname "$OUT")" 2>/dev/null || true
    tmp="$OUT.tmp.$$"
    printf '{"ts":%s,"sys":{"cpu":%s,"ram_mb":%s},"app":{"cpu":%s,"ram_mb":%s}}\n' \
        "$ts" "$sys_cpu" "$sys_ram" "$app_cpu" "$app_ram" > "$tmp" 2>/dev/null
    if [ -f "$tmp" ]; then
        mv -f "$tmp" "$OUT" 2>/dev/null || cat "$tmp" > "$OUT"
        rm -f "$tmp" 2>/dev/null
        log "ok sys=${sys_cpu}% ${sys_ram}MB app=${app_cpu}% ${app_ram}MB"
    else
        log "fail write $OUT"
        return 1
    fi
}

if [ "$1" = "once" ]; then
    sample_once
    exit $?
fi

echo $$ > /tmp/fk-hostinfo.pid 2>/dev/null || true
log "daemon start pid=$$"
while true; do
    sample_once || true
    sleep "$INTERVAL"
done
