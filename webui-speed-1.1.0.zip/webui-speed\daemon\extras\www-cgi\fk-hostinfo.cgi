#!/opt/bin/perl
# self-contained CGI: CPU/RAM роутера + qBittorrent → JSON + CORS
use strict;
use warnings;

print "Content-Type: application/json; charset=utf-8\r\n";
print "Access-Control-Allow-Origin: *\r\n";
print "Cache-Control: no-store\r\n";
print "\r\n";

my $out   = "/opt/etc/qBittorrent_entware/webui-speed/public/fk-host.json";
my $state = "/tmp/fk-hostinfo.state";

sub read_cpu {
    if (open my $fh, "<", "/proc/stat") {
        while (my $line = <$fh>) {
            if ($line =~ /^cpu\s+(.*)/) {
                my @n = split /\s+/, $1;
                my $idle = ($n[3] // 0) + ($n[4] // 0);
                my $total = 0;
                $total += $_ for @n;
                close $fh;
                return ($total, $idle);
            }
        }
        close $fh;
    }
    return (0, 0);
}

sub mem_used_mb {
    my ($t, $a) = (0, 0);
    if (open my $fh, "<", "/proc/meminfo") {
        while (<$fh>) {
            $t = $1 if /^MemTotal:\s+(\d+)/;
            $a = $1 if /^MemAvailable:\s+(\d+)/;
        }
        close $fh;
    }
    return 0 if $t < 1;
    return int(($t - $a) / 1024);
}

sub qbit_pid {
    for my $name (qw(qbittorrent-nox qbittorrent)) {
        my $p = `pidof $name 2>/dev/null`;
        if ($p =~ /(\d+)/) { return $1; }
    }
    return 0;
}

sub proc_cpu {
    my ($pid) = @_;
    return 0 unless $pid && open my $fh, "<", "/proc/$pid/stat";
    my $line = <$fh>;
    close $fh;
    return 0 unless defined $line;
    # field 14,15 after comm — comm may contain spaces in () 
    if ($line =~ /\((?:\\.|[^)])*\)\s+\S+\s+(.*)/) {
        my @rest = split /\s+/, $1;
        # utime stime are indices 11,12 in @rest (fields 14,15 overall after state)
        return ($rest[11] // 0) + ($rest[12] // 0);
    }
    my @f = split /\s+/, $line;
    return ($f[13] // 0) + ($f[14] // 0);
}

sub proc_rss_mb {
    my ($pid) = @_;
    return 0 unless $pid && open my $fh, "<", "/proc/$pid/status";
    while (<$fh>) {
        if (/^VmRSS:\s+(\d+)/) {
            close $fh;
            return int($1 / 1024);
        }
    }
    close $fh;
    return 0;
}

my ($ct, $ci) = read_cpu();
my ($pt, $pi, $pp) = (0, 0, 0);
if (open my $sf, "<", $state) {
    my $line = <$sf>;
    close $sf;
    if (defined $line) {
        ($pt, $pi, $pp) = map { $_ + 0 } split /\s+/, $line;
    }
}

my $dt = $ct - $pt;
my $di = $ci - $pi;
my $sys_cpu = 0;
if ($dt > 0) {
    $sys_cpu = int(($dt - $di) * 100 / $dt);
    $sys_cpu = 0 if $sys_cpu < 0;
    $sys_cpu = 100 if $sys_cpu > 100;
}
my $sys_ram = mem_used_mb();

my $qpid = qbit_pid();
my $cp = proc_cpu($qpid);
my $app_ram = proc_rss_mb($qpid);
my $app_cpu = 0;
if ($dt > 0) {
    my $dp = $cp - $pp;
    $dp = 0 if $dp < 0;
    $app_cpu = int($dp * 100 / $dt);
    $app_cpu = 0 if $app_cpu < 0;
    $app_cpu = 100 if $app_cpu > 100;
}

if (open my $sf, ">", $state) {
    print {$sf} "$ct $ci $cp\n";
    close $sf;
}

my $ts = time;
my $json = sprintf(
    '{"ts":%d,"sys":{"cpu":%d,"ram_mb":%d},"app":{"cpu":%d,"ram_mb":%d}}' . "\n",
    $ts, $sys_cpu, $sys_ram, $app_cpu, $app_ram
);

if (open my $of, ">", $out) {
    print {$of} $json;
    close $of;
}

print $json;
