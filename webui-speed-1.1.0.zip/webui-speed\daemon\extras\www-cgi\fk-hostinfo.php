<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Cache-Control: no-store");

$out = "/opt/etc/qBittorrent_entware/webui-speed/public/fk-host.json";
$state = "/tmp/fk-hostinfo.state";

function read_cpu() {
    $line = @file("/proc/stat")[0] ?? "";
    if (!preg_match('/^cpu\s+(.*)/', $line, $m)) return [0, 0];
    $n = preg_split('/\s+/', trim($m[1]));
    $idle = (int)($n[3] ?? 0) + (int)($n[4] ?? 0);
    $total = 0;
    foreach ($n as $v) $total += (int)$v;
    return [$total, $idle];
}

function mem_used_mb() {
    $t = 0; $a = 0;
    foreach (@file("/proc/meminfo") ?: [] as $line) {
        if (preg_match('/^MemTotal:\s+(\d+)/', $line, $m)) $t = (int)$m[1];
        if (preg_match('/^MemAvailable:\s+(\d+)/', $line, $m)) $a = (int)$m[1];
    }
    if ($t < 1) return 0;
    return (int)(($t - $a) / 1024);
}

function qbit_pid() {
    foreach (["qbittorrent-nox", "qbittorrent"] as $name) {
        $p = trim((string)@shell_exec("pidof " . escapeshellarg($name) . " 2>/dev/null"));
        if (preg_match('/(\d+)/', $p, $m)) return (int)$m[1];
    }
    return 0;
}

function proc_cpu($pid) {
    if ($pid < 1) return 0;
    $line = @file_get_contents("/proc/$pid/stat");
    if ($line === false) return 0;
    if (preg_match('/\)\s+\S+\s+(.*)/', $line, $m)) {
        $rest = preg_split('/\s+/', trim($m[1]));
        return (int)($rest[11] ?? 0) + (int)($rest[12] ?? 0);
    }
    return 0;
}

function proc_rss_mb($pid) {
    if ($pid < 1) return 0;
    foreach (@file("/proc/$pid/status") ?: [] as $line) {
        if (preg_match('/^VmRSS:\s+(\d+)/', $line, $m)) return (int)((int)$m[1] / 1024);
    }
    return 0;
}

[$ct, $ci] = read_cpu();
$pt = 0; $pi = 0; $pp = 0;
if (is_readable($state)) {
    $parts = preg_split('/\s+/', trim((string)@file_get_contents($state)));
    $pt = (int)($parts[0] ?? 0);
    $pi = (int)($parts[1] ?? 0);
    $pp = (int)($parts[2] ?? 0);
}
$dt = $ct - $pt;
$di = $ci - $pi;
$sys_cpu = 0;
if ($dt > 0) {
    $sys_cpu = (int)(($dt - $di) * 100 / $dt);
    if ($sys_cpu < 0) $sys_cpu = 0;
    if ($sys_cpu > 100) $sys_cpu = 100;
}
$sys_ram = mem_used_mb();
$qpid = qbit_pid();
$cp = proc_cpu($qpid);
$app_ram = proc_rss_mb($qpid);
$app_cpu = 0;
if ($dt > 0) {
    $dp = $cp - $pp;
    if ($dp < 0) $dp = 0;
    $app_cpu = (int)($dp * 100 / $dt);
    if ($app_cpu < 0) $app_cpu = 0;
    if ($app_cpu > 100) $app_cpu = 100;
}
@file_put_contents($state, "$ct $ci $cp\n");
$json = json_encode([
    "ts" => time(),
    "sys" => ["cpu" => $sys_cpu, "ram_mb" => $sys_ram],
    "app" => ["cpu" => $app_cpu, "ram_mb" => $app_ram],
], JSON_UNESCAPED_UNICODE);
@file_put_contents($out, $json . "\n");
echo $json, "\n";
