#!/bin/sh
# Лёгкий опрос метрик → JSON в RootFolder/private.
# Управление: маяк fk-want/CRWW или fk-sysinfo-want.json
#
# fk_sys_cpu     — загрузка CPU хоста (%), из /proc/stat (точнее RCI)
# fk_panel_cpu   — % CPU всех qbittorrent-nox + дочерних (все ядра)
# fk_col_cpu     — % CPU этого демона
# fk_panel_rss_kb / fk_col_rss_kb — RSS дерева qBit и демона
# fk_panel_vms_kb / fk_col_vms_kb — VmSize (вирт. память), если есть в /proc

WEBUI_PRIVATE="${FK_SYSINFO_DIR:-/opt/etc/qBittorrent_entware/webui-speed/private}"
OUT="$WEBUI_PRIVATE/fk-sysinfo.json"
WANT="$WEBUI_PRIVATE/fk-sysinfo-want.json"
WANT_DIR="$WEBUI_PRIVATE/fk-want"
RCI="http://127.0.0.1:79/rci/show/system"
INTERVAL="${FK_SYSINFO_INTERVAL:-5}"
RCI_EVERY="${FK_SYSINFO_RCI_EVERY:-2}"
WANT_FRESH_SEC="${FK_SYSINFO_WANT_FRESH:-120}"

# Кольцо графиков: RAM (/tmp) до 12 ч или 4 МБ → сброс в архив на диск; диск ≤20 МБ.
# Скорость при >30 КиБ/с; CPU/RAM — всегда при наличии метрик.
HIST_TMP="${FK_SG_HIST_TMP:-/tmp/fk-sg-ring.txt}"
HIST_WWW="$WEBUI_PRIVATE/fk-sg-hist.txt"
HIST_DIR="${FK_SG_HIST_DIR:-$WEBUI_PRIVATE/fk-sg-hist}"
HIST_MANIFEST="$HIST_DIR/manifest.txt"
HIST_LOAD_MIN="${FK_SG_LOAD_MIN:-30720}"
HIST_KEEP_SEC="${FK_SG_KEEP_SEC:-43200}"
HIST_RAM_MAX="${FK_SG_RAM_MAX:-4194304}"
HIST_DISK_MAX="${FK_SG_DISK_MAX:-20971520}"
HIST_PUB_EVERY="${FK_SG_PUB_EVERY:-300}"
HIST_BUCKET="${FK_SG_BUCKET:-60}"
QBT_PORT="${FK_QBT_PORT:-}"
hist_acc_min=0
hist_acc_n=0
hist_acc_dl=0
hist_acc_ul=0
hist_acc_cpu=0
hist_acc_cn=0
hist_acc_ram=0
hist_acc_rn=0
hist_last_pub=0
mkdir -p "$HIST_DIR" 2>/dev/null || true

# USER_HZ
if [ -n "$FK_SYSINFO_HZ" ]; then
    HZ="$FK_SYSINFO_HZ"
else
    HZ=$(getconf CLK_TCK 2>/dev/null || echo 100)
fi
[ "$HZ" -gt 0 ] 2>/dev/null || HZ=100

mkdir -p "$WEBUI_PRIVATE" "$WANT_DIR" 2>/dev/null || true

i=0
while [ "$i" -lt 16 ]; do
    b0=$(( (i >> 3) & 1 ))
    b1=$(( (i >> 2) & 1 ))
    b2=$(( (i >> 1) & 1 ))
    b3=$(( i & 1 ))
    name="${b0}${b1}${b2}${b3}"
    [ -f "$WANT_DIR/$name" ] || : > "$WANT_DIR/$name"
    i=$((i + 1))
done

nproc_count() {
    n=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null)
    [ -n "$n" ] && [ "$n" -gt 0 ] 2>/dev/null && echo "$n" && return
    n=$(grep -c '^cpu[0-9]' /proc/stat 2>/dev/null)
    [ -n "$n" ] && [ "$n" -gt 0 ] 2>/dev/null && echo "$n" && return
    echo 1
}

NPROC=$(nproc_count)

read_pid_jiffies() {
    pid="$1"
    [ -n "$pid" ] && [ -r "/proc/$pid/stat" ] || { echo 0; return; }
    # после «)» : поле 12=utime, 13=stime (см. proc(5))
    set -- $(sed 's/.*)//' /proc/$pid/stat 2>/dev/null)
    echo $(( ${12:-0} + ${13:-0} ))
}

read_self_jiffies() {
    read_pid_jiffies "self"
}

# /proc/stat: total и idle(+iowait) jiffies (сумма по всем ядрам)
read_host_cpu() {
    # cpu  user nice system idle iowait irq softirq steal guest guest_nice
    set -- $(grep '^cpu ' /proc/stat 2>/dev/null)
    shift
    user=${1:-0}; nice=${2:-0}; system=${3:-0}; idle=${4:-0}
    iowait=${5:-0}; irq=${6:-0}; softirq=${7:-0}; steal=${8:-0}
    total=$((user + nice + system + idle + iowait + irq + softirq + steal))
    idles=$((idle + iowait))
    echo "$total $idles"
}

CORES_PREV="$WEBUI_PRIVATE/.fk-cores-prev"
CORES_STAT="$WEBUI_PRIVATE/.fk-cores-stat"

# Пишет в CORES_STAT строки: idx total idle
# Печатает JSON-массив процентов по ядрам (или пусто если нет дельты)
compute_cores_json() {
    grep '^cpu[0-9]' /proc/stat 2>/dev/null > "$CORES_STAT" || {
        echo ""
        return
    }
    json="["
    sep_c=""
    idx=0
    : > "$CORES_PREV.new"
    while read -r _name user nice system idle iowait irq softirq steal _; do
        user=${user:-0}; nice=${nice:-0}; system=${system:-0}; idle=${idle:-0}
        iowait=${iowait:-0}; irq=${irq:-0}; softirq=${softirq:-0}; steal=${steal:-0}
        total=$((user + nice + system + idle + iowait + irq + softirq + steal))
        idles=$((idle + iowait))
        prev_t=""
        prev_i=""
        if [ -f "$CORES_PREV" ]; then
            set -- $(awk -v i="$idx" '$1==i {print $2,$3; exit}' "$CORES_PREV" 2>/dev/null)
            prev_t=${1:-}
            prev_i=${2:-}
        fi
        echo "$idx $total $idles" >> "$CORES_PREV.new"
        ci=0
        cf=0
        if [ -n "$prev_t" ] && [ -n "$prev_i" ]; then
            dt=$((total - prev_t))
            di=$((idles - prev_i))
            if [ "$dt" -gt 0 ]; then
                set -- $(host_cpu_pct_parts "$dt" "$di")
                ci=$1
                cf=$2
            fi
        fi
        json="${json}${sep_c}${ci}.${cf}"
        sep_c=","
        idx=$((idx + 1))
    done < "$CORES_STAT"
    json="${json}]"
    mv -f "$CORES_PREV.new" "$CORES_PREV" 2>/dev/null || true
    [ "$idx" -eq 0 ] && echo "" || echo "$json"
}

# все qbittorrent-nox и их дочерние процессы
list_qbit_tree_pids() {
    seen=" "
    out=""
    queue=""
    for n in qbittorrent-nox aarch64-qbittorrent-nox mipsel-qbittorrent-nox; do
        for p in $(pidof "$n" 2>/dev/null); do
            case "$seen" in *" $p "*) continue ;; esac
            [ -r "/proc/$p/stat" ] || continue
            seen="$seen$p "
            out="$out $p"
            queue="$queue $p"
        done
    done
    if [ -z "$out" ]; then
        for d in /proc/[0-9]*; do
            [ -r "$d/cmdline" ] || continue
            case $(tr '\0' ' ' < "$d/cmdline" 2>/dev/null) in
                *qbittorrent-nox*)
                    p=${d##*/}
                    case "$seen" in *" $p "*) continue ;; esac
                    [ -r "/proc/$p/stat" ] || continue
                    seen="$seen$p "
                    out="$out $p"
                    queue="$queue $p"
                    ;;
            esac
        done
    fi
    while [ -n "$queue" ]; do
        next=""
        for parent in $queue; do
            for d in /proc/[0-9]*; do
                c=${d##*/}
                case "$seen" in *" $c "*) continue ;; esac
                [ -r "$d/stat" ] || continue
                set -- $(sed 's/.*)//' "$d/stat" 2>/dev/null)
                [ "${2:-}" = "$parent" ] || continue
                seen="$seen$c "
                out="$out $c"
                next="$next $c"
            done
        done
        queue=$next
    done
    echo $out
}

sum_pids_jiffies() {
    sum=0
    for p in $1; do
        j=$(read_pid_jiffies "$p")
        sum=$((sum + j))
    done
    echo "$sum"
}

# сумма RSS дерева qBit (КиБ)
sum_qbit_rss_kb() {
    sum=0
    for p in $(list_qbit_tree_pids); do
        r=$(read_rss_kb "$p")
        sum=$((sum + r))
    done
    echo "$sum"
}

# сумма VmSize дерева qBit (КиБ); пусто если /proc не отдаёт VmSize
sum_qbit_vms_kb() {
    sum=0
    any=0
    for p in $(list_qbit_tree_pids); do
        v=$(read_vms_kb "$p")
        [ -n "$v" ] || continue
        any=1
        sum=$((sum + v))
    done
    [ "$any" = 1 ] && echo "$sum" || echo ""
}

# dj за du сек → % от всех ядер, одна десятая (i f)
# 1000*dj / (HZ*du*nproc) = проценты*10
cpu_pct_parts() {
    dj="$1"
    du="$2"
    np="$3"
    [ "$dj" -lt 0 ] && dj=0
    [ "$du" -le 0 ] && du=1
    [ "$np" -le 0 ] && np=1
    # проценты * 10
    pct=$((dj * 1000 / (HZ * du * np)))
    i=$((pct / 10))
    f=$((pct % 10))
    [ "$i" -gt 100 ] && i=100 && f=0
    echo "$i $f"
}

host_cpu_pct_parts() {
    dt="$1"
    di="$2"
    [ "$dt" -le 0 ] && { echo "0 0"; return; }
    [ "$di" -lt 0 ] && di=0
    [ "$di" -gt "$dt" ] && di=$dt
    busy=$((dt - di))
    # *1000 / dt → десятые процента
    pct=$((busy * 1000 / dt))
    i=$((pct / 10))
    f=$((pct % 10))
    [ "$i" -gt 100 ] && i=100 && f=0
    echo "$i $f"
}

read_uptime_s() {
    set -- $(cat /proc/uptime 2>/dev/null)
    echo "${1%%.*}"
}

read_rss_kb() {
    pid="$1"
    f="/proc/self/status"
    [ -n "$pid" ] && [ "$pid" != "self" ] && f="/proc/$pid/status"
    [ -r "$f" ] || { echo 0; return; }
    while read -r k v _; do
        [ "$k" = "VmRSS:" ] && echo "$v" && return
    done < "$f"
    echo 0
}

# КиБ; пустая строка если поля нет
read_vms_kb() {
    pid="$1"
    f="/proc/self/status"
    [ -n "$pid" ] && [ "$pid" != "self" ] && f="/proc/$pid/status"
    [ -r "$f" ] || { echo ""; return; }
    while read -r k v _; do
        [ "$k" = "VmSize:" ] && echo "$v" && return
    done < "$f"
    echo ""
}

read_memtotal_kb() {
    while read -r k v _; do
        [ "$k" = "MemTotal:" ] && echo "$v" && return
    done < /proc/meminfo 2>/dev/null
    echo ""
}

# VMEM системы: swap из /proc/meminfo + тип (zram = сжатая, иначе дисковый своп).
# Печатает: used_kb total_kb kind   (kind: zram|swap); пусто если свопа нет.
read_vmem_info() {
    st=""
    sf=""
    while read -r k v _; do
        [ "$k" = "SwapTotal:" ] && st=$v
        [ "$k" = "SwapFree:" ] && sf=$v
    done < /proc/meminfo 2>/dev/null
    [ -n "$st" ] || return 0
    [ "$st" -gt 0 ] 2>/dev/null || return 0
    [ -n "$sf" ] || sf=0
    used=$((st - sf))
    [ "$used" -ge 0 ] 2>/dev/null || used=0
    kind="swap"
    if [ -r /proc/swaps ]; then
        # любое zram-устройство в таблице свопа → сжатая память
        if grep -q 'zram' /proc/swaps 2>/dev/null; then
            kind="zram"
        fi
    elif ls /sys/block/zram* >/dev/null 2>&1; then
        kind="zram"
    fi
    echo "$used $st $kind"
}

fetch_rci() {
    if [ -x /bin/busybox ] && /bin/busybox wget -q -T 2 -O "$1" "$RCI" 2>/dev/null; then
        return 0
    fi
    if command -v wget >/dev/null 2>&1 && wget -q -T 2 -O "$1" "$RCI" 2>/dev/null; then
        return 0
    fi
    if command -v curl >/dev/null 2>&1 && curl -fsS --connect-timeout 1 --max-time 2 "$RCI" -o "$1" 2>/dev/null; then
        return 0
    fi
    return 1
}

detect_qbt_port() {
    if [ -n "$QBT_PORT" ]; then
        echo "$QBT_PORT"
        return
    fi
    for conf in \
        /opt/etc/qBittorrent_entware/qBittorrent/config/qBittorrent.conf \
        /opt/etc/qBittorrent/qBittorrent.conf \
        /opt/etc/qBittorrent/config/qBittorrent.conf
    do
        [ -f "$conf" ] || continue
        p=$(grep -E '^WebUI\\Port=' "$conf" 2>/dev/null | head -n1 | cut -d= -f2 | tr -d '\r')
        if [ -n "$p" ] && [ "$p" -gt 0 ] 2>/dev/null; then
            QBT_PORT=$p
            echo "$p"
            return
        fi
    done
    QBT_PORT=8080
    echo 8080
}

# печатает: dl_bps ul_bps  или пусто
fetch_transfer_speeds() {
    port=$(detect_qbt_port)
    url="http://127.0.0.1:${port}/api/v2/transfer/info"
    tf="$WEBUI_PRIVATE/.fk-xfer.tmp"
    rm -f "$tf" 2>/dev/null
    if [ -x /bin/busybox ] && /bin/busybox wget -q -T 1 -O "$tf" "$url" 2>/dev/null; then
        :
    elif command -v wget >/dev/null 2>&1 && wget -q -T 1 -O "$tf" "$url" 2>/dev/null; then
        :
    elif command -v curl >/dev/null 2>&1 && curl -fsS --connect-timeout 1 --max-time 1 "$url" -o "$tf" 2>/dev/null; then
        :
    else
        rm -f "$tf" 2>/dev/null
        return 1
    fi
    [ -s "$tf" ] || { rm -f "$tf" 2>/dev/null; return 1; }
    body=$(tr -d '\n\r' < "$tf" 2>/dev/null)
    rm -f "$tf" 2>/dev/null
    dl=$(echo "$body" | sed -n 's/.*"dl_info_speed":\([0-9][0-9]*\).*/\1/p' | head -n1)
    ul=$(echo "$body" | sed -n 's/.*"up_info_speed":\([0-9][0-9]*\).*/\1/p' | head -n1)
    [ -n "$dl" ] || dl=0
    [ -n "$ul" ] || ul=0
    echo "$dl $ul"
}

hist_bytes() {
    f="$1"
    [ -f "$f" ] || { echo 0; return; }
    wc -c < "$f" 2>/dev/null | tr -d ' \t' || echo 0
}

hist_first_ts() {
    [ -f "$HIST_TMP" ] || { echo 0; return; }
    head -n1 "$HIST_TMP" 2>/dev/null | awk '{print $1; exit}'
}

# манифест архивов: ts0 ts1 bytes name
hist_write_manifest() {
    mkdir -p "$HIST_DIR" 2>/dev/null || true
    mf="$HIST_MANIFEST.tmp"
    : > "$mf"
    for f in "$HIST_DIR"/seg-*.txt; do
        [ -f "$f" ] || continue
        bn=$(basename "$f")
        sz=$(hist_bytes "$f")
        t0=$(head -n1 "$f" 2>/dev/null | awk '{print $1; exit}')
        t1=$(tail -n1 "$f" 2>/dev/null | awk '{print $1; exit}')
        [ -n "$t0" ] && [ -n "$t1" ] || continue
        printf '%s %s %s %s\n' "$t0" "$t1" "$sz" "$bn" >> "$mf"
    done
    mv -f "$mf" "$HIST_MANIFEST" 2>/dev/null || cat "$mf" > "$HIST_MANIFEST" 2>/dev/null || true
}

# диск ≤ HIST_DISK_MAX: удаляем самые старые seg-*
hist_prune_disk() {
    mkdir -p "$HIST_DIR" 2>/dev/null || true
    while :; do
        total=0
        for f in "$HIST_DIR"/seg-*.txt; do
            [ -f "$f" ] || continue
            sz=$(hist_bytes "$f")
            total=$((total + sz))
        done
        [ "$total" -le "$HIST_DISK_MAX" ] 2>/dev/null && break
        oldest=""
        for f in "$HIST_DIR"/seg-*.txt; do
            [ -f "$f" ] || continue
            oldest=$f
            break
        done
        [ -n "$oldest" ] || break
        rm -f "$oldest" 2>/dev/null || break
    done
    hist_write_manifest
}

# текущий RAM-буфер → seg на диск, очистка /tmp
hist_flush_to_disk() {
    [ -f "$HIST_TMP" ] || return
    [ -s "$HIST_TMP" ] || return
    now=$(date +%s 2>/dev/null || echo 0)
    [ "$now" -gt 0 ] || return
    mkdir -p "$HIST_DIR" 2>/dev/null || true
    seg="$HIST_DIR/seg-${now}.txt"
    mv -f "$HIST_TMP" "$seg" 2>/dev/null || {
        cat "$HIST_TMP" > "$seg" 2>/dev/null || return
        : > "$HIST_TMP"
    }
    : > "$HIST_TMP" 2>/dev/null || true
    hist_prune_disk
    hist_publish
}

# публикация только текущего RAM-кольца (без переписывания всего архива)
hist_publish() {
    now=$(date +%s 2>/dev/null || echo 0)
    if [ -f "$HIST_TMP" ]; then
        cp -f "$HIST_TMP" "$HIST_WWW" 2>/dev/null || cat "$HIST_TMP" > "$HIST_WWW" 2>/dev/null || true
    else
        : > "$HIST_WWW" 2>/dev/null || true
    fi
    hist_last_pub=$now
}

# 12 ч или 4 МБ → архив; публикация не чаще HIST_PUB_EVERY (кроме ротации)
hist_maybe_rotate_and_pub() {
    now=$(date +%s 2>/dev/null || echo 0)
    [ "$now" -gt 0 ] || return
    rotated=0
    if [ -f "$HIST_TMP" ] && [ -s "$HIST_TMP" ]; then
        sz=$(hist_bytes "$HIST_TMP")
        t0=$(hist_first_ts)
        age=0
        [ -n "$t0" ] && [ "$t0" -gt 0 ] 2>/dev/null && age=$((now - t0))
        if [ "$sz" -ge "$HIST_RAM_MAX" ] 2>/dev/null || [ "$age" -ge "$HIST_KEEP_SEC" ] 2>/dev/null; then
            hist_flush_to_disk
            rotated=1
        fi
    fi
    if [ "$rotated" = 0 ]; then
        if [ "$hist_last_pub" -eq 0 ] || [ $((now - hist_last_pub)) -ge "$HIST_PUB_EVERY" ]; then
            hist_publish
        fi
    fi
}

hist_flush_minute() {
    [ "$hist_acc_n" -gt 0 ] 2>/dev/null || return
    [ "$hist_acc_min" -gt 0 ] 2>/dev/null || return
    dl=$((hist_acc_dl / hist_acc_n))
    ul=$((hist_acc_ul / hist_acc_n))
    max=$dl
    [ "$ul" -gt "$max" ] && max=$ul
    keep=0
    [ "$max" -ge "$HIST_LOAD_MIN" ] && keep=1
    [ "$hist_acc_cn" -gt 0 ] && keep=1
    [ "$hist_acc_rn" -gt 0 ] && keep=1
    if [ "$keep" = 1 ]; then
        ts=$((hist_acc_min + HIST_BUCKET / 2))
        cpu="-"
        ram="-"
        if [ "$hist_acc_cn" -gt 0 ]; then
            c10=$((hist_acc_cpu / hist_acc_cn))
            cpu=$((c10 / 10)).$((c10 % 10))
        fi
        if [ "$hist_acc_rn" -gt 0 ]; then
            r10=$((hist_acc_ram / hist_acc_rn))
            ram=$((r10 / 10)).$((r10 % 10))
        fi
        printf '%s %s %s %s %s\n' "$ts" "$dl" "$ul" "$cpu" "$ram" >> "$HIST_TMP"
        hist_maybe_rotate_and_pub
    fi
    hist_acc_min=0
    hist_acc_n=0
    hist_acc_dl=0
    hist_acc_ul=0
    hist_acc_cpu=0
    hist_acc_cn=0
    hist_acc_ram=0
    hist_acc_rn=0
}

# dl/ul B/s; cpu_i cpu_f ram_i (целые), пустые = нет
hist_note_sample() {
    dl="${1:-0}"
    ul="${2:-0}"
    cpu_i="$3"
    cpu_f="$4"
    ram_i="$5"
    now=$(date +%s 2>/dev/null || echo 0)
    [ "$now" -gt 0 ] || return
    bucket=$((now / HIST_BUCKET * HIST_BUCKET))
    if [ "$hist_acc_min" -gt 0 ] && [ "$hist_acc_min" -ne "$bucket" ]; then
        hist_flush_minute
    fi
    if [ "$hist_acc_min" -eq 0 ]; then
        hist_acc_min=$bucket
    fi
    hist_acc_n=$((hist_acc_n + 1))
    hist_acc_dl=$((hist_acc_dl + dl))
    hist_acc_ul=$((hist_acc_ul + ul))
    if [ -n "$cpu_i" ]; then
        [ -n "$cpu_f" ] || cpu_f=0
        c10=$((cpu_i * 10 + cpu_f))
        hist_acc_cpu=$((hist_acc_cpu + c10))
        hist_acc_cn=$((hist_acc_cn + 1))
    fi
    if [ -n "$ram_i" ]; then
        hist_acc_ram=$((hist_acc_ram + ram_i * 10))
        hist_acc_rn=$((hist_acc_rn + 1))
    fi
}

file_atime() {
    f="$1"
    [ -f "$f" ] || { echo 0; return; }
    if a=$(stat -c %X "$f" 2>/dev/null); then echo "$a"; return; fi
    if a=$(stat -f %a "$f" 2>/dev/null); then echo "$a"; return; fi
    echo 0
}

want_cpu=1
want_ram=1
want_webcpu=1
want_webram=1

read_want() {
    want_cpu=1
    want_ram=1
    want_webcpu=1
    want_webram=1

    now=$(date +%s 2>/dev/null || echo 0)
    best_a=0
    best=""
    for f in "$WANT_DIR"/[01][01][01][01]; do
        [ -f "$f" ] || continue
        a=$(file_atime "$f")
        [ "$a" -gt "$best_a" ] 2>/dev/null || continue
        if [ "$now" -gt 0 ] && [ "$a" -gt 0 ]; then
            age=$((now - a))
            [ "$age" -ge 0 ] && [ "$age" -le "$WANT_FRESH_SEC" ] || continue
        fi
        best_a=$a
        best=$(basename "$f")
    done

    if [ -n "$best" ] && [ "${#best}" -eq 4 ]; then
        want_cpu=$(echo "$best" | cut -c1)
        want_ram=$(echo "$best" | cut -c2)
        want_webcpu=$(echo "$best" | cut -c3)
        want_webram=$(echo "$best" | cut -c4)
        printf '{"cpu":%s,"ram":%s,"webcpu":%s,"webram":%s}\n' \
            "$want_cpu" "$want_ram" "$want_webcpu" "$want_webram" > "$WANT" 2>/dev/null
        return 0
    fi

    [ -f "$WANT" ] || return 0
    w=$(tr -d ' \n\r\t' < "$WANT" 2>/dev/null)
    case "$w" in *\"cpu\":0*) want_cpu=0 ;; esac
    case "$w" in *\"ram\":0*) want_ram=0 ;; esac
    case "$w" in *\"webcpu\":0*) want_webcpu=0 ;; esac
    case "$w" in *\"webram\":0*) want_webram=0 ;; esac
}

last_rci_body=""
tick=0
prev_j=$(read_self_jiffies)
prev_u=$(read_uptime_s)
prev_qj=0
prev_qbit_fp=""
set -- $(read_host_cpu)
prev_ht=$1
prev_hi=$2

while :; do
    if ! pidof qbittorrent-nox >/dev/null 2>&1 \
        && ! pidof aarch64-qbittorrent-nox >/dev/null 2>&1 \
        && ! pidof mipsel-qbittorrent-nox >/dev/null 2>&1; then
        if [ -z "$(list_qbit_tree_pids)" ]; then
            rm -f "$OUT" 2>/dev/null
            last_rci_body=""
            prev_qj=0
            prev_qbit_fp=""
            sleep 20
            prev_j=$(read_self_jiffies)
            prev_u=$(read_uptime_s)
            set -- $(read_host_cpu)
            prev_ht=$1
            prev_hi=$2
            continue
        fi
    fi

    read_want
    tick=$((tick + 1))
    tmp="$OUT.tmp"
    ok=0
    need_rci=0
    [ "$want_ram" = 1 ] && need_rci=1
    # RCI как запасной cpuload, если /proc/stat недоступен
    [ "$want_cpu" = 1 ] && need_rci=1

    if [ "$need_rci" = 1 ]; then
        if [ $((tick % RCI_EVERY)) -eq 0 ]; then
            if fetch_rci "$tmp" && [ -s "$tmp" ]; then
                # одна строка JSON без внешней {
                last_rci_body=$(tr -d '\n\r' < "$tmp" | sed 's/^{//')
                ok=1
            fi
        elif [ -n "$last_rci_body" ]; then
            ok=1
        fi
    else
        last_rci_body=""
    fi

    col_i=0; col_f=0
    panel_i=0; panel_f=0
    sys_i=0; sys_f=0
    rss_kb=0
    panel_rss_kb=0
    vms_kb=""
    panel_vms_kb=""
    memtotal_kb=""
    have_sys=0
    cores_json=""

    cur_j=$(read_self_jiffies)
    cur_u=$(read_uptime_s)
    du=$((cur_u - prev_u))
    [ "$du" -le 0 ] && du=1

    set -- $(read_host_cpu)
    cur_ht=$1
    cur_hi=$2

    if [ "$want_cpu" = 1 ]; then
        dt=$((cur_ht - prev_ht))
        di=$((cur_hi - prev_hi))
        if [ "$dt" -gt 0 ]; then
            set -- $(host_cpu_pct_parts "$dt" "$di")
            sys_i=$1
            sys_f=$2
            have_sys=1
        fi
        cores_json=$(compute_cores_json)
    fi

    need_proc=0
    [ "$want_webcpu" = 1 ] && need_proc=1
    [ "$want_webram" = 1 ] && need_proc=1
    qbit_pids=""
    if [ "$need_proc" = 1 ]; then
        qbit_pids=$(list_qbit_tree_pids)
    fi

    if [ "$want_webcpu" = 1 ]; then
        dj=$((cur_j - prev_j))
        set -- $(cpu_pct_parts "$dj" "$du" "$NPROC")
        col_i=$1
        col_f=$2

        if [ -n "$qbit_pids" ]; then
            cur_qj=$(sum_pids_jiffies "$qbit_pids")
            qbit_fp=$(echo "$qbit_pids" | tr -s ' ' ',')
            if [ "$qbit_fp" != "$prev_qbit_fp" ] || [ "$prev_qj" -le 0 ]; then
                prev_qj=$cur_qj
                prev_qbit_fp=$qbit_fp
                panel_i=0
                panel_f=0
            else
                djq=$((cur_qj - prev_qj))
                [ "$djq" -lt 0 ] && djq=0
                set -- $(cpu_pct_parts "$djq" "$du" "$NPROC")
                panel_i=$1
                panel_f=$2
                prev_qj=$cur_qj
            fi
        else
            prev_qj=0
            prev_qbit_fp=""
            panel_i=0
            panel_f=0
        fi
    fi

    if [ "$want_webram" = 1 ]; then
        rss_kb=$(read_rss_kb self)
        panel_rss_kb=$(sum_qbit_rss_kb)
        vms_kb=$(read_vms_kb self)
        panel_vms_kb=$(sum_qbit_vms_kb)
        memtotal_kb=$(read_memtotal_kb)
    fi

    # VMEM (swap/zram) для попапа «ОЗУ системы»
    vmem_used_kb=""
    vmem_total_kb=""
    vmem_kind=""
    if [ "$want_ram" = 1 ] || [ "$want_webram" = 1 ]; then
        set -- $(read_vmem_info)
        if [ -n "${1:-}" ] && [ -n "${2:-}" ]; then
            vmem_used_kb=$1
            vmem_total_kb=$2
            vmem_kind=${3:-swap}
        fi
    fi

    prev_j=$cur_j
    prev_u=$cur_u
    prev_ht=$cur_ht
    prev_hi=$cur_hi

    {
        printf '{'
        sep=""
        if [ "$have_sys" = 1 ]; then
            printf '%s"fk_sys_cpu":%s.%s' "$sep" "$sys_i" "$sys_f"
            sep=","
            if [ -n "$cores_json" ]; then
                printf '%s"fk_cores":%s' "$sep" "$cores_json"
                sep=","
            fi
        fi
        if [ "$want_webcpu" = 1 ]; then
            printf '%s"fk_panel_cpu":%s.%s,"fk_col_cpu":%s.%s' \
                "$sep" "$panel_i" "$panel_f" "$col_i" "$col_f"
            sep=","
        fi
        if [ "$want_webram" = 1 ]; then
            printf '%s"fk_panel_rss_kb":%s,"fk_col_rss_kb":%s' \
                "$sep" "$panel_rss_kb" "$rss_kb"
            sep=","
            if [ -n "$panel_vms_kb" ] || [ -n "$vms_kb" ]; then
                [ -n "$panel_vms_kb" ] || panel_vms_kb=0
                [ -n "$vms_kb" ] || vms_kb=0
                printf '%s"fk_panel_vms_kb":%s,"fk_col_vms_kb":%s' \
                    "$sep" "$panel_vms_kb" "$vms_kb"
                sep=","
            fi
            if [ -n "$memtotal_kb" ]; then
                printf '%s"fk_mem_total_kb":%s' "$sep" "$memtotal_kb"
                sep=","
            fi
        fi
        if [ -n "$vmem_total_kb" ] && [ -n "$vmem_kind" ]; then
            printf '%s"fk_vmem_used_kb":%s,"fk_vmem_total_kb":%s,"fk_vmem_kind":"%s"' \
                "$sep" "$vmem_used_kb" "$vmem_total_kb" "$vmem_kind"
            sep=","
        fi
        if [ "$ok" = 1 ] && [ -n "$last_rci_body" ]; then
            printf '%s%s' "$sep" "$last_rci_body"
        else
            printf '}'
            printf '\n'
        fi
    } > "$OUT.new" 2>/dev/null && mv -f "$OUT.new" "$OUT"

    # кольцо → /tmp (лёгкое), копия в private для графика
    xdl=0
    xul=0
    xfer=$(fetch_transfer_speeds 2>/dev/null || true)
    if [ -n "$xfer" ]; then
        set -- $xfer
        xdl=${1:-0}
        xul=${2:-0}
    fi
    h_cpu_i=""
    h_cpu_f=""
    h_ram_i=""
    if [ "$have_sys" = 1 ]; then
        h_cpu_i=$sys_i
        h_cpu_f=$sys_f
    fi
    # доля занятой RAM из RCI memory, если есть
    if [ "$ok" = 1 ] && [ -n "$last_rci_body" ]; then
        mem=$(echo "$last_rci_body" | sed -n 's/.*"memory":"\([0-9][0-9]*\)\/\([0-9][0-9]*\)".*/\1 \2/p' | head -n1)
        if [ -n "$mem" ]; then
            set -- $mem
            if [ "${2:-0}" -gt 0 ] 2>/dev/null; then
                h_ram_i=$(( ${1:-0} * 100 / ${2:-1} ))
            fi
        fi
    fi
    # писать минуту при скорости > порога или при наличии CPU/RAM
    if [ -n "$xfer" ] || [ -n "$h_cpu_i" ] || [ -n "$h_ram_i" ]; then
        hist_note_sample "$xdl" "$xul" "$h_cpu_i" "$h_cpu_f" "$h_ram_i"
    fi

    rm -f "$tmp" "$OUT.new" 2>/dev/null
    sleep "$INTERVAL"
done
