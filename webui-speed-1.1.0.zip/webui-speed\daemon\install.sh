#!/bin/sh
# Опциональный демон метрик (Keenetic/Entware и совместимые).
# Тема уже должна лежать в RootFolder (см. ../install.sh).
set -e

SRC="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
THEME_ROOT="$(CDPATH= cd -- "$SRC/.." && pwd)"
DEST="${FK_WEBUI_ROOT:-$THEME_ROOT}"
INIT_D="/opt/etc/init.d/S90fk-sysinfo"

[ -f "$DEST/private/index.html" ] || {
    echo "Сначала установите скин (../install.sh). Нет $DEST/private"
    exit 1
}
[ -f "$SRC/fk-sysinfo-loop.sh" ] || {
    echo "Нет $SRC/fk-sysinfo-loop.sh"
    exit 1
}

mkdir -p "$DEST/daemon"
cp "$SRC/fk-sysinfo-loop.sh" "$DEST/daemon/fk-sysinfo-loop.sh"
cp "$SRC/S90fk-sysinfo" "$DEST/daemon/S90fk-sysinfo"
chmod +x "$DEST/daemon/fk-sysinfo-loop.sh" "$DEST/daemon/S90fk-sysinfo"
mkdir -p "$DEST/private/fk-want" 2>/dev/null || true

# подставить путь темы в init-скрипт
export FK_WEBUI_ROOT="$DEST"
sed "s|^THEME_ROOT=.*|THEME_ROOT=\"$DEST\"|" "$DEST/daemon/S90fk-sysinfo" > "$INIT_D"
chmod +x "$INIT_D"

"$INIT_D" stop 2>/dev/null || true
FK_WEBUI_ROOT="$DEST" "$INIT_D" start

echo "Демон fk-sysinfo запущен."
echo "JSON: $DEST/private/fk-sysinfo.json"
echo "В WebUI появятся CPU / RAM / web CPU / qb RAM (Ctrl+F5)."
