# Онлайн-установка webui-speed (скин + демон) с GitHub.
# Вставьте ВЕСЬ блок в SSH одним разом.
# Перед вставкой замените USER/REPO на свой репозиторий.

sh <<'WEBUI_SPEED_INSTALL'
set -e
# --- правьте здесь ---
FK_WEBUI_REPO="${FK_WEBUI_REPO:-USER/REPO}"
FK_WEBUI_TAG="${FK_WEBUI_TAG:-latest}"
FK_WEBUI_ROOT="${FK_WEBUI_ROOT:-/opt/etc/qBittorrent_entware/webui-speed}"
# FK_WEBUI_SKIP_DAEMON=1   # раскомментируйте, если демон не нужен
# ---------------------

REPO="$FK_WEBUI_REPO"
TAG="$FK_WEBUI_TAG"
DEST="$FK_WEBUI_ROOT"
TMP="/tmp/webui-speed-install.$$"
INIT_D="/opt/etc/init.d/S90fk-sysinfo"

die() { echo "Ошибка: $*" >&2; exit 1; }
[ "$REPO" != "USER/REPO" ] && [ -n "$REPO" ] || die "Задайте FK_WEBUI_REPO=owner/name"

fetch() {
  if command -v curl >/dev/null 2>&1; then curl -fsSL -o "$2" "$1"
  elif command -v wget >/dev/null 2>&1; then wget -q -O "$2" "$1"
  else die "Нужен curl или wget"; fi
}

echo "=== webui-speed ← GitHub $REPO ==="
rm -rf "$TMP"; mkdir -p "$TMP"
ZIP="$TMP/webui-speed.zip"

if [ "$TAG" = "latest" ]; then
  fetch "https://api.github.com/repos/$REPO/releases/latest" "$TMP/release.json" || die "API latest"
  URL=$(sed -n 's/.*"browser_download_url": "\([^"]*webui-speed[^"]*\.zip\)".*/\1/p' "$TMP/release.json" | head -n 1)
  [ -n "$URL" ] || URL=$(sed -n 's/.*"browser_download_url": "\([^"]*\.zip\)".*/\1/p' "$TMP/release.json" | head -n 1)
  TAG_NAME=$(sed -n 's/.*"tag_name": "\([^"]*\)".*/\1/p' "$TMP/release.json" | head -n 1)
  [ -n "$URL" ] || { [ -n "$TAG_NAME" ] || die "нет тега"; URL="https://github.com/$REPO/archive/refs/tags/${TAG_NAME}.zip"; }
else
  fetch "https://api.github.com/repos/$REPO/releases/tags/$TAG" "$TMP/release.json" 2>/dev/null || true
  URL=$(sed -n 's/.*"browser_download_url": "\([^"]*webui-speed[^"]*\.zip\)".*/\1/p' "$TMP/release.json" 2>/dev/null | head -n 1)
  [ -n "$URL" ] || URL=$(sed -n 's/.*"browser_download_url": "\([^"]*\.zip\)".*/\1/p' "$TMP/release.json" 2>/dev/null | head -n 1)
  [ -n "$URL" ] || URL="https://github.com/$REPO/archive/refs/tags/${TAG}.zip"
fi

echo "Скачиваю: $URL"
fetch "$URL" "$ZIP" || die "скачивание"
command -v unzip >/dev/null 2>&1 || die "нужен unzip (opkg install unzip)"
unzip -q -o "$ZIP" -d "$TMP/extract" || die "unzip"

SRC=""
for d in "$TMP/extract" "$TMP/extract"/*; do
  [ -d "$d" ] || continue
  [ -f "$d/private/index.html" ] && [ -f "$d/public/index.html" ] && SRC="$d" && break
done
[ -n "$SRC" ] || die "в архиве нет private/ + public/"

mkdir -p "$DEST"
rm -rf "$DEST/private" "$DEST/public" "$DEST/translations"
cp -a "$SRC/private" "$DEST/private"
cp -a "$SRC/public" "$DEST/public"
[ -d "$SRC/translations" ] && cp -a "$SRC/translations" "$DEST/translations"
cp "$SRC/version.txt" "$DEST/version.txt" 2>/dev/null || echo webui-speed > "$DEST/version.txt"
[ -d "$SRC/daemon" ] && { rm -rf "$DEST/daemon"; cp -a "$SRC/daemon" "$DEST/daemon"; }
mkdir -p "$DEST/private/fk-want"
chmod -R a+rX "$DEST" 2>/dev/null || true
chmod +x "$DEST/daemon/fk-sysinfo-loop.sh" "$DEST/daemon/S90fk-sysinfo" 2>/dev/null || true

CONF=""
for c in /opt/etc/qBittorrent_entware/config/qBittorrent.conf \
         /opt/etc/qBittorrent/config/qBittorrent.conf \
         /opt/root/.config/qBittorrent/qBittorrent.conf; do
  [ -f "$c" ] && CONF="$c" && break
done
if [ -n "$CONF" ]; then
  if grep -q '^WebUI\\AlternativeUIEnabled=' "$CONF" 2>/dev/null; then
    sed -i 's|^WebUI\\AlternativeUIEnabled=.*|WebUI\\AlternativeUIEnabled=true|' "$CONF"
  else
    printf '%s\n' 'WebUI\AlternativeUIEnabled=true' >> "$CONF"
  fi
  if grep -q '^WebUI\\RootFolder=' "$CONF" 2>/dev/null; then
    sed -i "s|^WebUI\\\\RootFolder=.*|WebUI\\\\RootFolder=$DEST|" "$CONF"
  else
    printf '%s\n' "WebUI\\RootFolder=$DEST" >> "$CONF"
  fi
  echo "AlternativeUI → $DEST"
fi

if [ "${FK_WEBUI_SKIP_DAEMON:-0}" != "1" ] && [ -f "$DEST/daemon/fk-sysinfo-loop.sh" ]; then
  export FK_WEBUI_ROOT="$DEST"
  sed "s|^THEME_ROOT=.*|THEME_ROOT=\"$DEST\"|" "$DEST/daemon/S90fk-sysinfo" > "$INIT_D"
  chmod +x "$INIT_D" "$DEST/daemon/fk-sysinfo-loop.sh"
  "$INIT_D" stop 2>/dev/null || true
  FK_WEBUI_ROOT="$DEST" "$INIT_D" start
  echo "Демон запущен"
fi

rm -rf "$TMP"
echo "Готово. Ctrl+F5 в браузере."
WEBUI_SPEED_INSTALL
