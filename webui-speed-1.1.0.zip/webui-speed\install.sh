#!/bin/sh
# Установка скина webui-speed как Alternative WebUI (public/ + private/).
# Демон метрик НЕ ставится — см. daemon/install.sh
set -e

SRC="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
DEST="${FK_WEBUI_ROOT:-/opt/etc/qBittorrent_entware/webui-speed}"

[ -f "$SRC/private/index.html" ] && [ -f "$SRC/public/index.html" ] || {
    echo "Нужны $SRC/private и $SRC/public"
    exit 1
}

mkdir -p "$DEST"
# не трогаем runtime JSON/маяки при обновлении темы
rm -rf "$DEST/private" "$DEST/public" "$DEST/translations"
cp -a "$SRC/private" "$DEST/private"
cp -a "$SRC/public" "$DEST/public"
if [ -d "$SRC/translations" ]; then
    cp -a "$SRC/translations" "$DEST/translations"
fi
cp "$SRC/version.txt" "$DEST/version.txt" 2>/dev/null || printf '%s\n' "webui-speed" > "$DEST/version.txt"
cp "$SRC/README.md" "$DEST/README.md" 2>/dev/null || true
# опциональный демон — копируем скрипты, но не запускаем
if [ -d "$SRC/daemon" ]; then
    rm -rf "$DEST/daemon"
    cp -a "$SRC/daemon" "$DEST/daemon"
    chmod +x "$DEST/daemon/fk-sysinfo-loop.sh" "$DEST/daemon/S90fk-sysinfo" "$DEST/daemon/install.sh" 2>/dev/null || true
fi
mkdir -p "$DEST/private/fk-want" 2>/dev/null || true
chmod -R a+rX "$DEST" 2>/dev/null || true

CONF=""
for c in \
    /opt/etc/qBittorrent_entware/config/qBittorrent.conf \
    /opt/etc/qBittorrent/config/qBittorrent.conf \
    /opt/root/.config/qBittorrent/qBittorrent.conf \
    "$HOME/.config/qBittorrent/qBittorrent.conf"
do
    [ -f "$c" ] && CONF="$c" && break
done

if [ -n "$CONF" ]; then
    if grep -q '^WebUI\\AlternativeUIEnabled=' "$CONF" 2>/dev/null; then
        sed -i 's|^WebUI\\AlternativeUIEnabled=.*|WebUI\\AlternativeUIEnabled=true|' "$CONF"
    else
        printf '%s\n' 'WebUI\AlternativeUIEnabled=true' >> "$CONF"
    fi
    if grep -q '^WebUI\\RootFolder=' "$CONF" 2>/dev/null; then
        sed -i "s|^WebUI\\\\RootFolder=.*|WebUI\\\\RootFolder=$DEST|" "$CONF"
    else
        printf '%s\n' "WebUI\\RootFolder=$DEST" >> "$CONF"
    fi
    echo "qBittorrent.conf: AlternativeUI → $DEST"
else
    echo "Конфиг qBittorrent не найден — укажите вручную:"
    echo "  WebUI → Use alternative WebUI → папка: $DEST"
fi

echo "Скин установлен. Ctrl+F5 в браузере."
echo "Метрики CPU/RAM роутера появятся только если запущен демон: sh $DEST/daemon/install.sh"
