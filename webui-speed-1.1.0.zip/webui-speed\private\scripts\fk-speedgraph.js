/*
 * Два независимых графика (как в µTorrent):
 *   session — слева: живые сэмплы + кольцо в RAM до 12 ч
 *   torrent — вкладка «Скорость»: localStorage, окно 12 ч
 * Кольцо: /tmp (fk-sg-hist.txt) ≤12 ч / 4 МБ → архив fk-sg-hist/seg-* (диск ≤20 МБ).
 * Подгрузка с диска — только если масштаб требует данных старше RAM.
 */
(function () {
    "use strict";

    var MAX_POINTS = 120;
    var MAX_SAMPLES = 4000;
    var SAMPLE_MIN_GAP_MS = 900;
    var PERSIST_EVERY_MS = 15000;
    var HIST_KEY_PREFIX = "fk_sg_th:";
    var HIST_INDEX_KEY = "fk_sg_th_index";
    var MAX_STORED_TORRENTS = 24;
    var RING_MS = 12 * 3600 * 1000;
    var RING_BUCKET_MS = 60000;
    var RING_LOAD_MIN = 30 * 1024; /* 30 КиБ/с — только для скорости; CPU/RAM не режем */

    /** точка кольца/истории: скорость выше порога или есть CPU/RAM/VMEM (порог только для скорости) */
    function ringKeepPoint(d, u, c, r, v) {
        if (Math.max(Number(d) || 0, Number(u) || 0) >= RING_LOAD_MIN)
            return true;
        if (c != null && !isNaN(Number(c)))
            return true;
        if (r != null && !isNaN(Number(r)))
            return true;
        if (v != null && !isNaN(Number(v)))
            return true;
        return false;
    }
    var RING_LS_KEY = "fk_sg_sess_ring_v1";
    var RING_URL = "fk-sg-hist.txt";
    var RING_MANIFEST_URL = "fk-sg-hist/manifest.txt";
    var RING_ARCH_DIR = "fk-sg-hist/";
    /* реже читаем диск: текущее кольцо раз в 10 мин; архивы — по запросу масштаба */
    var RING_FETCH_EVERY_MS = 600000;
    var RING_SAVE_EVERY_MS = 300000;
    var lastRingSaveAt = 0;
    var archLoaded = {}; /* seg name -> true */
    var ringFetchBusy = false;

    var RESOLUTIONS = [
        { id: "auto", ms: 0, label: "авто" },
        { id: "1m", ms: 60000, label: "1 мин" },
        { id: "2m", ms: 120000, label: "2 мин" },
        { id: "5m", ms: 300000, label: "5 мин" },
        { id: "10m", ms: 600000, label: "10 мин" },
        { id: "20m", ms: 1200000, label: "20 мин" },
        { id: "30m", ms: 1800000, label: "30 мин" },
        { id: "1h", ms: 3600000, label: "1 час" },
        { id: "2h", ms: 7200000, label: "2 часа" },
        { id: "3h", ms: 10800000, label: "3 часа" },
        { id: "5h", ms: 18000000, label: "5 часов" },
        { id: "10h", ms: 36000000, label: "10 часов" },
        { id: "1d", ms: 86400000, label: "Сутки" },
        { id: "full", ms: 0, label: "С начала загрузки" },
        /* устаревшие id — только для миграции localStorage */
        { id: "1s", ms: 1000, label: "1 с" },
        { id: "5s", ms: 5000, label: "5 с" },
        { id: "30s", ms: 30000, label: "30 с" }
    ];

    /**
     * «авто» (верхний график): окно от 2 мин, при превышении — следующее
     * фиксированное значение масштаба: 2→5→10→20→30м→1→2→3→5→10ч→сутки;
     * дальше кратно суткам.
     */
    var AUTO_STEPS_MS = [
        120000, 300000, 600000, 1200000, 1800000,
        3600000, 7200000, 10800000, 18000000, 36000000,
        86400000
    ];
    var AUTO_STEP_AFTER_1D = 86400000;

    function resMsOf(id) {
        for (var i = 0; i < RESOLUTIONS.length; i++) {
            if (RESOLUTIONS[i].id === id)
                return RESOLUTIONS[i].ms;
        }
        return 120000;
    }

    function isKnownRes(id) {
        for (var i = 0; i < RESOLUTIONS.length; i++) {
            if (RESOLUTIONS[i].id === id)
                return true;
        }
        return false;
    }

    function autoWindowMs(samples) {
        if (!samples || !samples.length)
            return AUTO_STEPS_MS[0];
        var span = Math.max(0, Date.now() - samples[0].t);
        var i;
        for (i = 0; i < AUTO_STEPS_MS.length; i++) {
            if (span <= AUTO_STEPS_MS[i])
                return AUTO_STEPS_MS[i];
        }
        return Math.ceil(span / AUTO_STEP_AFTER_1D) * AUTO_STEP_AFTER_1D;
    }

    function effectiveResMs(g) {
        if (!g)
            return 120000;
        if (g.resId === "auto")
            return autoWindowMs(g.samples);
        if (g.resId === "full")
            return 0;
        return resMsOf(g.resId);
    }

    function loadRes(key) {
        try {
            var v = localStorage.getItem(key);
            if (isKnownRes(v))
                return v;
        }
        catch (e) { /* ignore */ }
        return "auto";
    }

    function saveKV(key, val) {
        try { localStorage.setItem(key, val); }
        catch (e) { /* ignore */ }
    }

    function defaultFilt(withSys) {
        return { dl: true, ul: true, cpu: false, ram: false, vmem: false, sys: !!withSys };
    }

    function loadFilt(key, withSys) {
        var f = defaultFilt(withSys);
        try {
            var raw = localStorage.getItem(key);
            if (raw) {
                var o = JSON.parse(raw);
                if (o && typeof o === "object") {
                    f.dl = !!o.dl;
                    f.ul = !!o.ul;
                    if (withSys) {
                        f.cpu = !!o.cpu;
                        f.ram = !!o.ram;
                        f.vmem = !!o.vmem;
                    }
                }
            }
            else {
                // миграция со старого show
                var old = localStorage.getItem(key.replace("_filt", "_show"));
                if (old === "dl") { f.dl = true; f.ul = false; }
                else if (old === "ul") { f.dl = false; f.ul = true; }
            }
        }
        catch (e) { /* ignore */ }
        if (!f.dl && !f.ul && !f.cpu && !f.ram && !f.vmem)
            f.dl = true;
        return f;
    }

    function saveFilt(key, f) {
        try {
            localStorage.setItem(key, JSON.stringify({
                dl: !!f.dl, ul: !!f.ul, cpu: !!f.cpu, ram: !!f.ram, vmem: !!f.vmem
            }));
        }
        catch (e) { /* ignore */ }
    }

    function makeGraph(opts) {
        var withSys = !!opts.withSys;
        var rid = loadRes(opts.lsRes);
        return {
            filt: loadFilt(opts.lsFilt, withSys),
            resId: rid,
            resMs: rid === "auto" ? AUTO_STEPS_MS[0] : resMsOf(rid),
            lsFilt: opts.lsFilt,
            lsRes: opts.lsRes,
            filtersId: opts.filtersId,
            resSelect: opts.resSelect,
            withSys: withSys,
            samples: [],
            dl: [],
            ul: [],
            cpu: [],
            ram: [],
            vmem: [],
            viewPointMs: 1000,
            viewSpanMs: 0,
            yAxis: opts.yAxis,
            xAxis: opts.xAxis,
            canvas: opts.canvas,
            windowHint: opts.windowHint,
            legendDl: opts.legendDl,
            legendUl: opts.legendUl,
            legendCpu: opts.legendCpu || "",
            legendRam: opts.legendRam || "",
            legendVmem: opts.legendVmem || "",
            persist: !!opts.persist
        };
    }

    var session = makeGraph({
        lsFilt: "fk_sg_session_filt",
        lsRes: "fk_sg_session_res",
        filtersId: "fkSgFilters",
        resSelect: "fkSgRes",
        // CPU/RAM — только при демоне fk-sysinfo (включается setDaemonMetrics)
        withSys: false,
        yAxis: "fkSgYaxis",
        xAxis: "fkSgXaxis",
        canvas: "fkSgCanvas",
        windowHint: "fkSgWindow",
        legendDl: "fkSgDl",
        legendUl: "fkSgUl",
        legendCpu: "fkSgCpu",
        legendRam: "fkSgRam",
        persist: false
    });

    var torrent = makeGraph({
        lsFilt: "fk_sg_torrent_filt",
        lsRes: "fk_sg_torrent_res",
        filtersId: "fkTgFilters",
        resSelect: "fkTgRes",
        withSys: false,
        yAxis: "fkTgYaxis",
        xAxis: "fkTgXaxis",
        canvas: "fkTgCanvas",
        windowHint: "fkTgWindow",
        legendDl: "fkTgDl",
        legendUl: "fkTgUl",
        legendCpu: "fkTgCpu",
        legendRam: "fkTgRam",
        legendVmem: "fkTgVmem",
        persist: true
    });

    try {
        if (!localStorage.getItem("fk_sg_session_res") && localStorage.getItem("fk_sg_res")) {
            var old = localStorage.getItem("fk_sg_res");
            session.resId = isKnownRes(old) ? old : "auto";
            session.resMs = effectiveResMs(session);
            saveKV(session.lsRes, session.resId);
        }
    }
    catch (e) { /* ignore */ }

    var torrentHash = "";
    var lastPersistAt = 0;
    var lastSys = { cpu: null, ramPct: null, ramUsed: null, ramTotal: null };
    // qBit+демон (для графика торрента); RAM/VMEM в МБ и % от ОЗУ хоста
    var lastQbit = {
        cpu: null, ramMb: null, vmemMb: null, ramPct: null, vmemPct: null, vmemLive: false
    };
    var vmemAvailable = false;

    // IEC: минимум КиБ/с (Б/с не показываем)
    var KIB = 1024;
    var MIB = 1048576;
    var TIP_IEC =
        "КиБ / МиБ / ГиБ — двоичные (IEC): 1 КиБ = 1024 байт, 1 МиБ = 1024 КиБ, 1 ГиБ = 1024 МиБ.\n"
        + "КБ / МБ / ГБ — десятичные (СИ): 1 КБ = 1000 байт, 1 МБ = 1000 КБ, 1 ГБ = 1000 МБ.\n"
        + "Скорости здесь в КиБ·МиБ (×1024). 1 МиБ ≈ 1,05 МБ.";

    function applyIecTip(el) {
        if (!el)
            return;
        el.title = TIP_IEC;
        el.setAttribute("data-fk-iec-tip", "1");
    }

    function fmtSpeedParts(bytesPerSec) {
        var n = Number(bytesPerSec) || 0;
        if (n < MIB) {
            var kib = n / KIB;
            if (kib > 0 && kib < 10)
                return { v: kib.toFixed(1), u: " КиБ/с" };
            return { v: String(Math.round(kib)), u: " КиБ/с" };
        }
        if (n < 1073741824)
            return { v: (n / MIB).toFixed(n < 10485760 ? 2 : 1), u: " МиБ/с" };
        return { v: (n / 1073741824).toFixed(2), u: " ГиБ/с" };
    }

    function fmtSpeed(bytesPerSec) {
        var p = fmtSpeedParts(bytesPerSec);
        return p.v + p.u;
    }

    function setSpeedLegend(id, bytesPerSec) {
        var el = document.getElementById(id);
        if (!el)
            return;
        var n = Number(bytesPerSec) || 0;
        var p = fmtSpeedParts(n);
        el.textContent = p.v;
        var wrap = el.parentElement;
        var unit = wrap ? wrap.querySelector(".fk-sg-unit") : null;
        /* при 0 — без «КиБ/с» / «МиБ/с»; единицы только когда скорость > 0 */
        if (unit)
            unit.textContent = n > 0 ? p.u : "";
        else
            el.textContent = n > 0 ? (p.v + p.u) : p.v;
        if (wrap)
            wrap.title = n > 0 ? (p.v + p.u) : p.v;
        if (wrap)
            wrap.classList.toggle("fk-sg-speed-zero", n <= 0);
    }

    /** при узкой шторке — спрятать «КиБ/с» / «МиБ/с» у ↓/↑ */
    function syncLegendUnitsCompact() {
        function apply(root) {
            if (!root)
                return;
            root.classList.remove("fk-sg-hide-units");
            var head = root.querySelector(".fk-sg-head");
            var speeds = root.querySelector(".fk-sg-speeds");
            if (!head)
                return;
            var cramped = (head.scrollWidth > head.clientWidth + 1)
                || (speeds && speeds.scrollWidth > speeds.clientWidth + 1);
            root.classList.toggle("fk-sg-hide-units", cramped);
        }
        apply(document.getElementById("fkSessionSpeed"));
        apply(document.getElementById("fkTorrentSpeed"));
    }

    function fmtAxisSpeed(bytesPerSec) {
        var n = Number(bytesPerSec) || 0;
        var mib = n / MIB;
        if (mib >= 10 || Math.abs(mib - Math.round(mib)) < 0.05)
            return Math.round(mib) + " МиБ/с";
        if (mib >= 1)
            return mib.toFixed(1) + " МиБ/с";
        var kib = n / KIB;
        if (kib > 0 && kib < 10)
            return kib.toFixed(1) + " КиБ/с";
        return Math.round(kib) + " КиБ/с";
    }

    /** ступени Y: КиБ → МиБ */
    function speedScaleMax(peakBytes) {
        var peak = Number(peakBytes) || 0;
        var kib = peak / KIB;
        if (kib <= 10)
            return 10 * KIB;
        if (kib <= 50)
            return 50 * KIB;
        if (kib <= 100)
            return 100 * KIB;
        if (kib <= 500)
            return 500 * KIB;
        var mib = peak / MIB;
        if (mib <= 1)
            return MIB;
        if (mib <= 5)
            return 5 * MIB;
        if (mib <= 10)
            return 10 * MIB;
        if (mib <= 20)
            return 20 * MIB;
        if (mib <= 50)
            return 50 * MIB;
        if (mib <= 100)
            return 100 * MIB;
        var top = 200;
        while (mib > top)
            top += 100;
        return top * MIB;
    }

    function fmtTimeAgo(secondsAgo) {
        var s = Math.max(0, Math.round(secondsAgo));
        if (s <= 0)
            return "сейчас";
        if (s < 60)
            return "−" + s + " с";
        var m = Math.round(s / 60);
        if (m < 60)
            return "−" + m + " м";
        var h = s / 3600;
        if (h < 48) {
            if (h < 10 && Math.abs(h - Math.round(h)) > 0.05)
                return "−" + h.toFixed(1).replace(/\.0$/, "") + " ч";
            return "−" + Math.round(h) + " ч";
        }
        var d = s / 86400;
        if (d < 10 && Math.abs(d - Math.round(d)) > 0.05)
            return "−" + d.toFixed(1).replace(/\.0$/, "") + " д";
        return "−" + Math.round(d) + " д";
    }

    function avgNullable(a, b) {
        if (a == null && b == null)
            return null;
        if (a == null)
            return b;
        if (b == null)
            return a;
        return (a + b) / 2;
    }

    function downsampleInPlace(arr) {
        if (arr.length < 2)
            return;
        var out = [];
        for (var i = 0; i < arr.length; i += 2) {
            if (i + 1 < arr.length) {
                out.push({
                    t: Math.round((arr[i].t + arr[i + 1].t) / 2),
                    d: (arr[i].d + arr[i + 1].d) / 2,
                    u: (arr[i].u + arr[i + 1].u) / 2,
                    c: avgNullable(arr[i].c, arr[i + 1].c),
                    r: avgNullable(arr[i].r, arr[i + 1].r),
                    v: avgNullable(arr[i].v, arr[i + 1].v)
                });
            }
            else {
                out.push(arr[i]);
            }
        }
        arr.length = 0;
        for (var j = 0; j < out.length; j++)
            arr.push(out[j]);
    }

    /** сколько держать в session.samples: не короче RAM-кольца; для длинного масштаба — шире */
    function sessionKeepMs() {
        var span = 0;
        try { span = effectiveResMs(session) || 0; }
        catch (e) { span = 0; }
        if (span <= 0)
            return Math.max(RING_MS, 24 * 3600 * 1000);
        return Math.max(RING_MS, span);
    }

    function trimSamplesWindow(samples, winMs) {
        if (!samples || !samples.length)
            return;
        var keep = winMs;
        if (keep == null || keep <= 0)
            keep = (samples === session.samples) ? sessionKeepMs() : RING_MS;
        var cut = Date.now() - keep;
        while (samples.length && samples[0].t < cut)
            samples.shift();
    }

    /** кольцо: минута с скоростью >30 КиБ/с и/или с CPU/RAM */
    var ringAcc = { t0: 0, n: 0, d: 0, u: 0, c: 0, cn: 0, r: 0, rn: 0 };
    var ringCache = []; /* {t,d,u,c,r} */
    var lastRingFetchAt = 0;
    var sessionRingReady = false;

    function ringPack(list) {
        var out = new Array(list.length);
        var i;
        for (i = 0; i < list.length; i++) {
            var s = list[i];
            out[i] = [
                Math.round(s.t / 1000),
                Math.round(s.d),
                Math.round(s.u),
                s.c == null ? -1 : Math.round(s.c * 10),
                s.r == null ? -1 : Math.round(s.r * 10)
            ];
        }
        return out;
    }

    function ringUnpack(packed) {
        var out = [];
        if (!packed || !packed.length)
            return out;
        var i;
        for (i = 0; i < packed.length; i++) {
            var p = packed[i];
            if (!p || p.length < 3)
                continue;
            var t = Number(p[0]) * 1000;
            if (!t)
                continue;
            out.push({
                t: t,
                d: Number(p[1]) || 0,
                u: Number(p[2]) || 0,
                c: p[3] != null && Number(p[3]) >= 0 ? Number(p[3]) / 10 : null,
                r: p[4] != null && Number(p[4]) >= 0 ? Number(p[4]) / 10 : null,
                v: null
            });
        }
        return out;
    }

    function saveRingLocal(force) {
        var now = Date.now();
        if (!force && lastRingSaveAt && now - lastRingSaveAt < RING_SAVE_EVERY_MS)
            return;
        try {
            trimSamplesWindow(ringCache, RING_MS);
            localStorage.setItem(RING_LS_KEY, JSON.stringify({ v: 1, s: ringPack(ringCache) }));
            lastRingSaveAt = now;
        }
        catch (e) { /* ignore */ }
    }

    function loadRingLocal() {
        try {
            var raw = localStorage.getItem(RING_LS_KEY);
            if (!raw)
                return [];
            var o = JSON.parse(raw);
            return ringUnpack(o && o.s);
        }
        catch (e) {
            return [];
        }
    }

    function parseRingText(text) {
        var out = [];
        if (!text)
            return out;
        var lines = String(text).split(/\n+/);
        var i;
        for (i = 0; i < lines.length; i++) {
            var line = lines[i].replace(/^\s+|\s+$/g, "");
            if (!line || line.charAt(0) === "#")
                continue;
            var p = line.split(/\s+/);
            if (p.length < 3)
                continue;
            var t = Number(p[0]) * 1000;
            if (!t)
                continue;
            var c = p[3] != null && p[3] !== "-" ? Number(p[3]) : null;
            var r = p[4] != null && p[4] !== "-" ? Number(p[4]) : null;
            out.push({
                t: t,
                d: Number(p[1]) || 0,
                u: Number(p[2]) || 0,
                c: c != null && !isNaN(c) ? c : null,
                r: r != null && !isNaN(r) ? r : null,
                v: null
            });
        }
        return out;
    }

    /** дописать минутные точки кольца, не трогая уже есть плотные живые сэмплы */
    function mergeRingInto(list, samples) {
        if (!list || !list.length || !samples)
            return;
        var have = {};
        var i;
        for (i = 0; i < samples.length; i++)
            have[Math.floor(samples[i].t / RING_BUCKET_MS)] = 1;
        var added = 0;
        for (i = 0; i < list.length; i++) {
            var p = list[i];
            if (!ringKeepPoint(p.d, p.u, p.c, p.r, p.v))
                continue;
            var k = Math.floor(p.t / RING_BUCKET_MS);
            if (have[k])
                continue;
            samples.push({
                t: k * RING_BUCKET_MS + RING_BUCKET_MS / 2,
                d: p.d,
                u: p.u,
                c: p.c,
                r: p.r,
                v: null
            });
            have[k] = 1;
            added += 1;
        }
        if (!added)
            return;
        samples.sort(function (a, b) { return a.t - b.t; });
        trimSamplesWindow(samples, samples === session.samples ? sessionKeepMs() : RING_MS);
    }

    function mergeRingCache(list) {
        if (!list || !list.length)
            return;
        var i;
        for (i = 0; i < list.length; i++)
            upsertRingPoint(list[i]);
    }

    function upsertRingPoint(pt) {
        if (!pt || !ringKeepPoint(pt.d, pt.u, pt.c, pt.r, pt.v))
            return;
        var k = Math.floor(pt.t / RING_BUCKET_MS);
        var tMid = k * RING_BUCKET_MS + RING_BUCKET_MS / 2;
        var i;
        for (i = ringCache.length - 1; i >= 0; i--) {
            if (Math.floor(ringCache[i].t / RING_BUCKET_MS) === k) {
                ringCache[i] = { t: tMid, d: pt.d, u: pt.u, c: pt.c, r: pt.r, v: null };
                trimSamplesWindow(ringCache, RING_MS);
                return;
            }
            if (ringCache[i].t < tMid - RING_BUCKET_MS)
                break;
        }
        ringCache.push({ t: tMid, d: pt.d, u: pt.u, c: pt.c, r: pt.r, v: null });
        ringCache.sort(function (a, b) { return a.t - b.t; });
        trimSamplesWindow(ringCache, RING_MS);
    }

    function flushRingAcc() {
        if (!ringAcc.n || !ringAcc.t0)
            return;
        var d = ringAcc.d / ringAcc.n;
        var u = ringAcc.u / ringAcc.n;
        var cAvg = ringAcc.cn ? ringAcc.c / ringAcc.cn : null;
        var rAvg = ringAcc.rn ? ringAcc.r / ringAcc.rn : null;
        if (!ringKeepPoint(d, u, cAvg, rAvg, null)) {
            ringAcc = { t0: 0, n: 0, d: 0, u: 0, c: 0, cn: 0, r: 0, rn: 0 };
            return;
        }
        var pt = {
            t: ringAcc.t0 + RING_BUCKET_MS / 2,
            d: d,
            u: u,
            c: cAvg,
            r: rAvg,
            v: null
        };
        upsertRingPoint(pt);
        mergeRingInto([pt], session.samples);
        saveRingLocal(false);
        ringAcc.t0 = 0;
        ringAcc.n = 0;
        ringAcc.d = 0;
        ringAcc.u = 0;
        ringAcc.c = 0;
        ringAcc.cn = 0;
        ringAcc.r = 0;
        ringAcc.rn = 0;
    }

    function noteSessionRing(t, d, u, c, r) {
        var bucket = Math.floor(t / RING_BUCKET_MS) * RING_BUCKET_MS;
        if (ringAcc.t0 && ringAcc.t0 !== bucket)
            flushRingAcc();
        if (!ringAcc.t0) {
            ringAcc.t0 = bucket;
            ringAcc.n = 0;
            ringAcc.d = 0;
            ringAcc.u = 0;
            ringAcc.c = 0;
            ringAcc.cn = 0;
            ringAcc.r = 0;
            ringAcc.rn = 0;
        }
        ringAcc.n += 1;
        ringAcc.d += d;
        ringAcc.u += u;
        if (c != null && !isNaN(c)) {
            ringAcc.c += c;
            ringAcc.cn += 1;
        }
        if (r != null && !isNaN(r)) {
            ringAcc.r += r;
            ringAcc.rn += 1;
        }
    }

    function applyRingList(list, forceSave) {
        if (!list || !list.length)
            return;
        mergeRingCache(list);
        mergeRingInto(list, session.samples);
        saveRingLocal(!!forceSave);
    }

    function fetchRouterRing(cb) {
        if (ringFetchBusy) {
            if (cb)
                cb([]);
            return;
        }
        ringFetchBusy = true;
        fetch(RING_URL + "?t=" + Date.now(), { cache: "no-store", credentials: "same-origin" })
            .then(function (r) { return r.ok ? r.text() : ""; })
            .then(function (text) {
                lastRingFetchAt = Date.now();
                ringFetchBusy = false;
                cb(parseRingText(text));
            })
            .catch(function () {
                lastRingFetchAt = Date.now();
                ringFetchBusy = false;
                cb([]);
            });
    }

    function parseManifest(text) {
        var out = [];
        if (!text)
            return out;
        var lines = String(text).split(/\n+/);
        var i;
        for (i = 0; i < lines.length; i++) {
            var line = lines[i].replace(/^\s+|\s+$/g, "");
            if (!line || line.charAt(0) === "#")
                continue;
            var p = line.split(/\s+/);
            if (p.length < 4)
                continue;
            out.push({
                t0: Number(p[0]) * 1000,
                t1: Number(p[1]) * 1000,
                bytes: Number(p[2]) || 0,
                name: p[3]
            });
        }
        return out;
    }

    /** архивы с диска — только сегменты, пересекающие [now-needMs, now-RING_MS] */
    function fetchArchSegments(needMs, cb) {
        var now = Date.now();
        var from = now - needMs;
        var to = now - RING_MS + RING_BUCKET_MS;
        if (from >= to) {
            if (cb)
                cb();
            return;
        }
        fetch(RING_MANIFEST_URL + "?t=" + now, { cache: "no-store", credentials: "same-origin" })
            .then(function (r) { return r.ok ? r.text() : ""; })
            .then(function (text) {
                var segs = parseManifest(text);
                var want = [];
                var i;
                for (i = 0; i < segs.length; i++) {
                    var s = segs[i];
                    if (!s.name || archLoaded[s.name])
                        continue;
                    if (s.t1 < from || s.t0 > to)
                        continue;
                    want.push(s.name);
                }
                if (!want.length) {
                    if (cb)
                        cb();
                    return;
                }
                var left = want.length;
                want.forEach(function (name) {
                    fetch(RING_ARCH_DIR + name + "?t=" + now, {
                        cache: "no-store",
                        credentials: "same-origin"
                    })
                        .then(function (r) { return r.ok ? r.text() : ""; })
                        .then(function (body) {
                            archLoaded[name] = true;
                            applyRingList(parseRingText(body), false);
                            left -= 1;
                            if (left <= 0 && cb)
                                cb();
                        })
                        .catch(function () {
                            left -= 1;
                            if (left <= 0 && cb)
                                cb();
                        });
                });
            })
            .catch(function () {
                if (cb)
                    cb();
            });
    }

    /**
     * подтянуть историю под окно масштаба:
     * — текущее кольцо (RAM/WWW) редко;
     * — архивы с диска только если окно > 12 ч или дыра в покрытии.
     */
    function ensureSessionHistory(spanMs, cb) {
        var need = spanMs > 0 ? spanMs : RING_MS * 2;
        var now = Date.now();
        var cover = session.samples.length ? now - session.samples[0].t : 0;
        var needRemote = !sessionRingReady
            || now - lastRingFetchAt >= RING_FETCH_EVERY_MS
            || (need > cover * 0.85 && now - lastRingFetchAt > 8000);
        var needArch = need > RING_MS || (session.samples.length && cover < need * 0.9 && need > 3600000);

        function afterRing() {
            if (needArch)
                fetchArchSegments(need, cb);
            else if (cb)
                cb();
        }

        if (needRemote) {
            fetchRouterRing(function (remote) {
                applyRingList(remote, true);
                afterRing();
            });
        }
        else
            afterRing();
    }

    function hydrateSessionRing(done) {
        ringCache = loadRingLocal();
        mergeRingInto(ringCache, session.samples);
        ensureSessionHistory(effectiveResMs(session) || AUTO_STEPS_MS[0], function () {
            sessionRingReady = true;
            if (done)
                done();
        });
    }

    function pushSample(samples, t, dl, ul, cpu, ram, vmem) {
        var d = Number(dl) || 0;
        var u = Number(ul) || 0;
        var c = cpu == null || isNaN(Number(cpu)) ? null : Number(cpu);
        var r = ram == null || isNaN(Number(ram)) ? null : Number(ram);
        var v = vmem == null || isNaN(Number(vmem)) ? null : Number(vmem);
        if (samples.length) {
            var last = samples[samples.length - 1];
            if (t - last.t < SAMPLE_MIN_GAP_MS) {
                last.t = t;
                last.d = d;
                last.u = u;
                if (c != null)
                    last.c = c;
                if (r != null)
                    last.r = r;
                if (v != null)
                    last.v = v;
                if (samples === session.samples)
                    noteSessionRing(t, d, u, c, r);
                return;
            }
        }
        samples.push({ t: t, d: d, u: u, c: c, r: r, v: v });
        trimSamplesWindow(samples, samples === session.samples ? sessionKeepMs() : RING_MS);
        while (samples.length > MAX_SAMPLES)
            downsampleInPlace(samples);
        if (samples === session.samples)
            noteSessionRing(t, d, u, c, r);
    }

    function clearSamples(g) {
        g.samples.length = 0;
        g.dl.length = 0;
        g.ul.length = 0;
        g.cpu.length = 0;
        g.ram.length = 0;
        g.vmem.length = 0;
        g.viewPointMs = g.resMs || 1000;
        g.viewSpanMs = 0;
    }

    function readHistIndex() {
        try {
            var raw = localStorage.getItem(HIST_INDEX_KEY);
            if (!raw)
                return [];
            var arr = JSON.parse(raw);
            return Array.isArray(arr) ? arr : [];
        }
        catch (e) {
            return [];
        }
    }

    function writeHistIndex(list) {
        try { localStorage.setItem(HIST_INDEX_KEY, JSON.stringify(list)); }
        catch (e) { /* ignore */ }
    }

    function touchHistIndex(hash) {
        var list = readHistIndex().filter(function (h) { return h !== hash; });
        list.push(hash);
        while (list.length > MAX_STORED_TORRENTS) {
            var drop = list.shift();
            try { localStorage.removeItem(HIST_KEY_PREFIX + drop); }
            catch (e) { /* ignore */ }
        }
        writeHistIndex(list);
    }

    /** для хранения: 1-мин ведра; скорость >30 КиБ/с и/или CPU/RAM, окно 5 ч */
    function compactSamplesForStore(samples) {
        var cut = Date.now() - RING_MS;
        var buckets = {};
        var i;
        for (i = 0; i < samples.length; i++) {
            var s = samples[i];
            if (s.t < cut)
                continue;
            var k = Math.floor(s.t / RING_BUCKET_MS);
            var b = buckets[k];
            if (!b) {
                buckets[k] = { n: 1, d: s.d, u: s.u, c: s.c, cn: s.c != null ? 1 : 0, r: s.r, rn: s.r != null ? 1 : 0, v: s.v, vn: s.v != null ? 1 : 0 };
            }
            else {
                b.n += 1;
                b.d += s.d;
                b.u += s.u;
                if (s.c != null) { b.c = (b.c || 0) + s.c; b.cn += 1; }
                if (s.r != null) { b.r = (b.r || 0) + s.r; b.rn += 1; }
                if (s.v != null) { b.v = (b.v || 0) + s.v; b.vn += 1; }
            }
        }
        var keys = Object.keys(buckets);
        keys.sort(function (a, b) { return Number(a) - Number(b); });
        var out = [];
        for (i = 0; i < keys.length; i++) {
            var bk = buckets[keys[i]];
            var d = bk.d / bk.n;
            var u = bk.u / bk.n;
            var c = bk.cn ? bk.c / bk.cn : null;
            var r = bk.rn ? bk.r / bk.rn : null;
            var v = bk.vn ? bk.v / bk.vn : null;
            if (!ringKeepPoint(d, u, c, r, v))
                continue;
            out.push({
                t: Number(keys[i]) * RING_BUCKET_MS + RING_BUCKET_MS / 2,
                d: d,
                u: u,
                c: c,
                r: r,
                v: v
            });
        }
        return out;
    }

    function persistTorrentHistory(hash, samples, force) {
        if (!hash || !samples)
            return;
        var now = Date.now();
        if (!force && now - lastPersistAt < PERSIST_EVERY_MS)
            return;
        lastPersistAt = now;
        var compact = compactSamplesForStore(samples);
        try {
            var packed = new Array(compact.length);
            for (var i = 0; i < compact.length; i++) {
                var s = compact[i];
                packed[i] = [s.t, Math.round(s.d), Math.round(s.u),
                    s.c == null ? -1 : Math.round(s.c * 10),
                    s.r == null ? -1 : Math.round(s.r * 10),
                    s.v == null ? -1 : Math.round(s.v * 10)];
            }
            localStorage.setItem(HIST_KEY_PREFIX + hash, JSON.stringify({ v: 2, s: packed }));
            touchHistIndex(hash);
        }
        catch (e) {
            try {
                while (compact.length > 300)
                    compact.shift();
                var packed2 = new Array(compact.length);
                for (var j = 0; j < compact.length; j++) {
                    var s2 = compact[j];
                    packed2[j] = [s2.t, Math.round(s2.d), Math.round(s2.u)];
                }
                localStorage.setItem(HIST_KEY_PREFIX + hash, JSON.stringify({ v: 2, s: packed2 }));
                touchHistIndex(hash);
            }
            catch (e2) { /* ignore */ }
        }
    }

    function loadTorrentHistory(hash) {
        if (!hash)
            return [];
        try {
            var raw = localStorage.getItem(HIST_KEY_PREFIX + hash);
            if (!raw)
                return [];
            var obj = JSON.parse(raw);
            if (!obj || !Array.isArray(obj.s))
                return [];
            var cut = Date.now() - RING_MS;
            var out = [];
            for (var i = 0; i < obj.s.length; i++) {
                var row = obj.s[i];
                if (!row || row.length < 3)
                    continue;
                var t = Number(row[0]) || 0;
                var d = Number(row[1]) || 0;
                var u = Number(row[2]) || 0;
                var c = row[3] != null && Number(row[3]) >= 0 ? Number(row[3]) / 10 : null;
                var r = row[4] != null && Number(row[4]) >= 0 ? Number(row[4]) / 10 : null;
                var v = row[5] != null && Number(row[5]) >= 0 ? Number(row[5]) / 10 : null;
                if (t < cut)
                    continue;
                if (!ringKeepPoint(d, u, c, r, v))
                    continue;
                out.push({ t: t, d: d, u: u, c: c, r: r, v: v });
            }
            return out;
        }
        catch (e) {
            return [];
        }
    }

    function averageInRange(samples, fromIdx, t0, t1) {
        var sumD = 0;
        var sumU = 0;
        var sumC = 0;
        var sumR = 0;
        var sumV = 0;
        var n = 0;
        var nC = 0;
        var nR = 0;
        var nV = 0;
        for (var i = fromIdx; i < samples.length; i++) {
            var s = samples[i];
            if (s.t < t0)
                continue;
            if (s.t >= t1)
                break;
            sumD += s.d;
            sumU += s.u;
            n++;
            if (s.c != null) { sumC += s.c; nC++; }
            if (s.r != null) { sumR += s.r; nR++; }
            if (s.v != null) { sumV += s.v; nV++; }
        }
        if (!n)
            return null;
        return {
            d: sumD / n,
            u: sumU / n,
            c: nC ? sumC / nC : null,
            r: nR ? sumR / nR : null,
            v: nV ? sumV / nV : null
        };
    }

    function findFirstIndexAtOrAfter(samples, t) {
        var lo = 0;
        var hi = samples.length;
        while (lo < hi) {
            var mid = (lo + hi) >> 1;
            if (samples[mid].t < t)
                lo = mid + 1;
            else
                hi = mid;
        }
        return lo;
    }

    function sampleAtOrInterp(samples, t) {
        if (!samples.length)
            return { d: 0, u: 0, c: null, r: null, v: null };
        var i = findFirstIndexAtOrAfter(samples, t);
        if (i <= 0)
            return { d: samples[0].d, u: samples[0].u, c: samples[0].c, r: samples[0].r, v: samples[0].v };
        if (i >= samples.length) {
            var L = samples[samples.length - 1];
            return { d: L.d, u: L.u, c: L.c, r: L.r, v: L.v };
        }
        var a = samples[i - 1];
        var b = samples[i];
        if (b.t === a.t)
            return { d: b.d, u: b.u, c: b.c, r: b.r, v: b.v };
        var k = (t - a.t) / (b.t - a.t);
        if (k < 0)
            k = 0;
        if (k > 1)
            k = 1;
        return {
            d: a.d + (b.d - a.d) * k,
            u: a.u + (b.u - a.u) * k,
            c: (a.c == null || b.c == null) ? (a.c != null ? a.c : b.c) : (a.c + (b.c - a.c) * k),
            r: (a.r == null || b.r == null) ? (a.r != null ? a.r : b.r) : (a.r + (b.r - a.r) * k),
            v: (a.v == null || b.v == null) ? (a.v != null ? a.v : b.v) : (a.v + (b.v - a.v) * k)
        };
    }

    /** число точек от ширины canvas — шире график → выше плотность */
    function bucketsForGraph(g) {
        var canvas = document.getElementById(g.canvas);
        var w = 200;
        if (canvas) {
            var sz = canvasCssSize(canvas);
            w = sz.cssW;
        }
        return Math.max(48, Math.min(400, Math.round(w / 2.2)));
    }

    /**
     * Справа → налево (все графики):
     *  — правый край оси X всегда = «сейчас»;
     *  — пока истории меньше окна: пусто слева, линия у правого края;
     *  — когда окно заполнено: скролл влево.
     */
    function rebuildView(g) {
        var samples = g.samples;
        var now = Date.now();
        g.dl.length = 0;
        g.ul.length = 0;
        g.cpu.length = 0;
        g.ram.length = 0;
        g.vmem.length = 0;

        var buckets = bucketsForGraph(g);
        var winMs = effectiveResMs(g);
        var full = g.resId === "full";
        var t0;
        var tEnd;
        var span;
        var pointMs;
        var dataEnd = now;

        if (full) {
            if (!samples.length) {
                g.viewPointMs = 1000;
                g.viewSpanMs = 0;
                return;
            }
            t0 = samples[0].t;
            tEnd = Math.max(samples[samples.length - 1].t, now);
            dataEnd = tEnd;
            span = Math.max(1000, tEnd - t0);
        }
        else {
            span = winMs > 0 ? winMs : 60000;
            g.resMs = span;
            /* всегда: «сейчас» справа, история уходит влево */
            tEnd = now;
            t0 = now - span;
            dataEnd = now;
        }

        pointMs = span / Math.max(1, buckets - 1);
        g.viewSpanMs = span;
        g.viewPointMs = pointMs;

        var firstT = samples.length ? samples[0].t : null;
        var lastT = samples.length ? samples[samples.length - 1].t : null;
        /* CPU/RAM/VMEM держим между точками — не зависят от порога 30 КиБ/с */
        var holdC = null;
        var holdR = null;
        var holdV = null;

        for (var i = 0; i < buckets; i++) {
            var t = t0 + i * pointMs;
            var b0 = (i === 0) ? t0 : (t - pointMs / 2);
            var b1 = (i === buckets - 1) ? (tEnd + 1) : (t + pointMs / 2);

            if (!samples.length || firstT == null || b1 < firstT) {
                g.dl.push(null);
                g.ul.push(null);
                g.cpu.push(null);
                g.ram.push(null);
                g.vmem.push(null);
                continue;
            }

            var avg = averageInRange(samples, findFirstIndexAtOrAfter(samples, b0), b0, Math.min(b1, dataEnd + 1));
            /* скорость — только точка в пределах 1 мин; sys-метрики — nearest + hold */
            if (!avg && t <= dataEnd && lastT != null) {
                var iNear = findFirstIndexAtOrAfter(samples, t);
                var cand = null;
                var dtBest = RING_BUCKET_MS + 1;
                if (iNear < samples.length) {
                    dtBest = Math.abs(samples[iNear].t - t);
                    cand = samples[iNear];
                }
                if (iNear > 0) {
                    var dt0 = Math.abs(samples[iNear - 1].t - t);
                    if (dt0 < dtBest) {
                        dtBest = dt0;
                        cand = samples[iNear - 1];
                    }
                }
                if (cand && dtBest <= RING_BUCKET_MS)
                    avg = { d: cand.d, u: cand.u, c: cand.c, r: cand.r, v: cand.v };
                else if (cand) {
                    /* далеко для скорости, но CPU/RAM/VMEM всё равно берём */
                    avg = {
                        d: null,
                        u: null,
                        c: cand.c,
                        r: cand.r,
                        v: cand.v
                    };
                }
            }
            if (!avg) {
                g.dl.push(null);
                g.ul.push(null);
                g.cpu.push(holdC);
                g.ram.push(holdR);
                g.vmem.push(holdV);
            }
            else {
                if (avg.d != null && avg.u != null) {
                    g.dl.push(avg.d);
                    g.ul.push(avg.u);
                }
                else {
                    g.dl.push(null);
                    g.ul.push(null);
                }
                if (avg.c != null)
                    holdC = avg.c;
                if (avg.r != null)
                    holdR = avg.r;
                if (avg.v != null)
                    holdV = avg.v;
                g.cpu.push(avg.c != null ? avg.c : holdC);
                g.ram.push(avg.r != null ? avg.r : holdR);
                g.vmem.push(avg.v != null ? avg.v : holdV);
            }
        }
    }

    function histPeak(a, b) {
        var max = 0;
        var i;
        for (i = 0; i < a.length; i++) {
            if (a[i] != null && a[i] > max)
                max = a[i];
        }
        for (i = 0; i < b.length; i++) {
            if (b[i] != null && b[i] > max)
                max = b[i];
        }
        return max;
    }

    function histMax(a, b) {
        var peak = histPeak(a, b);
        if (peak <= 0)
            return 0;
        return speedScaleMax(peak);
    }

    function setText(id, text) {
        var el = document.getElementById(id);
        if (!el)
            return;
        el.textContent = text;
        if (/[КМГT]иБ|KiB|MiB|GiB|TiB/i.test(String(text)))
            applyIecTip(el);
    }

    function setAxisY(id, max, pctMode) {
        var box = document.getElementById(id);
        if (!box)
            return;
        var spans = box.querySelectorAll("span");
        var showSpeed = !pctMode && Number(max) > 0;
        var side = document.getElementById("fkSessionSpeed");
        if (side && id === "fkSgYaxis")
            side.classList.toggle("fk-sg-axis-slim", !showSpeed);
        if (spans.length >= 3) {
            if (pctMode) {
                /* 100% справа; слева только середина — без «0» снизу */
                spans[0].textContent = "";
                spans[1].textContent = Math.round(max / 2) + " %";
                spans[2].textContent = "";
                box.removeAttribute("title");
            }
            else if (!showSpeed) {
                /* нет скорости — без обозначений и без «0» */
                spans[0].textContent = "";
                spans[1].textContent = "";
                spans[2].textContent = "";
                box.removeAttribute("title");
            }
            else {
                spans[0].textContent = fmtAxisSpeed(max);
                spans[1].textContent = fmtAxisSpeed(max / 2);
                spans[2].textContent = "0";
                applyIecTip(box);
            }
        }
    }

    function syncPctAxis(g, pctOn) {
        var plot = null;
        var canvas = document.getElementById(g.canvas);
        if (canvas) {
            var wrap = canvas.parentElement;
            plot = wrap && wrap.classList.contains("fk-sg-canvas-wrap")
                ? wrap.parentElement
                : (canvas.closest ? canvas.closest(".fk-sg-plot") : null);
        }
        if (!plot)
            return;
        var pctEl = plot.querySelector(".fk-sg-yaxis-pct");
        if (!pctEl) {
            pctEl = document.createElement("div");
            pctEl.className = "fk-sg-yaxis-pct";
            pctEl.setAttribute("aria-hidden", "true");
            pctEl.innerHTML = "<span>100%</span>";
            plot.appendChild(pctEl);
        }
        pctEl.classList.toggle("invisible", !pctOn);
        plot.classList.toggle("fk-sg-has-pct", !!pctOn);
        var root = plot.closest ? plot.closest(".fk-sg-sidebar, .fk-sg-torrent") : null;
        if (root)
            root.classList.toggle("fk-sg-has-pct-axis", !!pctOn);
    }

    function setAxisX(id, spanMs) {
        var box = document.getElementById(id);
        if (!box)
            return;
        var spanSec = Math.max(0, spanMs / 1000);
        var spans = box.querySelectorAll("span");
        if (spans.length >= 3) {
            spans[0].textContent = spanSec ? fmtTimeAgo(spanSec) : "0 с";
            spans[1].textContent = spanSec ? fmtTimeAgo(spanSec / 2) : "";
            spans[2].textContent = "сейчас";
        }
    }

    function canvasCssSize(canvas) {
        var wrap = canvas.parentElement;
        var plot = wrap;
        if (wrap && wrap.classList.contains("fk-sg-canvas-wrap"))
            plot = wrap.parentElement;
        var rect = canvas.getBoundingClientRect();
        var cssW = Math.floor(rect.width || canvas.clientWidth || 0);
        var cssH = Math.floor(rect.height || canvas.clientHeight || 0);
        if ((cssW < 20 || cssH < 20) && plot) {
            var pr = plot.getBoundingClientRect();
            var yaxis = plot.querySelector(".fk-sg-yaxis");
            var ypct = plot.querySelector(".fk-sg-yaxis-pct:not(.invisible)");
            var yw = yaxis ? yaxis.getBoundingClientRect().width : 52;
            /* в сайдбаре 100% поверх холста — ширину не вычитаем */
            var side = plot.closest && plot.closest(".fk-sg-sidebar");
            var pw = (!side && ypct) ? ypct.getBoundingClientRect().width : 0;
            if (cssW < 20)
                cssW = Math.floor(pr.width - yw - pw - 4);
            if (cssH < 20)
                cssH = Math.floor(pr.height);
        }
        if (cssW < 20)
            cssW = 160;
        if (cssH < 20)
            cssH = 90;
        return { cssW: cssW, cssH: cssH };
    }

    function drawSeries(ctx, hist, max, cssW, cssH, stroke, fill) {
        if (!hist.length)
            return null;
        var denom = Math.max(1, hist.length - 1);
        var xOf = function (j) { return (j / denom) * (cssW - 1); };
        var yOf = function (v) { return (cssH - 1) - (v / max) * (cssH - 1); };

        var segStart = -1;
        var lastValid = -1;
        var s;

        function strokeSeg(from, to) {
            if (from < 0 || to < from)
                return;
            if (fill) {
                ctx.beginPath();
                ctx.moveTo(xOf(from), cssH - 1);
                for (s = from; s <= to; s++)
                    ctx.lineTo(xOf(s), yOf(hist[s]));
                ctx.lineTo(xOf(to), cssH - 1);
                ctx.closePath();
                ctx.fillStyle = fill;
                ctx.fill();
            }
            ctx.beginPath();
            ctx.strokeStyle = stroke;
            ctx.lineWidth = 1.5;
            ctx.lineJoin = "round";
            ctx.lineCap = "round";
            for (s = from; s <= to; s++) {
                if (s === from)
                    ctx.moveTo(xOf(s), yOf(hist[s]));
                else
                    ctx.lineTo(xOf(s), yOf(hist[s]));
            }
            ctx.stroke();
        }

        for (var j = 0; j < hist.length; j++) {
            if (hist[j] == null) {
                strokeSeg(segStart, j - 1);
                segStart = -1;
                continue;
            }
            lastValid = j;
            if (segStart < 0)
                segStart = j;
        }
        strokeSeg(segStart, hist.length - 1);

        if (lastValid < 0)
            return null;
        var lv = Number(hist[lastValid]);
        var lx = xOf(lastValid);
        var ly = yOf(lv);
        ctx.fillStyle = stroke;
        ctx.beginPath();
        ctx.arc(lx, ly, 3, 0, Math.PI * 2);
        ctx.fill();
        return { idx: lastValid, v: lv, x: lx, y: ly, color: stroke };
    }

    function fmtPlotVal(kind, v, g, asLive) {
        if (v == null || isNaN(Number(v)))
            return "";
        var n = Number(v);
        if (kind === "dl" || kind === "ul")
            return fmtSpeed(n);
        /* справа (live): RAM/VMEM торрента — МБ суммы; hover по истории — % точки */
        if (asLive && kind === "ram" && g === torrent && lastQbit.ramMb != null)
            return fmtMemMb(lastQbit.ramMb);
        if (asLive && kind === "vmem" && g === torrent && lastQbit.vmemMb != null)
            return fmtMemMb(lastQbit.vmemMb);
        if (n > 0 && n < 1)
            return n.toFixed(1) + "%";
        return Math.round(n) + "%";
    }

    function ensureEndlabsCol(g) {
        var canvas = document.getElementById(g.canvas);
        var wrap = canvas && canvas.parentElement;
        var plot = wrap && wrap.classList.contains("fk-sg-canvas-wrap")
            ? wrap.parentElement
            : null;
        if (!plot)
            return null;
        var col = plot.querySelector(".fk-sg-endlabs");
        if (!col) {
            col = document.createElement("div");
            col.className = "fk-sg-endlabs";
            col.setAttribute("aria-hidden", "true");
            var pct = plot.querySelector(".fk-sg-yaxis-pct");
            if (pct)
                plot.insertBefore(col, pct);
            else
                plot.appendChild(col);
        }
        return { plot: plot, col: col, wrap: wrap };
    }

    /** подписи справа от серого холста — в колонке внутри #Filters (не обрезаются) */
    function placeEndLabels(g, ends, cssH) {
        var box = ensureEndlabsCol(g);
        if (!box)
            return;
        var plot = box.plot;
        var col = box.col;
        var wrap = box.wrap;
        if (wrap) {
            var stray = wrap.querySelectorAll(".fk-sg-endlab");
            var si;
            for (si = 0; si < stray.length; si++)
                stray[si].parentNode.removeChild(stray[si]);
        }
        while (col.firstChild)
            col.removeChild(col.firstChild);

        var need = !!(ends && ends.length);
        plot.classList.toggle("fk-sg-has-endlabs", need);
        var root = plot.closest ? plot.closest(".fk-sg-sidebar, .fk-sg-torrent") : null;
        if (root)
            root.classList.toggle("fk-sg-has-endlabs-axis", need);
        if (!need) {
            plot.style.removeProperty("--fk-sg-endlab-w");
            if (root)
                root.style.removeProperty("--fk-sg-endlab-w");
            return;
        }

        var maxW = (g === session) ? 32 : 44;
        var ei;
        for (ei = 0; ei < ends.length; ei++) {
            var e = ends[ei];
            if (!e || !e.pt || !e.text)
                continue;
            var el = document.createElement("span");
            el.className = "fk-sg-endlab";
            el.textContent = e.text;
            el.style.color = e.pt.color || "#333";
            el.style.borderColor = e.pt.color || "rgba(120,120,120,0.45)";
            el.style.top = Math.round(Math.min(cssH - 6, Math.max(6, e.pt.y))) + "px";
            col.appendChild(el);
            var w = el.offsetWidth + 4;
            if (w > maxW)
                maxW = w;
        }
        maxW = Math.min(64, Math.max(28, maxW));
        plot.style.setProperty("--fk-sg-endlab-w", maxW + "px");
        if (root)
            root.style.setProperty("--fk-sg-endlab-w", maxW + "px");
    }

    function ensurePlotTip(canvas) {
        if (!canvas || !canvas.parentElement)
            return null;
        var wrap = canvas.parentElement;
        var tip = wrap.querySelector(".fk-sg-tip");
        if (!tip) {
            tip = document.createElement("div");
            tip.className = "fk-sg-tip invisible";
            wrap.appendChild(tip);
        }
        return tip;
    }

    function bindPlotHover(g) {
        var canvas = document.getElementById(g.canvas);
        if (!canvas || canvas.dataset.fkHoverBound)
            return;
        canvas.dataset.fkHoverBound = "1";
        var tip = ensurePlotTip(canvas);
        canvas.addEventListener("mousemove", function (e) {
            var plot = g._plot;
            if (!plot || !plot.tracks || !plot.tracks.length || !tip) {
                if (tip)
                    tip.classList.add("invisible");
                return;
            }
            var rect = canvas.getBoundingClientRect();
            var x = e.clientX - rect.left;
            var y = e.clientY - rect.top;
            var cssW = plot.cssW || rect.width;
            var best = null;
            var bi;
            for (bi = 0; bi < plot.tracks.length; bi++) {
                var tr = plot.tracks[bi];
                if (!tr.hist || !tr.hist.length)
                    continue;
                var denom = Math.max(1, tr.hist.length - 1);
                var span = Math.max(1, cssW - 1);
                var idx = Math.round((x / span) * denom);
                if (idx < 0)
                    idx = 0;
                if (idx >= tr.hist.length)
                    idx = tr.hist.length - 1;
                var vv = tr.hist[idx];
                if (vv == null || isNaN(Number(vv)))
                    continue;
                var px = (idx / denom) * span;
                var py = (plot.cssH - 1) - (Number(vv) / tr.max) * (plot.cssH - 1);
                var dist = Math.abs(py - y) + Math.abs(px - x) * 0.15;
                if (!best || dist < best.dist)
                    best = { dist: dist, kind: tr.kind, v: Number(vv), color: tr.color, x: px, y: py };
            }
            if (!best || best.dist > 28) {
                tip.classList.add("invisible");
                return;
            }
            tip.textContent = fmtPlotVal(best.kind, best.v, g);
            tip.style.color = best.color;
            tip.style.left = Math.max(0, Math.min(best.x + 8, cssW - 64)) + "px";
            tip.style.top = Math.max(0, best.y - 18) + "px";
            tip.classList.remove("invisible");
        });
        canvas.addEventListener("mouseleave", function () {
            if (tip)
                tip.classList.add("invisible");
        });
    }

    function seriesForShow(g) {
        var f = g.filt;
        return {
            dl: f.dl ? g.dl : [],
            ul: f.ul ? g.ul : [],
            cpu: (f.cpu && g.withSys) ? g.cpu : [],
            ram: (f.ram && g.withSys) ? g.ram : [],
            vmem: (f.vmem && g.withSys && vmemAvailable) ? g.vmem : []
        };
    }

    function hasSpeedSeries(g) {
        return !!(g.filt.dl || g.filt.ul);
    }

    function hasPctSeries(g) {
        return !!(g.withSys && (g.filt.cpu || g.filt.ram || (g.filt.vmem && vmemAvailable)));
    }

    function drawLines(canvas, g) {
        if (!canvas)
            return;

        var size = canvasCssSize(canvas);
        var cssW = size.cssW;
        var cssH = size.cssH;
        var dpr = window.devicePixelRatio || 1;
        var w = Math.max(1, Math.floor(cssW * dpr));
        var h = Math.max(1, Math.floor(cssH * dpr));
        if (canvas.width !== w || canvas.height !== h) {
            canvas.width = w;
            canvas.height = h;
        }

        var ctx = canvas.getContext("2d");
        if (!ctx)
            return;

        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, cssW, cssH);

        var series = seriesForShow(g);
        var speedOn = hasSpeedSeries(g);
        var pctOn = hasPctSeries(g);
        var maxSpeed = histMax(series.dl, series.ul);
        var maxPct = 100;

        /* линии до правого края серого холста; подписи — в соседней колонке */
        ctx.fillStyle = "rgba(180,180,180,0.10)";
        ctx.fillRect(0, 0, cssW, cssH);
        ctx.strokeStyle = "rgba(140,140,140,0.22)";
        ctx.lineWidth = 1;
        var gi;
        for (gi = 0; gi <= 2; gi++) {
            var gy = (gi / 2) * (cssH - 1) + 0.5;
            ctx.beginPath();
            ctx.moveTo(0, gy);
            ctx.lineTo(cssW, gy);
            ctx.stroke();
        }

        var tracks = [];
        var ends = [];

        function addTrack(kind, hist, max, color, fill) {
            if (!hist || !hist.length || !(max > 0))
                return;
            var pt = drawSeries(ctx, hist, max, cssW, cssH, color, fill);
            tracks.push({ kind: kind, hist: hist, max: max, color: color });
            if (pt)
                ends.push({ kind: kind, pt: pt });
        }

        if (speedOn && maxSpeed > 0) {
            addTrack("ul", series.ul, maxSpeed, "#6a9fd4", "rgba(106,159,212,0.18)");
            addTrack("dl", series.dl, maxSpeed, "#7cb87c", "rgba(124,184,124,0.22)");
        }
        if (pctOn) {
            // CPU/RAM/VMEM — 100% справа = полная загрузка CPU и полный объём RAM
            if (g.filt.vmem && vmemAvailable)
                maxPct = Math.max(maxPct, histPeak(series.vmem, []) || 0, 100);
            if (g.filt.cpu)
                addTrack("cpu", series.cpu, maxPct, "#e6a23c", "rgba(230,162,60,0.12)");
            if (g.filt.ram)
                addTrack("ram", series.ram, maxPct, "#a855f7", "rgba(168,85,247,0.12)");
            if (g.filt.vmem && vmemAvailable)
                addTrack("vmem", series.vmem, maxPct, "#0d9488", "rgba(13,148,136,0.12)");
        }

        g._plot = { cssW: cssW, cssH: cssH, tracks: tracks };

        /* подписи справа от холста — текст не чаще 1 раз/с */
        var now = Date.now();
        if (!g._liveAt || now - g._liveAt >= 1000) {
            g._liveAt = now;
            g._liveLabels = {};
            var ei;
            for (ei = 0; ei < ends.length; ei++)
                g._liveLabels[ends[ei].kind] = fmtPlotVal(ends[ei].kind, ends[ei].pt.v, g, true);
        }
        var endLabs = [];
        for (var ej = 0; ej < ends.length; ej++) {
            endLabs.push({
                kind: ends[ej].kind,
                pt: ends[ej].pt,
                text: (g._liveLabels && g._liveLabels[ends[ej].kind])
                    || fmtPlotVal(ends[ej].kind, ends[ej].pt.v, g, true)
            });
        }
        placeEndLabels(g, endLabs, cssH);
        bindPlotHover(g);
    }

    function windowLabel(g) {
        if (!g.viewSpanMs)
            return "";
        return "окно " + fmtTimeAgo(g.viewSpanMs / 1000).replace(/^−/, "");
    }

    function updateLegendVisibility(g) {
        var f = g.filt;
        // в сайдбаре CPU/RAM — только подсветка чипов, без легенды (иначе строка разъезжается)
        var showSysLegend = !!(g.withSys && g !== session);
        var map = [
            [g.legendDl, ".fk-sg-dl", f.dl],
            [g.legendUl, ".fk-sg-ul", f.ul],
            [g.legendCpu, ".fk-sg-cpu", showSysLegend && f.cpu],
            [g.legendRam, ".fk-sg-ram", showSysLegend && f.ram],
            [g.legendVmem, ".fk-sg-vmem", showSysLegend && f.vmem && vmemAvailable]
        ];
        for (var i = 0; i < map.length; i++) {
            var id = map[i][0];
            if (!id)
                continue;
            var el = document.getElementById(id);
            var wrap = el && el.closest(map[i][1]);
            if (wrap)
                wrap.style.display = map[i][2] ? "" : "none";
        }
    }

    function syncFilterChips(g) {
        var box = document.getElementById(g.filtersId);
        if (!box)
            return;
        var chips = box.querySelectorAll(".fk-sg-chip");
        for (var i = 0; i < chips.length; i++) {
            var key = chips[i].getAttribute("data-series");
            var on = !!g.filt[key];
            chips[i].setAttribute("aria-pressed", on ? "true" : "false");
        }
    }

    function syncControls(g) {
        var resEl = document.getElementById(g.resSelect);
        if (resEl) {
            if (g === session) {
                var fullOpt = resEl.querySelector('option[value="full"]');
                if (fullOpt)
                    fullOpt.hidden = true;
                if (g.resId === "full") {
                    g.resId = "auto";
                    g.resMs = effectiveResMs(g);
                    saveKV(g.lsRes, g.resId);
                }
            }
            if (!resEl.querySelector('option[value="' + g.resId + '"]')) {
                if (g.resId === "1s" || g.resId === "5s" || g.resId === "30s")
                    g.resId = "auto";
                else if (!isKnownRes(g.resId))
                    g.resId = "auto";
            }
            if (resEl.value !== g.resId)
                resEl.value = g.resId;
            if (g.resId === "auto")
                resEl.title = "авто → " + fmtTimeAgo(effectiveResMs(g) / 1000).replace(/^−/, "") + " окно";
            else
                resEl.title = "Масштаб времени";
        }
        syncFilterChips(g);
        updateLegendVisibility(g);
    }

    var renderFp = { session: "", torrent: "" };
    var lastSyncControlsAt = 0;

    function liteMode() {
        try {
            return window.clientData && window.clientData.get
                && window.clientData.get("use_virtual_list") === true;
        }
        catch (e) {
            return false;
        }
    }

    function seriesFingerprint(g) {
        var a = g.dl;
        var b = g.ul;
        var c = g.cpu;
        var r = g.ram;
        var n = a.length;
        var lastSampleT = g.samples && g.samples.length
            ? g.samples[g.samples.length - 1].t
            : 0;
        var pick = function (arr) {
            if (!arr || !arr.length)
                return "x";
            return arr[0] + "/" + arr[arr.length >> 1] + "/" + arr[arr.length - 1];
        };
        return [
            g.resId,
            g.filt.dl ? 1 : 0, g.filt.ul ? 1 : 0, g.filt.cpu ? 1 : 0, g.filt.ram ? 1 : 0,
            g.filt.vmem ? 1 : 0, vmemAvailable ? 1 : 0,
            g.viewSpanMs, n, lastSampleT,
            pick(a), pick(b), pick(c), pick(r), pick(g.vmem),
            histPeak(a, b)
        ].join("|");
    }

    var AVG_WARMUP_MS = 60000;
    var IDLE_EPS = 256;
    var AVG_PENDING_DL = "через 1 мин после активной загрузки";
    var AVG_PENDING_UL = "через 1 мин после активной отдачи";

    /** первая точка с скоростью ≥ 30 КиБ/с по направлению (d|u) */
    function firstActiveAt(samples, key) {
        if (!samples || !samples.length)
            return null;
        var i;
        for (i = 0; i < samples.length; i++) {
            if ((Number(samples[i][key]) || 0) >= RING_LOAD_MIN)
                return samples[i].t;
        }
        return null;
    }

    function summarizeSpeeds(vals) {
        if (!vals || !vals.length)
            return { avg: null, max: null, min: null };
        var sum = 0;
        var max = -Infinity;
        var minPos = Infinity;
        var i;
        for (i = 0; i < vals.length; i++) {
            var v = Number(vals[i]) || 0;
            sum += v;
            if (v > max)
                max = v;
            if (v > IDLE_EPS && v < minPos)
                minPos = v;
        }
        return {
            avg: sum / vals.length,
            max: max === -Infinity ? null : max,
            min: minPos === Infinity ? null : minPos
        };
    }

    function computeTorrentSpeedStats(g) {
        var samples = g.samples;
        var now = Date.now();
        var t1 = now;
        var t0 = now - (g.viewSpanMs || 0);
        if (g.resId === "full" && samples.length) {
            t0 = samples[0].t;
            t1 = Math.max(samples[samples.length - 1].t, now);
        }
        else if (samples.length) {
            var dataStart = samples[0].t;
            var span = g.viewSpanMs || 60000;
            if ((now - dataStart) < span)
                t0 = dataStart;
            else
                t0 = now - span;
        }
        /* среднее: отсчёт 1 мин только после первой активной скорости ≥30 КиБ/с */
        var dlActiveAt = firstActiveAt(samples, "d");
        var ulActiveAt = firstActiveAt(samples, "u");
        var dlAvgFrom = dlActiveAt != null ? dlActiveAt + AVG_WARMUP_MS : null;
        var ulAvgFrom = ulActiveAt != null ? ulActiveAt + AVG_WARMUP_MS : null;
        var dlAvgReady = dlAvgFrom != null && now >= dlAvgFrom;
        var ulAvgReady = ulAvgFrom != null && now >= ulAvgFrom;

        var dlAvg = [];
        var ulAvg = [];
        var dlAll = [];
        var ulAll = [];
        for (var i = 0; i < samples.length; i++) {
            var s = samples[i];
            if (s.t < t0 || s.t > t1)
                continue;
            dlAll.push(s.d);
            ulAll.push(s.u);
            if (dlAvgReady && s.t >= dlAvgFrom)
                dlAvg.push(s.d);
            if (ulAvgReady && s.t >= ulAvgFrom)
                ulAvg.push(s.u);
        }
        var dlSum = summarizeSpeeds(dlAll);
        var ulSum = summarizeSpeeds(ulAll);
        var dlA = summarizeSpeeds(dlAvg);
        var ulA = summarizeSpeeds(ulAvg);
        return {
            dl: { avg: dlAvgReady ? dlA.avg : null, max: dlSum.max, min: dlSum.min },
            ul: { avg: ulAvgReady ? ulA.avg : null, max: ulSum.max, min: ulSum.min },
            dlAvgPending: !dlAvgReady,
            ulAvgPending: !ulAvgReady
        };
    }

    function fmtStatSpeed(v) {
        if (v == null || isNaN(v))
            return "—";
        return fmtSpeed(v);
    }

    function updateTorrentStats(g) {
        var box = document.getElementById("fkTgStats");
        if (!box)
            return;
        var hasTorrent = !!(torrentHash && g.samples.length);
        if (!hasTorrent) {
            box.classList.add("invisible");
            return;
        }

        var st = computeTorrentSpeedStats(g);
        var showDl = !!g.filt.dl;
        var showUl = !!g.filt.ul;

        function applyStat(id, val, seriesOn, pendingText) {
            var el = document.getElementById(id);
            if (!el)
                return;
            var wrap = el.closest(".fk-sg-stat-val");
            var hasNum = val != null && !isNaN(Number(val));
            var ok = seriesOn && (hasNum || !!pendingText);
            if (wrap)
                wrap.style.display = ok ? "" : "none";
            if (!ok) {
                el.textContent = "";
                return;
            }
            if (hasNum)
                setText(id, fmtStatSpeed(val));
            else
                setText(id, pendingText);
        }

        /* средняя — через 1 мин после ≥30 КиБ/с; без секундного таймера; макс/мин — сразу */
        applyStat("fkTgAvgDl", st.dl.avg, showDl, (showDl && st.dlAvgPending) ? AVG_PENDING_DL : null);
        applyStat("fkTgAvgUl", st.ul.avg, showUl, (showUl && st.ulAvgPending) ? AVG_PENDING_UL : null);
        applyStat("fkTgMaxDl", st.dl.max, showDl, null);
        applyStat("fkTgMaxUl", st.ul.max, showUl, null);
        applyStat("fkTgMinDl", st.dl.min, showDl, null);
        applyStat("fkTgMinUl", st.ul.min, showUl, null);

        var stats = box.querySelectorAll(".fk-sg-stat");
        var i;
        var any = false;
        for (i = 0; i < stats.length; i++) {
            var vals = stats[i].querySelectorAll(".fk-sg-stat-val");
            var vis = false;
            var j;
            for (j = 0; j < vals.length; j++) {
                if (vals[j].style.display !== "none") {
                    vis = true;
                    break;
                }
            }
            stats[i].style.display = vis ? "" : "none";
            if (vis)
                any = true;
        }
        /* блок статистики не прячем целиком, если выбран торрент и есть ↓/↑ */
        box.classList.toggle("invisible", !any && !(showDl || showUl));
        if ((showDl || showUl) && hasTorrent)
            box.classList.remove("invisible");
    }

    function paintCanvas(canvas, g) {
        try {
            if (liteMode())
                drawLines(canvas, g);
            else
                requestAnimationFrame(function () {
                    try {
                        drawLines(canvas, g);
                    }
                    catch (e) { /* ignore */ }
                });
        }
        catch (e) { /* ignore */ }
    }

    function renderGraph(g, visibleCheck, force) {
        if (typeof document !== "undefined" && document.hidden && !force)
            return;
        if (visibleCheck && !visibleCheck())
            return;
        var canvas = document.getElementById(g.canvas);
        if (!canvas)
            return;
        rebuildView(g);
        if (g === torrent)
            updateTorrentStats(g);
        var fp = seriesFingerprint(g);
        var key = g === session ? "session" : "torrent";
        /* линии всегда — иначе live-точки/CPU замирают при том же fingerprint */
        if (!force && fp === renderFp[key]) {
            if (Date.now() - lastSyncControlsAt > 2000) {
                lastSyncControlsAt = Date.now();
                syncControls(g);
            }
            paintCanvas(canvas, g);
            return;
        }
        renderFp[key] = fp;

        var series = seriesForShow(g);
        var speedOn = hasSpeedSeries(g);
        var pctOn = hasPctSeries(g);
        var max = speedOn ? histMax(series.dl, series.ul) : 100;
        setAxisY(g.yAxis, max, !speedOn && pctOn);
        syncPctAxis(g, pctOn);
        setAxisX(g.xAxis, g.viewSpanMs || 0);
        setText(g.windowHint, windowLabel(g));
        syncControls(g);
        paintCanvas(canvas, g);
    }

    function renderSession(force) {
        renderGraph(session, null, !!force);
        syncLegendUnitsCompact();
    }

    function renderTorrent(force) {
        renderGraph(torrent, function () {
            var panel = document.getElementById("propSpeed");
            return panel && !panel.classList.contains("invisible");
        }, !!force);
        syncLegendUnitsCompact();
    }

    function syncGraphWantToDaemon() {
        try {
            if (window.qBittorrent && window.qBittorrent.FkSysBar
                && typeof window.qBittorrent.FkSysBar.setGraphWant === "function") {
                /* сайдбар — CPU/RAM системы; торрент — CPU/RAM/VMEM qBit */
                window.qBittorrent.FkSysBar.setGraphWant({
                    cpu: !!session.filt.cpu,
                    ram: !!session.filt.ram,
                    webCpu: !!torrent.filt.cpu,
                    webRam: !!(torrent.filt.ram || torrent.filt.vmem)
                });
            }
        }
        catch (e) { /* ignore */ }
    }

    function toggleFilt(g, key) {
        if (!g.filt.hasOwnProperty(key))
            return;
        if ((key === "cpu" || key === "ram" || key === "vmem") && !g.withSys)
            return;
        if (key === "vmem" && !vmemAvailable)
            return;
        g.filt[key] = !g.filt[key];
        if (!g.filt.dl && !g.filt.ul && !g.filt.cpu && !g.filt.ram && !g.filt.vmem)
            g.filt[key] = true;
        saveFilt(g.lsFilt, g.filt);
        if (key === "cpu" || key === "ram" || key === "vmem")
            syncGraphWantToDaemon();
        updateLegendVisibility(g);
        if (g === torrent) {
            updateTorrentStats(g);
            /* без торрента: показать/скрыть заглушку при вкл./выкл. CPU/RAM/VMEM */
            updateTorrentFromTable();
            return;
        }
        if (g === session)
            renderSession(true);
        else
            renderTorrent(true);
    }

    function applyRes(g, id) {
        if (!isKnownRes(id))
            return;
        if (g === session && id === "full")
            id = "auto";
        g.resId = id;
        g.resMs = effectiveResMs(g);
        saveKV(g.lsRes, g.resId);
        if (g === session) {
            var span = effectiveResMs(g);
            ensureSessionHistory(span || AUTO_STEPS_MS[0], function () {
                renderSession(true);
            });
        }
        else
            renderTorrent(true);
    }

    function bindControl(id, handler) {
        var el = document.getElementById(id);
        if (!el || el.dataset.fkBound)
            return;
        el.dataset.fkBound = "1";
        el.addEventListener("change", function () {
            handler(el.value);
        });
    }

    function bindFilters(g) {
        var box = document.getElementById(g.filtersId);
        if (!box || box.dataset.fkBound)
            return;
        box.dataset.fkBound = "1";
        box.addEventListener("click", function (e) {
            var btn = e.target.closest(".fk-sg-chip");
            if (!btn || !box.contains(btn))
                return;
            e.preventDefault();
            toggleFilt(g, btn.getAttribute("data-series"));
        });
    }

    function bindAllControls() {
        bindFilters(session);
        bindFilters(torrent);
        bindControl(session.resSelect, function (v) { applyRes(session, v); });
        bindControl(torrent.resSelect, function (v) { applyRes(torrent, v); });
        bindSessionWidthResize();
        bindTorrentHeightResize();
        bindTorrentWidthResize();
        observePlots();
        syncControls(session);
        syncControls(torrent);
    }

    function setFiltersColumnWidth(px) {
        var col = document.getElementById("filtersColumn");
        if (!col)
            return;
        px = Math.max(160, Math.min(900, Math.round(px)));
        col.style.width = px + "px";
        try {
            localStorage.setItem("filters_width", String(px));
        }
        catch (e) { /* ignore */ }
        renderSession();
    }

    function bindSessionWidthResize() {
        var handle = document.getElementById("fkSgResizeX");
        var panel = document.getElementById("fkSessionSpeed");
        if (!handle || !panel || handle.dataset.fkBound)
            return;
        handle.dataset.fkBound = "1";
        var dragging = false;

        handle.addEventListener("mousedown", function (e) {
            e.preventDefault();
            e.stopPropagation();
            dragging = true;
            document.body.classList.add("fk-sg-resizing");
        });

        window.addEventListener("mousemove", function (e) {
            if (!dragging)
                return;
            var col = document.getElementById("filtersColumn");
            if (!col)
                return;
            var left = col.getBoundingClientRect().left;
            setFiltersColumnWidth(e.clientX - left);
            syncLegendUnitsCompact();
        });

        window.addEventListener("mouseup", function () {
            if (!dragging)
                return;
            dragging = false;
            document.body.classList.remove("fk-sg-resizing");
            syncLegendUnitsCompact();
            renderSession();
        });
    }

    function setTorrentGraphWidth(px) {
        var box = document.getElementById("fkTorrentSpeed");
        var host = document.getElementById("propSpeed");
        if (!box || !host)
            return;
        var hostW = Math.floor(host.getBoundingClientRect().width);
        if (hostW < 200)
            return;
        var minW = Math.min(240, hostW);
        px = Math.max(minW, Math.min(hostW, Math.round(px)));
        if (px >= hostW - 2) {
            box.style.width = "100%";
            box.style.maxWidth = "";
            box.style.alignSelf = "";
            box.classList.remove("fk-sg-torrent-narrow");
            try { localStorage.removeItem("fk_sg_torrent_w"); }
            catch (e) { /* ignore */ }
        }
        else {
            /* прижат влево: тянем правый край влево — сжимаем, справа пусто */
            box.style.width = px + "px";
            box.style.maxWidth = "100%";
            box.style.alignSelf = "flex-start";
            box.classList.add("fk-sg-torrent-narrow");
            try { localStorage.setItem("fk_sg_torrent_w", String(px)); }
            catch (e2) { /* ignore */ }
        }
        renderTorrent();
    }

    function restoreTorrentGraphWidth() {
        var box = document.getElementById("fkTorrentSpeed");
        var host = document.getElementById("propSpeed");
        if (!box || !host)
            return;
        try {
            var saved = Number(localStorage.getItem("fk_sg_torrent_w"));
            if (saved >= 240) {
                setTorrentGraphWidth(saved);
                return;
            }
        }
        catch (e) { /* ignore */ }
        box.style.width = "100%";
        box.style.maxWidth = "";
        box.style.alignSelf = "";
        box.classList.remove("fk-sg-torrent-narrow");
    }

    function bindTorrentWidthResize() {
        var handle = document.getElementById("fkTgResizeX");
        var box = document.getElementById("fkTorrentSpeed");
        if (!handle || !box || handle.dataset.fkBound)
            return;
        handle.dataset.fkBound = "1";
        var dragging = false;
        var startX = 0;
        var startW = 0;

        handle.addEventListener("mousedown", function (e) {
            e.preventDefault();
            e.stopPropagation();
            dragging = true;
            startX = e.clientX;
            startW = box.getBoundingClientRect().width;
            document.body.classList.add("fk-sg-resizing");
        });

        handle.addEventListener("dblclick", function (e) {
            e.preventDefault();
            e.stopPropagation();
            var host = document.getElementById("propSpeed");
            if (host)
                setTorrentGraphWidth(host.getBoundingClientRect().width);
        });

        window.addEventListener("mousemove", function (e) {
            if (!dragging)
                return;
            /* влево (clientX↓) — уже; вправо — шире; график слева */
            setTorrentGraphWidth(startW + (e.clientX - startX));
        });

        window.addEventListener("mouseup", function () {
            if (!dragging)
                return;
            dragging = false;
            document.body.classList.remove("fk-sg-resizing");
            renderTorrent();
        });

        restoreTorrentGraphWidth();
    }

    function bindTorrentHeightResize() {
        var handle = document.getElementById("fkTgResizeY");
        var plot = document.querySelector("#fkTorrentSpeed .fk-sg-plot");
        if (!handle || !plot || handle.dataset.fkBound)
            return;
        handle.dataset.fkBound = "1";
        var dragging = false;
        var startY = 0;
        var startH = 0;

        handle.addEventListener("mousedown", function (e) {
            e.preventDefault();
            e.stopPropagation();
            dragging = true;
            startY = e.clientY;
            startH = plot.getBoundingClientRect().height;
            document.body.classList.add("fk-sg-resizing-y");
        });

        window.addEventListener("mousemove", function (e) {
            if (!dragging)
                return;
            var h = Math.max(200, Math.min(900, startH + (e.clientY - startY)));
            /* ручное изменение — фиксируем высоту */
            plot.style.height = h + "px";
            plot.style.minHeight = h + "px";
            plot.style.flex = "0 0 auto";
            try {
                localStorage.setItem("fk_sg_torrent_plot_h", String(Math.round(h)));
                localStorage.setItem("fk_sg_torrent_plot_pin", "1");
            }
            catch (err) { /* ignore */ }
            renderTorrent();
        });

        window.addEventListener("mouseup", function () {
            if (!dragging)
                return;
            dragging = false;
            document.body.classList.remove("fk-sg-resizing-y");
            renderTorrent();
        });

        /* по умолчанию — растянуть на пустое место панели; pin — только после ручного ресайза */
        try {
            var pinned = localStorage.getItem("fk_sg_torrent_plot_pin") === "1";
            var saved = Number(localStorage.getItem("fk_sg_torrent_plot_h"));
            if (pinned && saved >= 200 && saved <= 900) {
                plot.style.height = saved + "px";
                plot.style.minHeight = saved + "px";
                plot.style.flex = "0 0 auto";
            }
            else {
                plot.style.height = "";
                plot.style.minHeight = "240px";
                plot.style.flex = "1 1 auto";
            }
        }
        catch (e) {
            plot.style.height = "";
            plot.style.minHeight = "240px";
            plot.style.flex = "1 1 auto";
        }
    }

    var plotObservers = [];
    function observePlots() {
        if (typeof ResizeObserver !== "function")
            return;
        while (plotObservers.length) {
            plotObservers.pop().disconnect();
        }
        ["fkSgCanvas", "fkTgCanvas"].forEach(function (id) {
            var canvas = document.getElementById(id);
            if (!canvas || !canvas.parentElement)
                return;
            var ro = new ResizeObserver(function () {
                if (id === "fkSgCanvas")
                    renderSession();
                else
                    renderTorrent();
            });
            ro.observe(canvas.parentElement);
            plotObservers.push(ro);
        });
    }

    function getSelectedHash() {
        try {
            var table = window.torrentsTable;
            if (!table)
                return "";
            if (typeof table.getCurrentTorrentID === "function") {
                var h = table.getCurrentTorrentID();
                if (h)
                    return String(h);
            }
            if (typeof table.selectedRowsIds === "function") {
                var ids = table.selectedRowsIds();
                if (ids && ids.length)
                    return String(ids[0]);
            }
            if (table.selectedRows && table.selectedRows.length)
                return String(table.selectedRows[0]);
        }
        catch (e) { /* ignore */ }
        return "";
    }

    function getFallbackActiveHash() {
        try {
            var table = window.torrentsTable;
            if (!table || typeof table.getRowValues !== "function")
                return "";
            var best = "";
            var bestScore = 0;
            for (var row of table.getRowValues()) {
                if (!row || !row.full_data)
                    continue;
                var dl = Number(row.full_data.dlspeed) || 0;
                var ul = Number(row.full_data.upspeed) || 0;
                var score = dl + ul;
                if (score > bestScore) {
                    bestScore = score;
                    best = String(row.rowId);
                }
            }
            return bestScore > 0 ? best : "";
        }
        catch (e) {
            return "";
        }
    }

    function readTorrentSpeeds(hash) {
        try {
            var table = window.torrentsTable;
            if (!table || typeof table.getRow !== "function")
                return null;
            var row = table.getRow(hash);
            if (!row || !row.full_data)
                return null;
            return {
                dl: Number(row.full_data.dlspeed) || 0,
                ul: Number(row.full_data.upspeed) || 0
            };
        }
        catch (e) {
            return null;
        }
    }

    function switchTorrentHash(hash) {
        if (hash === torrentHash)
            return;
        if (torrentHash && torrent.samples.length)
            persistTorrentHistory(torrentHash, torrent.samples, true);
        torrentHash = hash;
        clearSamples(torrent);
        if (hash) {
            var loaded = loadTorrentHistory(hash);
            for (var i = 0; i < loaded.length; i++)
                torrent.samples.push(loaded[i]);
        }
    }

    /** CPU/RAM/VMEM на вкладке «Скорость» без выбранного торрента — как верхний график */
    function torrentWantsSys() {
        return !!(torrent.withSys && (torrent.filt.cpu || torrent.filt.ram
            || (torrent.filt.vmem && vmemAvailable)));
    }

    function updateTorrentFromTable() {
        var panel = document.getElementById("propSpeed");
        if (!panel)
            return;

        var empty = document.getElementById("fkTgEmpty");
        var selected = getSelectedHash();
        var hash = selected || getFallbackActiveHash();

        if (!hash) {
            if (torrentHash) {
                if (torrent.samples.length)
                    persistTorrentHistory(torrentHash, torrent.samples, true);
                torrentHash = "";
                clearSamples(torrent);
            }
            setSpeedLegend("fkTgDl", 0);
            setSpeedLegend("fkTgUl", 0);
            updateTorrentStats(torrent);
            if (torrentWantsSys()) {
                if (empty)
                    empty.classList.add("invisible");
                syncTorrentSysLegend();
                if (!panel.classList.contains("invisible"))
                    renderTorrent();
                return;
            }
            if (torrent.samples.length)
                clearSamples(torrent);
            if (empty) {
                empty.textContent = "Выберите торрент в списке выше";
                empty.classList.remove("invisible");
            }
            if (!panel.classList.contains("invisible"))
                renderTorrent();
            return;
        }

        switchTorrentHash(hash);

        var sp = readTorrentSpeeds(hash);
        if (!sp)
            return;

        if (empty)
            empty.classList.add("invisible");

        setSpeedLegend("fkTgDl", sp.dl);
        setSpeedLegend("fkTgUl", sp.ul);
        syncTorrentSysLegend();
        /* CPU/RAM — qBit; VMEM — swap/zram; порог 30 КиБ/с только для скорости */
        pushSample(torrent.samples, Date.now(), sp.dl, sp.ul,
            lastQbit.cpu, lastQbit.ramPct, lastQbit.vmemPct);
        persistTorrentHistory(hash, torrent.samples, false);
        if (!panel.classList.contains("invisible"))
            renderTorrent();
    }

    function fmtCpuPct(v) {
        if (v == null || isNaN(v))
            return "—";
        var n = Number(v);
        if (n > 0 && n < 1)
            return n.toFixed(1) + " %";
        return Math.round(n) + " %";
    }

    function fmtRamPct(v) {
        if (v == null || isNaN(v))
            return "—";
        return Math.round(Number(v)) + " %";
    }

    function fmtMemMb(v) {
        if (v == null || isNaN(v))
            return "—";
        var n = Number(v);
        if (n > 0 && n < 10)
            return n.toFixed(1) + " МБ";
        return Math.round(n) + " МБ";
    }

    function syncTorrentSysLegend() {
        if (torrent.filt.cpu)
            setText("fkTgCpu", fmtCpuPct(lastQbit.cpu));
        if (torrent.filt.ram)
            setText("fkTgRam", fmtMemMb(lastQbit.ramMb));
        if (torrent.filt.vmem && vmemAvailable)
            setText("fkTgVmem", fmtMemMb(lastQbit.vmemMb));
    }

    /** записать CPU/RAM/VMEM в историю вкладки — без порога скорости и без обязательного торрента */
    function pushTorrentQbitSample() {
        if (!torrent.withSys)
            return;
        if (!torrentHash && !torrentWantsSys())
            return;
        if (lastQbit.cpu == null && lastQbit.ramPct == null && lastQbit.vmemPct == null)
            return;
        var td = 0;
        var tu = 0;
        if (torrent.samples.length) {
            td = torrent.samples[torrent.samples.length - 1].d;
            tu = torrent.samples[torrent.samples.length - 1].u;
        }
        pushSample(torrent.samples, Date.now(), td, tu,
            lastQbit.cpu, lastQbit.ramPct, lastQbit.vmemPct);
    }

    function hasTorrentVmem() {
        /* как в ОЗУ системы: только занятый swap/zram, не VmSize процесса */
        if (lastQbit.vmemLive === true)
            return true;
        return lastQbit.vmemMb != null && Number(lastQbit.vmemMb) > 0;
    }

    function syncVmemChipVisibility() {
        vmemAvailable = !!(torrent.withSys && hasTorrentVmem());
        var box = document.getElementById(torrent.filtersId);
        if (!box)
            return;
        box.querySelectorAll("[data-series=\"vmem\"]").forEach(function (el) {
            el.classList.toggle("invisible", !vmemAvailable);
        });
        if (!vmemAvailable && torrent.filt.vmem) {
            torrent.filt.vmem = false;
            saveFilt(torrent.lsFilt, torrent.filt);
            updateLegendVisibility(torrent);
        }
    }

    function onQbitMetrics(m) {
        if (!m)
            return;
        if (m.cpu != null && !isNaN(Number(m.cpu)))
            lastQbit.cpu = Number(m.cpu);
        if (m.ramMb != null && !isNaN(Number(m.ramMb)))
            lastQbit.ramMb = Number(m.ramMb);
        if (m.ramPct != null && !isNaN(Number(m.ramPct)))
            lastQbit.ramPct = Number(m.ramPct);
        if (Object.prototype.hasOwnProperty.call(m, "vmemLive"))
            lastQbit.vmemLive = !!m.vmemLive;
        if (m.vmemLive === false) {
            lastQbit.vmemMb = null;
            lastQbit.vmemPct = null;
        }
        else {
            if (m.vmemMb != null && !isNaN(Number(m.vmemMb)))
                lastQbit.vmemMb = Number(m.vmemMb);
            if (m.vmemPct != null && !isNaN(Number(m.vmemPct)))
                lastQbit.vmemPct = Number(m.vmemPct);
        }

        syncVmemChipVisibility();
        /* CPU/RAM/VMEM в историю — всегда, без порога 30 КиБ/с и без обязательного торрента */
        pushTorrentQbitSample();
        syncTorrentSysLegend();
        if (torrentWantsSys())
            renderTorrent(true);
    }

    function onSysMetrics(m) {
        if (!m)
            return;
        if (m.cpu != null && !isNaN(Number(m.cpu)))
            lastSys.cpu = Number(m.cpu);
        if (m.ramUsed != null && m.ramTotal != null && Number(m.ramTotal) > 0) {
            lastSys.ramUsed = Number(m.ramUsed);
            lastSys.ramTotal = Number(m.ramTotal);
            lastSys.ramPct = 100 * lastSys.ramUsed / lastSys.ramTotal;
        }
        else if (m.ramPct != null && !isNaN(Number(m.ramPct))) {
            lastSys.ramPct = Number(m.ramPct);
        }
        /* сайдбар — CPU/RAM системы */
        if (session.filt.cpu)
            setText("fkSgCpu", fmtCpuPct(lastSys.cpu));
        if (session.filt.ram)
            setText("fkSgRam", fmtRamPct(lastSys.ramPct));

        /* CPU/RAM системы в историю сайдбара — не зависят от порога скорости */
        var now = Date.now();
        if (session.withSys && (lastSys.cpu != null || lastSys.ramPct != null)) {
            var sd = 0;
            var su = 0;
            if (session.samples.length) {
                sd = session.samples[session.samples.length - 1].d;
                su = session.samples[session.samples.length - 1].u;
            }
            pushSample(session.samples, now, sd, su, lastSys.cpu, lastSys.ramPct);
        }

        if (session.filt.cpu || session.filt.ram)
            renderSession(true);
    }

    function onServerState(state) {
        if (!state)
            return;

        var dl = Number(state.dl_info_speed) || 0;
        var ul = Number(state.up_info_speed) || 0;
        setSpeedLegend("fkSgDl", dl);
        setSpeedLegend("fkSgUl", ul);
        if (session.filt.cpu)
            setText("fkSgCpu", fmtCpuPct(lastSys.cpu));
        if (session.filt.ram)
            setText("fkSgRam", fmtRamPct(lastSys.ramPct));
        syncLegendUnitsCompact();

        pushSample(session.samples, Date.now(), dl, ul, lastSys.cpu, lastSys.ramPct);
        /* диск — только по таймеру/масштабу, не на каждом sync */
        if (Date.now() - lastRingFetchAt >= RING_FETCH_EVERY_MS)
            ensureSessionHistory(effectiveResMs(session) || AUTO_STEPS_MS[0], null);
        renderSession(true);
        updateTorrentFromTable();
    }

    function updateTorrent() {
        updateTorrentFromTable();
        renderTorrent();
    }

    function clearTorrent() {
        if (torrentHash && torrent.samples.length)
            persistTorrentHistory(torrentHash, torrent.samples, true);
        torrentHash = "";
        clearSamples(torrent);
        setSpeedLegend("fkTgDl", 0);
        setSpeedLegend("fkTgUl", 0);
        var empty = document.getElementById("fkTgEmpty");
        if (empty)
            empty.classList.remove("invisible");
        renderTorrent();
    }

    function setDaemonMetrics(on) {
        on = !!on;
        session.withSys = on;
        torrent.withSys = on;
        var box = document.getElementById(session.filtersId);
        if (box) {
            box.querySelectorAll("[data-series=\"cpu\"], [data-series=\"ram\"]").forEach(function (el) {
                el.classList.toggle("invisible", !on);
            });
        }
        var tbox = document.getElementById(torrent.filtersId);
        if (tbox) {
            tbox.querySelectorAll("[data-series=\"cpu\"], [data-series=\"ram\"]").forEach(function (el) {
                el.classList.toggle("invisible", !on);
            });
        }
        /* выбор чипов CPU/RAM в localStorage не трогаем при offline — восстановится после F5 */
        if (!on) {
            lastSys.cpu = null;
            lastSys.ramPct = null;
            lastSys.ramUsed = null;
            lastSys.ramTotal = null;
            lastQbit.cpu = null;
            lastQbit.ramMb = null;
            lastQbit.vmemMb = null;
            lastQbit.ramPct = null;
            lastQbit.vmemPct = null;
            lastQbit.vmemLive = false;
            vmemAvailable = false;
        }
        else {
            session.filt = loadFilt(session.lsFilt, true);
            torrent.filt = loadFilt(torrent.lsFilt, true);
        }
        syncVmemChipVisibility();
        var head = document.getElementById("fkSessionSpeed");
        if (head) {
            head.querySelectorAll(".fk-sg-cpu, .fk-sg-ram").forEach(function (el) {
                el.classList.add("invisible");
                el.style.display = "none";
            });
        }
        updateLegendVisibility(session);
        updateLegendVisibility(torrent);
        syncControls(session);
        syncControls(torrent);
        if (on)
            syncGraphWantToDaemon();
        renderSession(true);
        renderTorrent(true);
    }

    window.qBittorrent = window.qBittorrent || {};
    window.qBittorrent.FkUnitTip = TIP_IEC;
    window.qBittorrent.FkSpeedGraph = {
        onServerState: onServerState,
        onSysMetrics: onSysMetrics,
        onQbitMetrics: onQbitMetrics,
        setDaemonMetrics: setDaemonMetrics,
        updateTorrent: updateTorrent,
        clearTorrent: clearTorrent,
        redraw: function () {
            bindAllControls();
            renderSession();
            renderTorrent();
        }
    };

    window.addEventListener("resize", function () {
        renderSession(true);
        renderTorrent(true);
    });

    document.addEventListener("visibilitychange", function () {
        if (!document.hidden) {
            renderSession(true);
            renderTorrent(true);
        }
    });

    window.addEventListener("beforeunload", function () {
        flushRingAcc();
        saveRingLocal(true);
        if (torrentHash && torrent.samples.length)
            persistTorrentHistory(torrentHash, torrent.samples, true);
    });

    var bootTries = 0;
    var boot = function () {
        bindAllControls();
        setDaemonMetrics(false);
        try {
            if (window.qBittorrent.FkSysBar && typeof window.qBittorrent.FkSysBar.hasDaemon === "function"
                && window.qBittorrent.FkSysBar.hasDaemon())
                setDaemonMetrics(true);
        }
        catch (e) { /* ignore */ }
        if (document.getElementById("fkSgCanvas")) {
            hydrateSessionRing(function () {
                syncGraphWantToDaemon();
                renderSession(true);
            });
            return;
        }
        if (bootTries++ < 40)
            setTimeout(boot, 250);
    };
    if (document.readyState === "loading")
        document.addEventListener("DOMContentLoaded", boot);
    else
        boot();
})();
