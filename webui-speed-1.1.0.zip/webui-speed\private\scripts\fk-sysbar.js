/*
 * Статус-бар CPU / RAM / web CPU / qb RAM + меню «⋯».
 * Работает только при наличии демона (fk-sysinfo.json).
 *
 * CPU     = загрузка хоста
 * web CPU = % всех процессов qBit (с дочерними) + демон
 * qb RAM  = сумма RSS дерева qBit на роутере
 */
(function () {
    "use strict";

    var POLL_CHOICES = [500, 1000, 3000, 5000, 10000, 15000, 30000];
    var DEFAULT_POLL_MS = 5000;
    var REPROBE_MS = 60000;
    var MAX_POINTS = 1200;
    /** окно для «среднего» в попапах (CPU / ОЗУ) */
    var AVG_WINDOW_MS = 600000;
    var JSON_URL = "fk-sysinfo.json";
    var LS_WANT = "fk_sysbar_want_v1";
    var LS_POLL = "fk_sysbar_poll_ms";
    var LS_POP_SCALE = "fk_sysbar_pop_scale_ms";
    var pollMs = DEFAULT_POLL_MS;
    var tickTimer = null;
    var SMOOTH_ALPHA = 0.28;
    var POP_W = 280;
    var POP_GAP = 8;
    var POP_SCALES = [
        { ms: 0, label: "авто" },
        { ms: 30000, label: "30 с" },
        { ms: 60000, label: "1 м" },
        { ms: 120000, label: "2 м" },
        { ms: 300000, label: "5 м" },
        { ms: 600000, label: "10 м" },
        { ms: 1200000, label: "20 м" },
        { ms: 1800000, label: "30 м" },
        { ms: 3600000, label: "1 ч" }
    ];
    /** ступени «авто» — как у верхнего графика (окно растёт с накоплением точек) */
    var POP_AUTO_STEPS_MS = [
        30000, 60000, 120000, 300000, 600000, 1200000, 1800000,
        3600000, 7200000, 10800000, 14400000, 18000000,
        21600000, 25200000, 28800000, 32400000, 36000000
    ];
    var POP_AUTO_STEP_AFTER = 36000000;
    var popScaleMs = 0; /* 0 = авто */
    var smooth = {};
    var popovers = {}; /* key -> { el, anchor, key, isCpu } */

    var hist = {
        sysCpu: [], sysRam: [], sysVmem: [], shellCpu: [], shellRam: [],
        panelCpu: [], colCpu: [],
        panelRam: [], colRam: [],
        cores: [], /* hist.cores[i] = [] */
        writeOver: [], readOver: [], avgQueue: [], cacheMain: []
    };
    /** пики ОЗУ за всё время сессии (не обрезаются с hist) */
    var ramPeak = { sysRam: null, shellRam: null, colRam: null, panelRam: null };
    var POP_YAXIS_W = 28;
    var CACHE_WRITE_HOT = 5;
    /* график записи: 0% — светло-зелёный; перегрузка — как цвет «Кэш» в статус-баре */
    var CACHE_WRITE_OK_COLOR = "#86efac";
    var CACHE_WRITE_HOT_COLOR = "#b45a5a";
    var CACHE_QUEUE_SOFT = 200;
    var CACHE_QUEUE_HARD = 650;
    var last = {
        sysCpu: null,
        sysRam: null,
        sysRamTotal: null,
        sysVmem: null,
        sysVmemTotal: null,
        sysVmemKind: null, /* "zram" | "swap" */
        shellCpu: null,
        shellRam: null,
        panelCpu: null,
        panelRam: null,
        panelVmem: null,
        colCpu: null,
        colRam: null,
        colVmem: null,
        webCpu: null,
        webRam: null,
        cores: [], /* текущие % по ядрам */
        writeOver: null,
        readOver: null,
        avgQueue: null,
        queuedJobs: null,
        buffersSize: null,
        readHits: null,
        queuedSize: null
    };
    var CORE_COLORS = ["#f59e0b", "#3b82f6", "#22c55e", "#a855f7", "#ef4444", "#06b6d4", "#eab308", "#f97316"];
    var want = { cpu: true, ram: true, webCpu: true, webRam: true, cache: true };
    /** сбор метрик кэша = want.cache и окно «Статистика» */
    var cacheCollect = false;
    /** запрос от верхнего/торрент-графика (чипы CPU/RAM) */
    var graphWant = { cpu: false, ram: false, webCpu: false, webRam: false };
    var menuEl = null;
    var sampleBusy = false;
    /** true только после успешного ответа демона */
    var daemonOk = false;
    var lastProbeAt = 0;
    var failStreak = 0;

    function loadWant() {
        try {
            var raw = localStorage.getItem(LS_WANT);
            if (!raw)
                return;
            var o = JSON.parse(raw);
            if (!o || typeof o !== "object")
                return;
            /* явное true/false из localStorage — помним выкл. после F5 */
            if (Object.prototype.hasOwnProperty.call(o, "cpu"))
                want.cpu = !!o.cpu;
            if (Object.prototype.hasOwnProperty.call(o, "ram"))
                want.ram = !!o.ram;
            if (Object.prototype.hasOwnProperty.call(o, "webCpu"))
                want.webCpu = !!o.webCpu;
            if (Object.prototype.hasOwnProperty.call(o, "webRam"))
                want.webRam = !!o.webRam;
            if (Object.prototype.hasOwnProperty.call(o, "cache"))
                want.cache = !!o.cache;
        }
        catch (e) { /* ignore */ }
    }

    function loadPollMs() {
        try {
            var n = Number(localStorage.getItem(LS_POLL));
            if (POLL_CHOICES.indexOf(n) >= 0)
                pollMs = n;
        }
        catch (e) { /* ignore */ }
        try {
            var raw = localStorage.getItem(LS_POP_SCALE);
            if (raw === "auto") {
                popScaleMs = 0;
            }
            else {
                var s = Number(raw);
                for (var i = 0; i < POP_SCALES.length; i++) {
                    if (POP_SCALES[i].ms === s) {
                        popScaleMs = s;
                        break;
                    }
                }
            }
        }
        catch (e2) { /* ignore */ }
    }

    function savePopScale(ms) {
        var ok = false;
        var i;
        for (i = 0; i < POP_SCALES.length; i++) {
            if (POP_SCALES[i].ms === ms) {
                ok = true;
                break;
            }
        }
        if (!ok)
            return;
        popScaleMs = ms;
        try {
            localStorage.setItem(LS_POP_SCALE, String(ms));
        }
        catch (e) { /* ignore */ }
        refreshAllPopovers(true);
    }

    function histSpanMs(arr) {
        if (!arr || arr.length < 2)
            return 0;
        return (arr.length - 1) * Math.max(pollMs, 500);
    }

    function maxHistSpanMs() {
        var span = 0;
        var keys = [
            "sysCpu", "sysRam", "sysVmem", "shellCpu", "shellRam",
            "panelCpu", "colCpu", "panelRam", "colRam",
            "writeOver", "readOver", "avgQueue", "cacheMain"
        ];
        var i;
        for (i = 0; i < keys.length; i++)
            span = Math.max(span, histSpanMs(hist[keys[i]]));
        if (hist.cores && hist.cores.length) {
            for (i = 0; i < hist.cores.length; i++)
                span = Math.max(span, histSpanMs(hist.cores[i]));
        }
        return span;
    }

    function autoPopScaleMs() {
        var span = maxHistSpanMs();
        var i;
        for (i = 0; i < POP_AUTO_STEPS_MS.length; i++) {
            if (span <= POP_AUTO_STEPS_MS[i])
                return POP_AUTO_STEPS_MS[i];
        }
        return Math.max(POP_AUTO_STEP_AFTER,
            Math.ceil(span / POP_AUTO_STEP_AFTER) * POP_AUTO_STEP_AFTER);
    }

    function effectivePopScaleMs() {
        if (popScaleMs === 0)
            return autoPopScaleMs();
        return popScaleMs;
    }

    function syncScaleSelUi() {
        var eff = effectivePopScaleMs();
        var tip = popScaleMs === 0
            ? ("авто → " + fmtTimeAgoShort(eff).replace(/^\u2212|^−/, "") + " окно")
            : "Интервал времени";
        var val = String(popScaleMs);
        Object.keys(popovers).forEach(function (k) {
            var sel = popovers[k].el.querySelector(".fk-syspop-scale-sel");
            if (!sel)
                return;
            if (sel.value !== val)
                sel.value = val;
            if (sel.title !== tip)
                sel.title = tip;
        });
    }

    function savePollMs(ms) {
        if (POLL_CHOICES.indexOf(ms) < 0)
            return;
        pollMs = ms;
        try {
            localStorage.setItem(LS_POLL, String(ms));
        }
        catch (e) { /* ignore */ }
        restartTickTimer();
    }

    function saveWant() {
        try {
            localStorage.setItem(LS_WANT, JSON.stringify(want));
        }
        catch (e) { /* ignore */ }
        pushWantToDaemon();
    }

    function restartTickTimer() {
        if (tickTimer != null) {
            clearInterval(tickTimer);
            tickTimer = null;
        }
        tickTimer = setInterval(tick, pollMs);
    }

    /**
     * Сигнал демону без лишнего порта: GET fk-want/CRWW (atime маяка).
     * C=cpu роутера R=ram роутера W=webcpu (панель+демон) W=webram (RSS).
     */
    function notifyDaemonState() {
        try {
            if (window.qBittorrent && window.qBittorrent.FkSpeedGraph
                && typeof window.qBittorrent.FkSpeedGraph.setDaemonMetrics === "function")
                window.qBittorrent.FkSpeedGraph.setDaemonMetrics(daemonOk);
        }
        catch (e) { /* ignore */ }
    }

    function setDaemonOk(ok) {
        ok = !!ok;
        if (daemonOk === ok)
            return;
        daemonOk = ok;
        if (!daemonOk) {
            last.sysCpu = last.sysRam = last.sysRamTotal = null;
            last.sysVmem = last.sysVmemTotal = last.sysVmemKind = null;
            last.panelCpu = last.panelRam = last.panelVmem = last.colCpu = last.colRam = last.colVmem = null;
            last.shellCpu = last.shellRam = last.webCpu = last.webRam = null;
            last.cores = [];
            hist.sysCpu.length = 0;
            hist.sysRam.length = 0;
            hist.sysVmem.length = 0;
            hist.shellCpu.length = 0;
            hist.shellRam.length = 0;
            hist.panelCpu.length = 0;
            hist.colCpu.length = 0;
            hist.panelRam.length = 0;
            hist.colRam.length = 0;
            hist.cores = [];
            ramPeak.sysRam = ramPeak.shellRam = ramPeak.colRam = ramPeak.panelRam = null;
            hidePopover();
            hideMenu();
        }
        applyVisibility();
        notifyDaemonState();
    }

    function pushWantToDaemon() {
        if (!daemonOk)
            return;
        /* cpu/ram: система (статус-бар + сайдбар); web*: qBit (статус-бар + график торрента) */
        var bits = ((want.cpu || want.webCpu || graphWant.cpu || graphWant.webCpu) ? "1" : "0")
            + ((want.ram || graphWant.ram || graphWant.webRam) ? "1" : "0")
            + ((want.webCpu || graphWant.webCpu) ? "1" : "0")
            + ((want.webRam || graphWant.webRam) ? "1" : "0");
        fetch("fk-want/" + bits + "?t=" + Date.now(), {
            cache: "no-store",
            credentials: "same-origin"
        }).catch(function () { /* ok */ });
    }

    function setGraphWant(o) {
        if (!o || typeof o !== "object")
            return;
        if (Object.prototype.hasOwnProperty.call(o, "cpu"))
            graphWant.cpu = !!o.cpu;
        if (Object.prototype.hasOwnProperty.call(o, "ram"))
            graphWant.ram = !!o.ram;
        if (Object.prototype.hasOwnProperty.call(o, "webCpu"))
            graphWant.webCpu = !!o.webCpu;
        if (Object.prototype.hasOwnProperty.call(o, "webRam"))
            graphWant.webRam = !!o.webRam;
        if (daemonOk) {
            pushWantToDaemon();
            sampleSysinfo();
        }
    }

    function needsSysFetch() {
        return daemonOk && (want.cpu || want.ram || want.webCpu || want.webRam
            || graphWant.cpu || graphWant.ram || graphWant.webCpu || graphWant.webRam);
    }

    function ema(key, v) {
        var n = Number(v);
        if (isNaN(n))
            return smooth[key];
        if (smooth[key] == null || isNaN(smooth[key]))
            smooth[key] = n;
        else
            smooth[key] = smooth[key] * (1 - SMOOTH_ALPHA) + n * SMOOTH_ALPHA;
        return smooth[key];
    }

    function push(arr, v) {
        var n = Number(v);
        if (isNaN(n))
            return;
        arr.push(n);
        while (arr.length > MAX_POINTS)
            arr.shift();
    }

    function noteRamPeak(key, v) {
        var n = Number(v);
        if (isNaN(n))
            return;
        if (ramPeak[key] == null || n > ramPeak[key])
            ramPeak[key] = n;
    }

    function avg(arr) {
        if (!arr || !arr.length)
            return null;
        var s = 0;
        for (var i = 0; i < arr.length; i++)
            s += arr[i];
        return s / arr.length;
    }

    function seriesForMs(arr, ms) {
        if (!arr || !arr.length)
            return [];
        var step = Math.max(pollMs, 500);
        var n = Math.max(1, Math.ceil(ms / step));
        n = Math.min(n, arr.length);
        return arr.slice(arr.length - n);
    }

    function seriesForScale(arr) {
        if (!arr || !arr.length)
            return [];
        var step = Math.max(pollMs, 500);
        var win = effectivePopScaleMs();
        var n = Math.max(2, Math.ceil(win / step));
        n = Math.min(n, arr.length, 400);
        return arr.slice(arr.length - n);
    }

    function avg10m(arr) {
        return avg(seriesForMs(arr, AVG_WINDOW_MS));
    }

    function ramMaxAll(key, arr) {
        if (ramPeak[key] != null)
            return ramPeak[key];
        if (!arr || !arr.length)
            return null;
        var m = arr[0];
        var i;
        for (i = 1; i < arr.length; i++) {
            if (arr[i] > m)
                m = arr[i];
        }
        return m;
    }

    function fmtTimeAgoShort(ms) {
        var s = Math.max(0, Math.round(ms / 1000));
        if (s < 60)
            return "−" + s + " с";
        var m = Math.round(s / 60);
        if (m < 60)
            return "−" + m + " м";
        var h = Math.round(m / 60);
        return "−" + h + " ч";
    }

    function scaleOptionsHtml() {
        var html = "";
        var i;
        for (i = 0; i < POP_SCALES.length; i++) {
            var sc = POP_SCALES[i];
            html += "<option value=\"" + sc.ms + "\"" +
                (sc.ms === popScaleMs ? " selected" : "") + ">" + sc.label + "</option>";
        }
        return html;
    }

    function fmtCpu(v) {
        if (v === null || v === undefined || isNaN(v))
            return "—";
        var n = Number(v);
        if (n < 0.05)
            return "0 %";
        if (n < 10)
            return n.toFixed(1) + " %";
        return Math.round(n) + " %";
    }

    function fmtRam(v) {
        if (v === null || v === undefined || isNaN(v))
            return "—";
        var n = Number(v);
        if (n > 0 && n < 10)
            return n.toFixed(1) + " МБ";
        return Math.round(n) + " МБ";
    }

    function fmtRamBar() {
        if (last.sysRamTotal == null || isNaN(last.sysRamTotal))
            return "—";
        if (last.sysRam == null || isNaN(last.sysRam))
            return Math.round(last.sysRamTotal) + " МБ";
        return Math.round(last.sysRam) + "/" + Math.round(last.sysRamTotal) + " МБ";
    }

    function fmtRssMiB(v) {
        if (v === null || v === undefined || isNaN(v))
            return "—";
        var n = Number(v);
        var kb = n * 1024;
        if (kb > 0 && kb < 1024)
            return Math.round(kb) + " КБ";
        return fmtRam(n);
    }

    /** web CPU в кнопке = все qBit (с дочерними) + демон */
    function combinedWebCpu() {
        var panel = last.panelCpu != null && !isNaN(last.panelCpu) ? Number(last.panelCpu) : 0;
        var col = last.colCpu != null && !isNaN(last.colCpu) ? Number(last.colCpu) : 0;
        return Math.min(100, panel + col);
    }

    /** qb RAM = RSS qBittorrent + демон метрик */
    function combinedWebRam() {
        var panel = last.panelRam != null && !isNaN(last.panelRam) ? Number(last.panelRam) : 0;
        var col = last.colRam != null && !isNaN(last.colRam) ? Number(last.colRam) : 0;
        if (last.panelRam == null && last.colRam == null)
            return 0;
        return panel + col;
    }

    function syncWebCpuLabel(doPush) {
        if (!want.webCpu)
            return;
        if (last.panelCpu == null && last.colCpu == null) {
            last.webCpu = null;
            setLabel("fkShellCpu", "—");
            return;
        }
        var raw = combinedWebCpu();
        last.webCpu = ema("webCpu", raw);
        if (doPush)
            push(hist.shellCpu, last.webCpu);
        setLabel("fkShellCpu", fmtCpu(last.webCpu));
    }

    function syncWebRamLabel(doPush) {
        if (!want.webRam)
            return;
        if (last.panelRam == null && last.colRam == null) {
            last.webRam = null;
            setLabel("fkShellRam", "—");
            return;
        }
        var raw = combinedWebRam();
        last.webRam = ema("webRam", raw);
        if (doPush) {
            push(hist.shellRam, last.webRam);
            noteRamPeak("shellRam", last.webRam);
            if (last.panelRam != null) {
                push(hist.panelRam, last.panelRam);
                noteRamPeak("panelRam", last.panelRam);
            }
            if (last.colRam != null) {
                push(hist.colRam, last.colRam);
                noteRamPeak("colRam", last.colRam);
            }
        }
        setLabel("fkShellRam", fmtRssMiB(last.webRam));
    }

    function setLabel(id, text) {
        var el = document.getElementById(id);
        if (el)
            setTextIfChanged(el, text);
    }

    /** не трогать DOM, если текст тот же — иначе сбрасывается выделение при копировании */
    function setTextIfChanged(el, text) {
        if (!el)
            return false;
        var t = text == null ? "" : String(text);
        if (el.textContent === t)
            return false;
        el.textContent = t;
        return true;
    }

    function setStyleIfChanged(el, prop, value) {
        if (!el)
            return false;
        var cur = el.style[prop];
        var next = value == null ? "" : String(value);
        if (cur === next)
            return false;
        el.style[prop] = next;
        return true;
    }

    /** пользователь выделяет текст в попапе — не переписывать DOM */
    function isSelectingInPopover() {
        try {
            var sel = window.getSelection && window.getSelection();
            if (!sel || sel.isCollapsed || !sel.rangeCount)
                return false;
            var n = sel.anchorNode;
            if (!n)
                return false;
            var el = n.nodeType === 1 ? n : n.parentElement;
            return !!(el && el.closest && el.closest(".fk-syspop"));
        }
        catch (e) {
            return false;
        }
    }

    function liteUiMode() {
        try {
            return !!(window.clientData && window.clientData.get
                && window.clientData.get("use_virtual_list") === true);
        }
        catch (e) {
            return false;
        }
    }

    function setCellVisible(cellId, sepId, on) {
        var cell = document.getElementById(cellId);
        if (cell)
            cell.classList.toggle("invisible", !on);
        if (sepId) {
            var sep = document.getElementById(sepId);
            if (sep)
                sep.classList.toggle("invisible", !on);
        }
    }

    function isStatusCellVisible(td) {
        if (!td || td.classList.contains("statusBarSeparator"))
            return false;
        if (td.classList.contains("invisible"))
            return false;
        if (td.querySelector("img, button, input, select, canvas, svg"))
            return true;
        return String(td.textContent || "").replace(/\u00a0/g, " ").trim().length > 0;
    }

    /**
     * Ровно один разделитель между соседними видимыми пунктами.
     * Пустые externalIPs/DHT и т.п. не считаются — иначе «дыра» из двух sep.
     */
    function normalizeStatusBarSeparators() {
        var free = document.getElementById("freeSpaceOnDisk");
        if (!free || !free.parentNode)
            return;
        var cells = Array.prototype.slice.call(free.parentNode.children);
        var i;
        var j;
        for (i = 0; i < cells.length; i++) {
            if (cells[i].classList.contains("statusBarSeparator"))
                cells[i].classList.add("invisible");
        }
        // пустые опциональные слоты не оставляют «дыру» между sep
        ["externalIPs", "DHTNodes"].forEach(function (id) {
            var el = document.getElementById(id);
            if (el && !String(el.textContent || "").replace(/\u00a0/g, " ").trim())
                el.classList.add("invisible");
        });
        var visible = [];
        for (i = 0; i < cells.length; i++) {
            if (cells[i].classList.contains("statusBarSeparator"))
                continue;
            if (!isStatusCellVisible(cells[i]))
                continue;
            visible.push(cells[i]);
        }
        for (i = 0; i < visible.length - 1; i++) {
            var ai = cells.indexOf(visible[i]);
            var bi = cells.indexOf(visible[i + 1]);
            var sep = null;
            for (j = bi - 1; j > ai; j--) {
                if (cells[j].classList.contains("statusBarSeparator")) {
                    sep = cells[j];
                    break;
                }
            }
            if (sep)
                sep.classList.remove("invisible");
        }
    }

    function applyVisibility() {
        var on = daemonOk;
        setCellVisible("fkSysCpuCell", "fkSysCpuSep", on && want.cpu);
        setCellVisible("fkSysRamCell", "fkSysRamSep", on && want.ram);
        setCellVisible("fkShellCpuCell", "fkShellCpuSep", on && want.webCpu);
        setCellVisible("fkShellRamCell", "fkShellRamSep", on && want.webRam);
        setCellVisible("fkCacheCell", null, on && want.cache);
        /* старый хвостовой sep после Кэш — убрать из DOM */
        var cacheSep = document.getElementById("fkCacheSep");
        if (cacheSep && cacheSep.parentNode)
            cacheSep.parentNode.removeChild(cacheSep);
        var menuWrap = document.getElementById("fkSysMenuWrap");
        if (menuWrap)
            menuWrap.classList.toggle("invisible", !on);
        var menuSep = document.getElementById("fkSysMenuSep");
        if (menuSep && menuSep.parentNode)
            menuSep.parentNode.removeChild(menuSep);
        if (!on || !want.cpu) {
            last.sysCpu = null;
            hist.sysCpu.length = 0;
        }
        if (!on || (!want.cpu && !want.webCpu)) {
            last.cores = [];
            hist.cores = [];
        }
        if (!on || !want.ram) {
            last.sysRam = null;
            last.sysRamTotal = null;
            last.sysVmem = last.sysVmemTotal = last.sysVmemKind = null;
            hist.sysRam.length = 0;
            hist.sysVmem.length = 0;
            ramPeak.sysRam = null;
        }
        if (!on || !want.webCpu) {
            last.shellCpu = null;
            last.panelCpu = null;
            last.colCpu = null;
            last.webCpu = null;
            hist.shellCpu.length = 0;
        }
        if (!on || !want.webRam) {
            last.shellRam = null;
            last.panelRam = null;
            last.colRam = null;
            last.webRam = null;
            hist.shellRam.length = 0;
            hist.panelRam.length = 0;
            hist.colRam.length = 0;
            ramPeak.shellRam = ramPeak.colRam = ramPeak.panelRam = null;
        }
        if (!on || !want.cache) {
            wipeCacheMemory();
            hidePopoverKey("cache");
        }
        if (!on) {
            hideAllPopovers();
        }
        else {
            if (!want.cpu)
                hidePopoverKey("sysCpu");
            if (!want.ram)
                hidePopoverKey("sysRam");
            if (!want.webCpu)
                hidePopoverKey("shellCpu");
            if (!want.webRam)
                hidePopoverKey("shellRam");
            if (!want.cache)
                hidePopoverKey("cache");
            placeAllPopovers();
        }
        normalizeStatusBarSeparators();
    }

    function cacheCellHtml() {
        /* unicode — подпись «Кэш»; без хвостового sep — дальше freeSpace сам */
        return "<td class=\"fk-sysbar\" id=\"fkCacheCell\" title=\"\u041a\u044d\u0448 \u0434\u0438\u0441\u043a\u0430\">" +
            "<span class=\"fk-sysbar-name\">\u041a\u044d\u0448</span> " +
            "<span id=\"fkCache\">0 %</span></td>";
    }

    function ensureBar() {
        if (document.getElementById("fkSysCpu")) {
            if (!document.getElementById("fkCacheCell")) {
                var ramSep = document.getElementById("fkShellRamSep");
                if (ramSep)
                    ramSep.insertAdjacentHTML("afterend", cacheCellHtml());
                else {
                    var ramCell = document.getElementById("fkShellRamCell");
                    if (ramCell)
                        ramCell.insertAdjacentHTML("afterend",
                            "<td class=\"statusBarSeparator\" id=\"fkShellRamSep\"></td>" + cacheCellHtml());
                }
                bindClick("fkCacheCell", "cache");
                applyVisibility();
            }
            if (!document.getElementById("fkSysMenuBtn"))
                ensureMenu();
            return true;
        }
        var free = document.getElementById("freeSpaceOnDisk");
        if (!free || !free.parentNode)
            return false;

        free.insertAdjacentHTML("beforebegin",
            "<td class=\"fk-sysbar\" id=\"fkSysCpuCell\" title=\"CPU системы\">CPU <span id=\"fkSysCpu\">—</span></td>" +
            "<td class=\"statusBarSeparator\" id=\"fkSysCpuSep\"></td>" +
            "<td class=\"fk-sysbar\" id=\"fkSysRamCell\" title=\"ОЗУ системы\">RAM <span id=\"fkSysRam\">—</span></td>" +
            "<td class=\"statusBarSeparator\" id=\"fkSysRamSep\"></td>" +
            "<td class=\"fk-sysbar\" id=\"fkShellCpuCell\" title=\"CPU qBittorrent\">qCPU <span id=\"fkShellCpu\">—</span></td>" +
            "<td class=\"statusBarSeparator\" id=\"fkShellCpuSep\"></td>" +
            "<td class=\"fk-sysbar\" id=\"fkShellRamCell\" title=\"ОЗУ qBittorrent\">qRAM <span id=\"fkShellRam\">—</span></td>" +
            "<td class=\"statusBarSeparator\" id=\"fkShellRamSep\"></td>" +
            cacheCellHtml());

        bindClick("fkSysCpuCell", "sysCpu");
        bindClick("fkSysRamCell", "sysRam");
        bindClick("fkShellCpuCell", "shellCpu");
        bindClick("fkShellRamCell", "shellRam");
        bindClick("fkCacheCell", "cache");
        ensureMenu();
        applyVisibility();
        return true;
    }

    function pollLabel(ms) {
        if (ms === 500)
            return "0.5 с";
        if (ms === 1000)
            return "1 с";
        if (ms < 1000)
            return ms + " мс";
        var s = ms / 1000;
        return (s === Math.floor(s) ? String(s) : s.toFixed(1)) + " с";
    }

    function ensureMenu() {
        if (document.getElementById("fkSysMenuBtn"))
            return;
        var up = document.getElementById("UpInfos");
        var anchor = up ? up.closest("td") : null;
        if (!anchor || !anchor.parentNode)
            return;
        var opts = "";
        var i;
        for (i = 0; i < POLL_CHOICES.length; i++) {
            var ms = POLL_CHOICES[i];
            opts += "<option value=\"" + ms + "\">" + pollLabel(ms) + "</option>";
        }
        anchor.insertAdjacentHTML("afterend",
            "<td id=\"fkSysMenuWrap\" class=\"fk-sysmenu-cell\">" +
            "<button type=\"button\" id=\"fkSysMenuBtn\" class=\"fk-sysmenu-btn\" title=\"Панель ресурсов\" aria-label=\"Панель ресурсов\">⋮</button>" +
            "<div id=\"fkSysMenu\" class=\"fk-sysmenu invisible\">" +
            "<label class=\"fk-sysmenu-item\"><input type=\"checkbox\" data-want=\"cpu\"> CPU</label>" +
            "<label class=\"fk-sysmenu-item\"><input type=\"checkbox\" data-want=\"ram\"> RAM</label>" +
            "<label class=\"fk-sysmenu-item\"><input type=\"checkbox\" data-want=\"webCpu\"> qCPU</label>" +
            "<label class=\"fk-sysmenu-item\"><input type=\"checkbox\" data-want=\"webRam\"> qRAM</label>" +
            "<label class=\"fk-sysmenu-item\"><input type=\"checkbox\" data-want=\"cache\"> Кэш</label>" +
            "<div class=\"fk-sysmenu-sep\"></div>" +
            "<label class=\"fk-sysmenu-poll\">Обновление" +
            "<select id=\"fkSysPollSel\">" + opts + "</select></label>" +
            "<div class=\"fk-sysmenu-note\">опрос системы с выбранным интервалом</div>" +
            "</div></td>");
        menuEl = document.getElementById("fkSysMenu");
        // меню на body — иначе overflow футера/панелей обрезает
        if (menuEl && menuEl.parentNode !== document.body)
            document.body.appendChild(menuEl);
        var btn = document.getElementById("fkSysMenuBtn");
        btn.addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            hideAllPopovers();
            syncMenuChecks();
            if (menuEl.classList.contains("invisible"))
                showMenu();
            else
                hideMenu();
        });
        menuEl.addEventListener("click", function (e) {
            e.stopPropagation();
        });
        menuEl.querySelectorAll("input[data-want]").forEach(function (inp) {
            inp.addEventListener("change", function () {
                var key = inp.getAttribute("data-want");
                if (!key || !Object.prototype.hasOwnProperty.call(want, key))
                    return;
                want[key] = !!inp.checked;
                saveWant();
                if (key === "cache") {
                    /* как переключатель «сбор» в попапе Кэш */
                    setCacheCollect(want.cache, false);
                    applyVisibility();
                    return;
                }
                applyVisibility();
                tick();
            });
        });
        var sel = document.getElementById("fkSysPollSel");
        if (sel) {
            sel.value = String(pollMs);
            sel.addEventListener("change", function () {
                savePollMs(Number(sel.value));
            });
        }
    }

    function placeMenu() {
        if (!menuEl)
            return;
        var btn = document.getElementById("fkSysMenuBtn");
        if (!btn)
            return;
        var r = btn.getBoundingClientRect();
        var mw = menuEl.offsetWidth || 168;
        var mh = menuEl.offsetHeight || 160;
        var left = Math.max(6, Math.min(r.right - mw, window.innerWidth - mw - 6));
        var top = r.top - mh - 6;
        if (top < 6)
            top = Math.min(window.innerHeight - mh - 6, r.bottom + 6);
        menuEl.style.left = left + "px";
        menuEl.style.top = top + "px";
        menuEl.style.right = "auto";
        menuEl.style.bottom = "auto";
    }

    function showMenu() {
        if (!menuEl)
            return;
        menuEl.classList.remove("invisible");
        placeMenu();
        requestAnimationFrame(placeMenu);
    }

    function syncMenuChecks() {
        if (!menuEl)
            return;
        menuEl.querySelectorAll("input[data-want]").forEach(function (inp) {
            var key = inp.getAttribute("data-want");
            if (key && Object.prototype.hasOwnProperty.call(want, key))
                inp.checked = !!want[key];
        });
        var sel = document.getElementById("fkSysPollSel");
        if (sel)
            sel.value = String(pollMs);
    }

    function hideMenu() {
        if (menuEl)
            menuEl.classList.add("invisible");
    }

    function bindClick(cellId, key) {
        var cell = document.getElementById(cellId);
        if (!cell)
            return;
        cell.addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            hideMenu();
            togglePopover(cell, key);
        });
    }

    var POP_META = {
        sysCpu: {
            title: "CPU системы",
            isCpu: true,
            hasMain: true,
            hint: "Загрузка процессора системы (все ядра)"
        },
        sysRam: {
            title: "ОЗУ системы",
            isCpu: false,
            hasMain: true,
            hint: "Оперативная память системы. Среднее — за 10 мин, макс — за всё время сессии."
        },
        shellCpu: {
            title: "CPU qBittorrent",
            isCpu: true,
            hasMain: true,
            hint: ""
        },
        shellRam: {
            title: "ОЗУ qBittorrent",
            isCpu: false,
            hasMain: true,
            hint: ""
        },
        cache: {
            title: "Кэш диска",
            isCpu: false,
            hasMain: true,
            hint: ""
        }
    };

    function hideAllPopovers() {
        Object.keys(popovers).forEach(function (k) {
            hidePopoverKey(k);
        });
    }

    function hidePopoverKey(key) {
        var p = popovers[key];
        if (!p)
            return;
        if (p.el && p.el.parentNode)
            p.el.parentNode.removeChild(p.el);
        delete popovers[key];
    }

    function hidePopover() {
        hideAllPopovers();
    }

    function anyPopoverOpen() {
        return Object.keys(popovers).length > 0;
    }

    function pushCores(cores) {
        if (!cores || !cores.length) {
            last.cores = [];
            return;
        }
        last.cores = cores.slice();
        var i;
        while (hist.cores.length < cores.length)
            hist.cores.push([]);
        if (hist.cores.length > cores.length)
            hist.cores.length = cores.length;
        for (i = 0; i < cores.length; i++) {
            var sm = ema("core" + i, cores[i]);
            push(hist.cores[i], sm);
            last.cores[i] = sm;
        }
    }

    function coresBreakdownHtml(idPrefix) {
        var pfx = idPrefix || "fkSysPop";
        var n = last.cores.length || (hist.cores && hist.cores.length) || 0;
        if (!n)
            return "<div class=\"fk-syspop-hint\">ждём разбивку по ядрам…</div>";
        var html = "<div class=\"fk-syspop-col-title\">По ядрам</div><div class=\"fk-syspop-cores\" id=\"" + pfx + "Cores\">";
        var i;
        for (i = 0; i < n; i++) {
            var v = last.cores[i] != null ? last.cores[i] : null;
            html += "<div class=\"fk-syspop-core-row\">" +
                "<span class=\"fk-syspop-core-lbl\">CPU" + i + "</span>" +
                "<b class=\"fk-syspop-core-val\" id=\"" + pfx + "CoreVal" + i + "\">" + fmtCpu(v) + "</b>" +
                "<canvas class=\"fk-syspop-core-cv\" id=\"" + pfx + "CoreCv" + i + "\" width=\"200\" height=\"36\"></canvas>" +
                "</div>";
        }
        html += "</div>";
        return html;
    }

    function redrawCoresIn(el, idPrefix) {
        if (!el)
            return;
        var pfx = idPrefix || "fkSysPop";
        var i;
        var n = Math.max(last.cores.length, hist.cores.length);
        for (i = 0; i < n; i++) {
            var valEl = el.querySelector("#" + pfx + "CoreVal" + i);
            var cv = el.querySelector("#" + pfx + "CoreCv" + i);
            if (valEl)
                setTextIfChanged(valEl, fmtCpu(last.cores[i]));
            if (cv)
                drawSpark(cv, seriesForScale(hist.cores[i] || []), CORE_COLORS[i % CORE_COLORS.length], true, el, {
                    max: 100,
                    fixedScale: true
                });
        }
    }

    function refreshCoresBox(el, idPrefix) {
        if (!el)
            return;
        var pfx = idPrefix || "fkSysPop";
        var box = el.querySelector("#" + pfx + "Cores");
        var need = last.cores.length;
        if (box && need && box.querySelectorAll(".fk-syspop-core-row").length !== need) {
            if (isSelectingInPopover())
                return;
            var wrap = box.parentNode;
            if (wrap)
                wrap.innerHTML = coresBreakdownHtml(pfx);
        }
        else if (!box && need) {
            if (isSelectingInPopover())
                return;
            var host = el.querySelector(".fk-syspop-cores-host");
            if (host)
                host.innerHTML = coresBreakdownHtml(pfx);
        }
    }

    function xaxisHtml(extraClass) {
        return "<div class=\"fk-syspop-xaxis" + (extraClass ? " " + extraClass : "") + "\" aria-hidden=\"true\">" +
            "<span class=\"fk-syspop-x0\"></span><span class=\"fk-syspop-x1\"></span><span class=\"fk-syspop-x2\">сейчас</span>" +
            "</div>";
    }

    /** метрики самого демона статистики (fk_col_*) есть в ответе */
    function hasDaemonCpu() {
        return daemonOk && last.colCpu != null && !isNaN(last.colCpu);
    }

    function hasDaemonRam() {
        return daemonOk && last.colRam != null && !isNaN(last.colRam);
    }

    function mainChartHtml(title) {
        var head = title
            ? "<div class=\"fk-syspop-col-title\">" + title + "</div>"
            : "";
        return head +
            "<div class=\"fk-syspop-chart-wrap\">" +
            "<div class=\"fk-syspop-plot\">" +
            "<div class=\"fk-syspop-yaxis\" aria-hidden=\"true\">" +
            "<span data-yt>—</span><span data-ym>—</span><span data-yb>0</span></div>" +
            "<div class=\"fk-syspop-canvas-wrap\">" +
            "<canvas class=\"fk-syspop-main-cv\" width=\"220\" height=\"72\"></canvas>" +
            "</div></div>" +
            "<div class=\"fk-syspop-foot\">" +
            "<div class=\"fk-syspop-yaxis-gutter\" aria-hidden=\"true\"></div>" +
            xaxisHtml() +
            "</div></div>";
    }

    function webCpuBreakdownHtml() {
        var withDaemon = hasDaemonCpu();
        var title = withDaemon
            ? "Состав: qBittorrent + демон статистики"
            : "Состав: qBittorrent";
        var daemonRow = withDaemon
            ? "<div class=\"fk-syspop-core-row fk-syspop-daemon\">" +
                "<b class=\"fk-syspop-core-val fk-syspop-c-daemon\" id=\"fkSysPopColCpu\">" + fmtCpu(last.colCpu) + "</b>" +
                "<canvas class=\"fk-syspop-core-cv\" id=\"fkSysPopColCv\" width=\"200\" height=\"36\"></canvas>" +
                "</div>"
            : "";
        return "<div class=\"fk-syspop-collector fk-syspop-cores-host\">" +
            coresBreakdownHtml("fkQbitPop") +
            "</div>" +
            "<div class=\"fk-syspop-collector\">" +
            "<div class=\"fk-syspop-col-title\" data-compose-title>" + title + "</div>" +
            "<div class=\"fk-syspop-cores fk-syspop-cores-compact\">" +
            "<div class=\"fk-syspop-core-row\">" +
            "<b class=\"fk-syspop-core-val fk-syspop-c-qbit\" id=\"fkSysPopPanelCpu\">" + fmtCpu(last.panelCpu) + "</b>" +
            "<canvas class=\"fk-syspop-core-cv\" id=\"fkSysPopPanelCv\" width=\"200\" height=\"36\"></canvas>" +
            "</div>" +
            daemonRow +
            "</div>" +
            "<div class=\"fk-syspop-spark-foot\">" +
            "<div class=\"fk-syspop-spark-gutter fk-syspop-spark-gutter-sm\" aria-hidden=\"true\"></div>" +
            xaxisHtml() +
            "</div></div>";
    }

    function collectorHtml() {
        var html = "<div class=\"fk-syspop-collector\">" +
            "<div class=\"fk-syspop-row\">qBittorrent: " +
            "<b class=\"fk-syspop-num\" id=\"fkSysPopPanelRss\">" + fmtRssMiB(last.panelRam) + "</b></div>";
        if (hasDaemonRam()) {
            var colAvg = avg10m(hist.colRam);
            var colMax = ramMaxAll("colRam", hist.colRam);
            html += "<div class=\"fk-syspop-row fk-syspop-daemon\">демон статистики: " +
                "<b class=\"fk-syspop-num\" id=\"fkSysPopColRss\">" + fmtRssMiB(last.colRam) + "</b></div>" +
                "<div class=\"fk-syspop-row fk-syspop-daemon\">демон · среднее (10 м): " +
                "<b class=\"fk-syspop-num\" data-col-avg>" + fmtRssMiB(colAvg) + "</b></div>" +
                "<div class=\"fk-syspop-row fk-syspop-daemon\">демон · макс: " +
                "<b class=\"fk-syspop-num\" data-col-max>" + fmtRssMiB(colMax) + "</b></div>";
        }
        return html + "</div>";
    }

    function hasSysVmem() {
        /* показывать только если своп/zram реально занят — не «0 / 1024 МБ» */
        return !!(last.sysVmemKind && last.sysVmemTotal != null && last.sysVmemTotal > 0
            && last.sysVmem != null && Number(last.sysVmem) > 0);
    }

    function sysVmemKindLabel() {
        if (last.sysVmemKind === "zram")
            return "сжатая память — часть от общей ОЗУ";
        if (last.sysVmemKind === "swap")
            return "дисковый своп — дополнительная память сверх ОЗУ";
        return "";
    }

    function hintForKey(key) {
        if (key === "sysRam") {
            var base = "Фиолетовый — занятая ОЗУ. Среднее — за 10 мин, макс — за всё время сессии.";
            if (hasSysVmem()) {
                var kind = sysVmemKindLabel();
                return base + " Бирюзовый — VMEM (" + kind + ").";
            }
            return base;
        }
        if (key === "shellCpu") {
            if (hasDaemonCpu())
                return "Общая — сумма qBit (с дочерними) и демона. В составе: синяя — qBit, зелёная — демон. Ниже — ядра системы.";
            return "Общая — загрузка процессов qBittorrent. Ниже — ядра системы.";
        }
        if (key === "shellRam") {
            if (hasDaemonRam())
                return "Фиолетовый — RSS qBittorrent, серый — демон. Среднее — за 10 мин, макс — за всё время сессии.";
            return "RSS qBittorrent. Среднее — за 10 мин, макс — за всё время сессии.";
        }
        if (key === "cache") {
            if (!cacheCollect)
                return "Сбор выключен. Включите переключатель «сбор» справа сверху — как «Вид → Статистика»; выключение — как крестик в окне статистики.";
            return "Данные как в «Вид → Статистика». Перегрузка записи >5% — диск не успевает (должно быть меньше). Время в очереди — чем меньше, тем лучше; слабо от 200 мс, заметнее от 650 мс.";
        }
        return POP_META[key] ? POP_META[key].hint : "";
    }

    function clearCacheStats() {
        last.writeOver = last.readOver = last.avgQueue = null;
        last.queuedJobs = last.buffersSize = last.readHits = last.queuedSize = null;
        hist.writeOver.length = 0;
        hist.readOver.length = 0;
        hist.avgQueue.length = 0;
        hist.cacheMain.length = 0;
        setLabel("fkCache", "0 %");
        updateCacheCellWarn();
    }

    /** полностью убрать кэш из памяти (история + EMA + попап) */
    function wipeCacheMemory() {
        clearCacheStats();
        try {
            delete smooth.writeOver;
            delete smooth.readOver;
            delete smooth.avgQueue;
            delete smooth.cacheMain;
        }
        catch (e) { /* ignore */ }
        hidePopoverKey("cache");
    }

    function fmtPct(v) {
        if (v === null || v === undefined || isNaN(v))
            v = 0;
        var n = Number(v);
        if (n < 10)
            return n.toFixed(1) + " %";
        return Math.round(n) + " %";
    }

    function fmtMs(v) {
        if (v === null || v === undefined || isNaN(v))
            return "0 мс";
        return Math.round(Number(v)) + " мс";
    }

    function fmtBytes(v) {
        if (v === null || v === undefined || isNaN(v))
            return "0";
        try {
            if (window.qBittorrent && window.qBittorrent.Misc
                && typeof window.qBittorrent.Misc.friendlyUnit === "function")
                return window.qBittorrent.Misc.friendlyUnit(Number(v), false);
        }
        catch (e) { /* ignore */ }
        return Math.round(Number(v)) + " Б";
    }

    function cacheWriteSparkColor(series) {
        var v = last.writeOver;
        if ((v === null || v === undefined) && series && series.length)
            v = series[series.length - 1];
        if (v != null && !isNaN(v) && Number(v) > CACHE_WRITE_HOT)
            return CACHE_WRITE_HOT_COLOR;
        return CACHE_WRITE_OK_COLOR;
    }

    function numOrNull(v) {
        if (v === null || v === undefined || v === "")
            return null;
        var n = Number(v);
        return isNaN(n) ? null : n;
    }

    function updateCacheCellWarn() {
        var cell = document.getElementById("fkCacheCell");
        if (!cell)
            return;
        cell.classList.remove("fk-cache-hot", "fk-cache-queue", "fk-cache-queue-hi");
        var w = last.writeOver;
        var q = last.avgQueue;
        if (w != null && w > CACHE_WRITE_HOT)
            cell.classList.add("fk-cache-hot");
        else if (q != null && q >= CACHE_QUEUE_HARD)
            cell.classList.add("fk-cache-queue-hi");
        else if (q != null && q >= CACHE_QUEUE_SOFT)
            cell.classList.add("fk-cache-queue");
        var tip = "Кэш диска (Статистика)";
        if (w != null)
            tip += "\nПерегрузка записи: " + fmtPct(w) + (w > CACHE_WRITE_HOT ? " — выше нормы, клиент перегружен по записи" : "");
        if (q != null)
            tip += "\nСреднее время в очереди: " + fmtMs(q) + (q >= CACHE_QUEUE_SOFT ? " — желательно меньше" : "");
        cell.title = tip;
    }

    function syncCacheLabel() {
        if (!cacheCollect) {
            setLabel("fkCache", "выкл");
            var cellOff = document.getElementById("fkCacheCell");
            if (cellOff) {
                cellOff.classList.remove("fk-cache-hot", "fk-cache-queue", "fk-cache-queue-hi");
                cellOff.title = "Кэш диска — сбор выключен. Откройте попап и включите переключатель (как «Вид → Статистика»).";
            }
            return;
        }
        if (last.writeOver == null) {
            setLabel("fkCache", "0 %");
            updateCacheCellWarn();
            return;
        }
        var t = fmtPct(last.writeOver);
        if (last.avgQueue != null && last.avgQueue >= CACHE_QUEUE_SOFT)
            t += " · " + Math.round(last.avgQueue) + "мс";
        setLabel("fkCache", t);
        updateCacheCellWarn();
    }

    function syncCacheSwitchUi() {
        Object.keys(popovers).forEach(function (k) {
            if (k !== "cache")
                return;
            var sw = popovers[k].el.querySelector("[data-cache-sw]");
            if (sw)
                sw.checked = !!cacheCollect;
        });
    }

    function setCacheCollect(on, fromWindow) {
        on = !!on;
        var prev = cacheCollect;
        cacheCollect = on;
        /* fromWindow — только окно Statistics; want.cache (меню/F5) не затираем */
        if (!fromWindow && want.cache !== on) {
            want.cache = on;
            saveWant();
        }
        if (!fromWindow) {
            try {
                if (on) {
                    if (!document.getElementById("statisticspage")
                        && typeof window.StatisticsLinkFN === "function")
                        window.StatisticsLinkFN();
                }
                else {
                    var w = document.getElementById("statisticspage");
                    if (w && typeof MochaUI !== "undefined" && MochaUI.closeWindow)
                        MochaUI.closeWindow(w);
                }
            }
            catch (e) { /* ignore */ }
        }
        if (!on) {
            wipeCacheMemory();
            setLabel("fkCache", "выкл");
        }
        syncCacheLabel();
        syncCacheSwitchUi();
        syncMenuChecks();
        if (prev !== on)
            applyVisibility();
        if (popovers.cache && on) {
            refreshPopoverKey("cache");
            redrawPopoverCharts("cache");
        }
    }

    function onStatisticsOpened() {
        /* окно статистики — дополнительный источник; переключатель меню не трогаем */
        if (!cacheCollect && want.cache)
            cacheCollect = true;
        else if (!want.cache)
            setCacheCollect(true, false);
        syncCacheSwitchUi();
    }

    function onStatisticsClosed() {
        /* закрытие окна не выключает want.cache — иначе после F5 всё сбрасывалось */
        if (!want.cache && cacheCollect) {
            cacheCollect = false;
            wipeCacheMemory();
            syncCacheLabel();
            syncCacheSwitchUi();
        }
    }

    function applyCacheStats(ss) {
        if (!want.cache || !cacheCollect || !ss || typeof ss !== "object")
            return false;
        var w = numOrNull(ss.write_cache_overload);
        var r = numOrNull(ss.read_cache_overload);
        var q = numOrNull(ss.average_time_queue);
        if (w == null && r == null && q == null)
            return false;
        if (w != null) {
            last.writeOver = w;
            push(hist.writeOver, w);
            push(hist.cacheMain, w);
        }
        if (r != null) {
            last.readOver = r;
            push(hist.readOver, r);
        }
        if (q != null) {
            last.avgQueue = q;
            push(hist.avgQueue, q);
        }
        last.queuedJobs = numOrNull(ss.queued_io_jobs);
        last.buffersSize = numOrNull(ss.total_buffers_size);
        last.readHits = numOrNull(ss.read_cache_hits);
        last.queuedSize = numOrNull(ss.total_queued_size);
        syncCacheLabel();
        return true;
    }

    function cacheBreakdownHtml() {
        return "<div class=\"fk-syspop-collector\">" +
            "<div class=\"fk-syspop-col-title\">Показатели</div>" +
            "<div class=\"fk-syspop-cores\">" +
            "<div class=\"fk-syspop-core-row\">" +
            "<span class=\"fk-syspop-core-lbl\">запись</span>" +
            "<b class=\"fk-syspop-core-val\" id=\"fkCachePopWrite\">" + fmtPct(last.writeOver) + "</b>" +
            "<canvas class=\"fk-syspop-core-cv\" id=\"fkCachePopWriteCv\" width=\"200\" height=\"36\"></canvas>" +
            "</div>" +
            "<div class=\"fk-syspop-core-row\">" +
            "<span class=\"fk-syspop-core-lbl\">чтение</span>" +
            "<b class=\"fk-syspop-core-val\" id=\"fkCachePopRead\">" + fmtPct(last.readOver) + "</b>" +
            "<canvas class=\"fk-syspop-core-cv\" id=\"fkCachePopReadCv\" width=\"200\" height=\"36\"></canvas>" +
            "</div>" +
            "<div class=\"fk-syspop-core-row\">" +
            "<span class=\"fk-syspop-core-lbl\">очередь</span>" +
            "<b class=\"fk-syspop-core-val\" id=\"fkCachePopQueue\">" + fmtMs(last.avgQueue) + "</b>" +
            "<canvas class=\"fk-syspop-core-cv\" id=\"fkCachePopQueueCv\" width=\"200\" height=\"36\"></canvas>" +
            "</div></div>" +
            "<div class=\"fk-syspop-spark-foot\">" +
            "<div class=\"fk-syspop-spark-gutter\" aria-hidden=\"true\"></div>" +
            xaxisHtml() +
            "</div>" +
            "<div class=\"fk-syspop-row\">задач в очереди: <b class=\"fk-syspop-num\" data-cache-jobs>" +
            (last.queuedJobs != null ? String(last.queuedJobs) : "0") + "</b></div>" +
            "<div class=\"fk-syspop-row\">размер очереди: <b class=\"fk-syspop-num\" data-cache-qsize>" +
            fmtBytes(last.queuedSize) + "</b></div>" +
            "<div class=\"fk-syspop-row\">буфер: <b class=\"fk-syspop-num\" data-cache-buf>" +
            fmtBytes(last.buffersSize) + "</b></div>" +
            "<div class=\"fk-syspop-row\">попадания чтения: <b class=\"fk-syspop-num\" data-cache-hits>" +
            fmtPct(last.readHits) + "</b></div>" +
            "</div>";
    }

    function curValForKey(key) {
        if (key === "shellCpu")
            return last.webCpu != null ? last.webCpu : combinedWebCpu();
        if (key === "shellRam")
            return last.webRam != null ? last.webRam : combinedWebRam();
        return last[key];
    }

    function valsHtml(key, meta) {
        if (key === "cache") {
            return "<div class=\"fk-syspop-vals-row\">" +
                "<span class=\"fk-syspop-val\">перегрузка записи: <b class=\"fk-syspop-num\" data-cur>" + fmtPct(last.writeOver) + "</b></span>" +
                "<span class=\"fk-syspop-val\">среднее (10 м): <b class=\"fk-syspop-num\" data-avg>" + fmtPct(avg10m(hist.writeOver)) + "</b></span>" +
                "</div>" +
                "<div class=\"fk-syspop-vals-row\">" +
                "<span class=\"fk-syspop-val\">время в очереди: <b class=\"fk-syspop-num\" data-cache-qcur>" + fmtMs(last.avgQueue) + "</b></span>" +
                "<span class=\"fk-syspop-val\">среднее (10 м): <b class=\"fk-syspop-num\" data-cache-qavg>" + fmtMs(avg10m(hist.avgQueue)) + "</b></span>" +
                "</div>";
        }
        var fmt = meta.isCpu ? fmtCpu : fmtRam;
        var mean = avg10m(hist[key] || []);
        if (key === "sysRam" || key === "shellRam") {
            var ramMax = ramMaxAll(key, hist[key] || []);
            var stats =
                "<span class=\"fk-syspop-val\">" + (key === "sysRam" ? "занято" : "сейчас") +
                ": <b class=\"fk-syspop-num\" data-cur>" + fmt(curValForKey(key)) + "</b></span>" +
                "<span class=\"fk-syspop-val\">среднее (10 м): <b class=\"fk-syspop-num\" data-avg>" + fmt(mean) + "</b></span>" +
                "<span class=\"fk-syspop-val\">макс: <b class=\"fk-syspop-num\" data-max>" + fmt(ramMax) + "</b></span>";
            if (key === "sysRam" && last.sysRamTotal != null) {
                var html = "<div class=\"fk-syspop-vals-row\">" +
                    "<span class=\"fk-syspop-val\">всего: <b class=\"fk-syspop-num\">" + fmtRam(last.sysRamTotal) + "</b></span>" +
                    "</div>" +
                    "<div class=\"fk-syspop-vals-row\">" + stats + "</div>";
                if (hasSysVmem()) {
                    html += "<div class=\"fk-syspop-vals-row\" data-vmem-row>" +
                        "<span class=\"fk-syspop-val\">VMEM: <b class=\"fk-syspop-num\" data-vmem-cur>" +
                        fmtRam(last.sysVmem) + "</b>" +
                        (last.sysVmemTotal != null ? " / <span data-vmem-tot>" + fmtRam(last.sysVmemTotal) + "</span>" : "") +
                        "</span>" +
                        "<span class=\"fk-syspop-val fk-syspop-vmem-kind\">" + sysVmemKindLabel() + "</span>" +
                        "</div>";
                }
                return html;
            }
            return "<div class=\"fk-syspop-vals-row\">" + stats + "</div>";
        }
        return "<div class=\"fk-syspop-vals-row\">" +
            "<span class=\"fk-syspop-val\">сейчас: <b class=\"fk-syspop-num\" data-cur>" + fmt(curValForKey(key)) + "</b></span>" +
            "<span class=\"fk-syspop-val\">среднее (10 м): <b class=\"fk-syspop-num\" data-avg>" + fmt(mean) + "</b></span>" +
            "</div>";
    }

    function updateXaxisLabels(root) {
        if (!root)
            return;
        var win = effectivePopScaleMs();
        if (root.getAttribute("data-fk-xwin") === String(win))
            return;
        root.setAttribute("data-fk-xwin", String(win));
        var a = fmtTimeAgoShort(win);
        var b = fmtTimeAgoShort(win / 2);
        root.querySelectorAll(".fk-syspop-x0").forEach(function (el) { setTextIfChanged(el, a); });
        root.querySelectorAll(".fk-syspop-x1").forEach(function (el) { setTextIfChanged(el, b); });
        root.querySelectorAll(".fk-syspop-x2").forEach(function (el) { setTextIfChanged(el, "сейчас"); });
    }

    function togglePopover(anchor, key) {
        var meta = POP_META[key];
        if (!meta || !anchor)
            return;
        if (popovers[key]) {
            hidePopoverKey(key);
            placeAllPopovers();
            return;
        }
        var el = document.createElement("div");
        el.className = "fk-syspop" + (meta.hasMain ? "" : " fk-syspop-nomain");
        el.setAttribute("data-fk-pop", key);
        el.style.width = POP_W + "px";

        var breakdown = "";
        if (key === "sysCpu")
            breakdown = "<div class=\"fk-syspop-collector fk-syspop-cores-host\">" + coresBreakdownHtml("fkSysPop") + "</div>";
        else if (key === "shellCpu")
            breakdown = webCpuBreakdownHtml();
        else if (key === "shellRam")
            breakdown = collectorHtml();
        else if (key === "cache")
            breakdown = cacheBreakdownHtml();

        var main = "";
        if (meta.hasMain) {
            if (key === "shellCpu")
                main = mainChartHtml("Общая");
            else if (key === "cache")
                main = mainChartHtml("Перегрузка записи");
            else
                main = mainChartHtml();
        }

        var headExtra = "";
        if (key === "cache") {
            headExtra = "<label class=\"fk-syspop-cache-sw\" title=\"Как «Вид → Статистика» / закрытие окна статистики\">" +
                "<input type=\"checkbox\" data-cache-sw" + (cacheCollect ? " checked" : "") + ">" +
                "<span>сбор</span></label>";
        }

        el.innerHTML =
            "<div class=\"fk-syspop-head\">" +
            "<div class=\"fk-syspop-title\">" + meta.title + "</div>" +
            headExtra +
            "<label class=\"fk-syspop-scale\">Интервал:" +
            "<select class=\"fk-syspop-scale-sel\">" + scaleOptionsHtml() + "</select></label>" +
            "</div>" +
            "<div class=\"fk-syspop-vals\">" + valsHtml(key, meta) + "</div>" +
            main +
            breakdown +
            "<div class=\"fk-syspop-hint\" data-hint>" + hintForKey(key) + "</div>";

        document.body.appendChild(el);
        popovers[key] = { el: el, anchor: anchor, key: key, isCpu: meta.isCpu };

        var sel = el.querySelector(".fk-syspop-scale-sel");
        if (sel) {
            sel.value = String(popScaleMs);
            sel.addEventListener("change", function () {
                savePopScale(Number(sel.value));
                syncScaleSelUi();
            });
            sel.addEventListener("click", function (e) { e.stopPropagation(); });
            syncScaleSelUi();
        }
        var cacheSw = el.querySelector("[data-cache-sw]");
        if (cacheSw) {
            cacheSw.addEventListener("change", function () {
                setCacheCollect(!!cacheSw.checked, false);
            });
            cacheSw.addEventListener("click", function (e) { e.stopPropagation(); });
        }
        el.addEventListener("pointerdown", function (e) { e.stopPropagation(); });

        updateXaxisLabels(el);
        placeAllPopovers();
        requestAnimationFrame(function () {
            placeAllPopovers();
            redrawPopoverCharts(key);
        });
    }

    function footerGapPx() {
        var margin = 6;
        var status = document.getElementById("desktopFooterWrapper")
            || document.getElementById("statusBar")
            || document.getElementById("desktopFooter");
        var footerGap = margin;
        if (status) {
            var sb = status.getBoundingClientRect();
            if (sb.top > 0 && sb.top < window.innerHeight)
                footerGap = Math.max(margin, window.innerHeight - sb.top + 4);
        }
        return footerGap;
    }

    function placeAllPopovers() {
        var keys = Object.keys(popovers);
        if (!keys.length)
            return;
        var margin = 6;
        var gap = POP_GAP;
        var footerGap = footerGapPx();
        keys.sort(function (a, b) {
            var ra = popovers[a].anchor.getBoundingClientRect().left;
            var rb = popovers[b].anchor.getBoundingClientRect().left;
            return ra - rb;
        });
        var preferred = [];
        var i;
        for (i = 0; i < keys.length; i++) {
            var rect = popovers[keys[i]].anchor.getBoundingClientRect();
            preferred.push(rect.left + rect.width / 2 - POP_W / 2);
        }
        var lefts = [];
        var cursor = margin;
        for (i = 0; i < preferred.length; i++) {
            var L = Math.max(cursor, preferred[i]);
            lefts.push(L);
            cursor = L + POP_W + gap;
        }
        var overflow = cursor - gap - (window.innerWidth - margin);
        if (overflow > 0) {
            for (i = 0; i < lefts.length; i++)
                lefts[i] -= overflow;
            if (lefts[0] < margin) {
                var shift = margin - lefts[0];
                for (i = 0; i < lefts.length; i++)
                    lefts[i] += shift;
            }
        }
        for (i = 0; i < keys.length; i++) {
            var el = popovers[keys[i]].el;
            setStyleIfChanged(el, "width", POP_W + "px");
            setStyleIfChanged(el, "left", Math.max(margin, lefts[i]) + "px");
            setStyleIfChanged(el, "right", "auto");
            setStyleIfChanged(el, "top", "auto");
            setStyleIfChanged(el, "bottom", footerGap + "px");
            setStyleIfChanged(el, "maxHeight",
                Math.min(window.innerHeight - footerGap - margin, 480) + "px");
        }
    }

    function setYaxisLabels(rootEl, max, isCpu) {
        if (!rootEl)
            return;
        var yaxis = rootEl.querySelector(".fk-syspop-yaxis");
        if (!yaxis)
            return;
        var key = String(Math.round(max)) + (isCpu ? "c" : "m");
        if (yaxis.getAttribute("data-fk-ymax") === key)
            return;
        yaxis.setAttribute("data-fk-ymax", key);
        var top = yaxis.querySelector("[data-yt]");
        var mid = yaxis.querySelector("[data-ym]");
        var bot = yaxis.querySelector("[data-yb]");
        var unit = isCpu ? "%" : " МБ";
        setTextIfChanged(top, Math.round(max) + unit);
        setTextIfChanged(mid, Math.round(max * 0.5) + unit);
        setTextIfChanged(bot, "0" + (isCpu ? "%" : ""));
    }

    function seriesFill(color) {
        if (color === "#a855f7")
            return "rgba(168,85,247,0.28)";
        if (color === "#3b82f6")
            return "rgba(59,130,246,0.22)";
        if (color === "#22c55e")
            return "rgba(34,197,94,0.20)";
        if (color === "#f59e0b" || color === "#fb923c")
            return "rgba(251,146,60,0.18)";
        if (color === "#ef4444" || color === CACHE_WRITE_HOT_COLOR || color === "#b45a5a")
            return "rgba(180,90,90,0.22)";
        if (color === CACHE_WRITE_OK_COLOR || color === "#86efac")
            return "rgba(134,239,172,0.22)";
        if (color === "#0d9488")
            return "rgba(13,148,136,0.14)";
        if (String(color).indexOf("120,120,120") >= 0 || color === "#9ca3af")
            return "rgba(120,120,120,0.20)";
        return "rgba(245,158,11,0.20)";
    }

    function drawSpark(canvas, series, color, isCpu, rootEl, opt) {
        if (!canvas)
            return;
        opt = opt || {};
        var series2 = opt.series2 || null;
        var color2 = opt.color2 || "#fb923c";
        var dpr = window.devicePixelRatio || 1;
        var isMain = canvas.classList.contains("fk-syspop-main-cv");
        var isCore = canvas.classList.contains("fk-syspop-core-cv");
        var cssH = isCore ? 36 : 72;
        canvas.style.width = "100%";
        canvas.style.height = cssH + "px";
        var cssW = Math.floor(canvas.getBoundingClientRect().width);
        if (!cssW || cssW < 40) {
            if (isMain)
                cssW = Math.max(100, (rootEl ? rootEl.clientWidth : POP_W) - POP_YAXIS_W - 24);
            else
                cssW = 120;
        }
        var pw = Math.floor(cssW * dpr);
        var ph = Math.floor(cssH * dpr);
        if (canvas.width !== pw || canvas.height !== ph) {
            canvas.width = pw;
            canvas.height = ph;
        }
        var ctx = canvas.getContext("2d");
        if (!ctx)
            return;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, cssW, cssH);

        var mini = !isMain;
        var padL = 1;
        var padR = 1;
        var padT = mini ? 2 : 3;
        var padB = mini ? 2 : 3;
        var plotW = Math.max(1, cssW - padL - padR);
        var plotH = Math.max(1, cssH - padT - padB);

        if (mini) {
            ctx.fillStyle = "rgba(127,127,127,0.10)";
            ctx.fillRect(padL, padT, plotW, plotH);
        }

        var max = 1;
        var i;
        var n = series ? series.length : 0;
        var n2 = series2 ? series2.length : 0;
        var len = Math.max(n, n2);
        var noStack = !!(series2 && opt.stack === false);
        for (i = 0; i < len; i++) {
            var a = (series && i < n) ? Number(series[i]) || 0 : 0;
            var b = (series2 && i < n2) ? Number(series2[i]) || 0 : 0;
            if (noStack) {
                if (a > max)
                    max = a;
                if (b > max)
                    max = b;
            }
            else {
                var sum = series2 ? (a + b) : a;
                if (sum > max)
                    max = sum;
            }
        }
        if (opt.max != null && !isNaN(Number(opt.max)) && Number(opt.max) > 0) {
            /* fixedScale: ось ровно opt.max (CPU системы 0…100%), иначе «не ниже» */
            max = opt.fixedScale ? Number(opt.max) : Math.max(max, Number(opt.max));
        }
        else if (isCpu)
            max = Math.max(max, 5);
        else if (opt.fitData)
            max = Math.max(max * 1.15, 4);
        else
            max = Math.max(max, last.sysRamTotal || 8);

        if (isMain)
            setYaxisLabels(rootEl, max, isCpu);

        if (isMain) {
            ctx.strokeStyle = "rgba(127,127,127,0.28)";
            ctx.lineWidth = 1;
            var ticks = [1, 0.5, 0];
            for (i = 0; i < ticks.length; i++) {
                var ty = padT + (1 - ticks[i]) * plotH;
                ctx.beginPath();
                ctx.moveTo(padL, ty);
                ctx.lineTo(padL + plotW, ty);
                ctx.stroke();
            }
        }

        if (!len) {
            if (isMain) {
                ctx.fillStyle = "rgba(140,140,140,0.9)";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText("ждём данные…", padL + plotW / 2, padT + plotH / 2);
            }
            return;
        }

        var denom = Math.max(1, len - 1);

        function yOf(v) {
            return padT + plotH - (Math.min(Math.max(v, 0), max) / max) * plotH;
        }

        function xOf(idx) {
            return padL + (idx / denom) * plotW;
        }

        function strokeFill(arr, stroke, fill, baseArr) {
            if (!arr || !arr.length)
                return;
            var j;
            var useBase = baseArr && baseArr.length;
            if (fill) {
                ctx.beginPath();
                for (j = 0; j < len; j++) {
                    var vTop = (j < arr.length ? arr[j] : 0) + (useBase && j < baseArr.length ? baseArr[j] : 0);
                    var x = xOf(j);
                    if (j === 0)
                        ctx.moveTo(x, yOf(vTop));
                    else
                        ctx.lineTo(x, yOf(vTop));
                }
                for (j = len - 1; j >= 0; j--) {
                    var vBot = useBase && j < baseArr.length ? baseArr[j] : 0;
                    ctx.lineTo(xOf(j), yOf(vBot));
                }
                ctx.closePath();
                ctx.fillStyle = fill;
                ctx.fill();
            }
            ctx.beginPath();
            for (j = 0; j < len; j++) {
                var vv = (j < arr.length ? arr[j] : 0) + (useBase && j < baseArr.length ? baseArr[j] : 0);
                if (j === 0)
                    ctx.moveTo(xOf(j), yOf(vv));
                else
                    ctx.lineTo(xOf(j), yOf(vv));
            }
            ctx.strokeStyle = stroke;
            ctx.lineWidth = mini ? 1.5 : 1.75;
            ctx.stroke();
        }

        var tracks = [];
        function trackOf(arr, stroke, stackedOn) {
            if (!arr || !arr.length)
                return;
            var lastI = len - 1;
            var raw = Number(arr[Math.min(lastI, arr.length - 1)]) || 0;
            var base = stackedOn && lastI < stackedOn.length ? Number(stackedOn[lastI]) || 0 : 0;
            var tot = raw + base;
            tracks.push({
                arr: arr,
                stackedOn: stackedOn || null,
                color: stroke,
                v: tot,
                x: xOf(lastI),
                y: yOf(tot)
            });
        }

        if (series2) {
            if (opt.stack === false) {
                /* две независимые линии от нуля (ОЗУ + VMEM) */
                strokeFill(series || [], color, seriesFill(color), null);
                strokeFill(series2, color2, opt.fill2 || "rgba(13,148,136,0.12)", null);
                trackOf(series || [], color, null);
                trackOf(series2, color2, null);
            }
            else {
                /* снизу основная серия, сверху вторая (демон) */
                strokeFill(series || [], color, seriesFill(color), null);
                strokeFill(series2, color2, opt.fill2 || "rgba(160,160,160,0.22)", series || []);
                trackOf(series || [], color, null);
                trackOf(series2, color2, series || []);
            }
        }
        else {
            strokeFill(series || [], color, seriesFill(color), null);
            trackOf(series || [], color, null);
        }

        /* точка + число справа; текст — не чаще 1 раз/с */
        var fmtLive = opt.fmt || (isCpu ? function (v) { return fmtCpu(v); } : function (v) {
            return opt.fitData ? (Math.round(v) + (opt.unit || "")) : fmtRssMiB(v);
        });
        var now = Date.now();
        if (!canvas._fkLiveAt || now - canvas._fkLiveAt >= 1000) {
            canvas._fkLiveAt = now;
            canvas._fkLiveText = {};
            var ti;
            for (ti = 0; ti < tracks.length; ti++)
                canvas._fkLiveText[ti] = fmtLive(tracks[ti].v);
        }
        var tj;
        for (tj = 0; tj < tracks.length; tj++) {
            var tr = tracks[tj];
            ctx.fillStyle = tr.color;
            ctx.beginPath();
            ctx.arc(tr.x, tr.y, mini ? 2.2 : 2.8, 0, Math.PI * 2);
            ctx.fill();
            var txt = (canvas._fkLiveText && canvas._fkLiveText[tj]) || fmtLive(tr.v);
            if (!txt)
                continue;
            ctx.save();
            ctx.font = mini ? "9px Tahoma, Segoe UI, sans-serif" : "10px Tahoma, Segoe UI, sans-serif";
            ctx.textBaseline = "middle";
            var tw = ctx.measureText(txt).width;
            var lx = tr.x + 5;
            if (lx + tw + 4 > padL + plotW)
                lx = Math.max(padL, tr.x - tw - 6);
            var ly = Math.min(padT + plotH - 6, Math.max(padT + 6, tr.y));
            ctx.fillStyle = "rgba(255,255,255,0.88)";
            ctx.fillRect(lx - 2, ly - 7, tw + 4, 14);
            ctx.fillStyle = tr.color;
            ctx.fillText(txt, lx, ly);
            ctx.restore();
        }

        canvas._fkPlot = {
            cssW: cssW, cssH: cssH, padL: padL, padT: padT, plotW: plotW, plotH: plotH,
            max: max, len: len, isCpu: !!isCpu, fmt: fmtLive,
            tracks: tracks.map(function (t) {
                return { arr: t.arr, stackedOn: t.stackedOn, color: t.color };
            })
        };
        bindSparkHover(canvas);
    }

    function ensureSparkTip(canvas) {
        var host = canvas.parentElement;
        if (!host)
            return null;
        if (getComputedStyle(host).position === "static")
            host.style.position = "relative";
        var tip = null;
        var kids = host.children;
        var ki;
        for (ki = 0; ki < kids.length; ki++) {
            if (kids[ki].classList && kids[ki].classList.contains("fk-syspop-tip")) {
                tip = kids[ki];
                break;
            }
        }
        if (!tip) {
            tip = document.createElement("div");
            tip.className = "fk-syspop-tip invisible";
            host.appendChild(tip);
        }
        return tip;
    }

    function bindSparkHover(canvas) {
        if (!canvas || canvas.dataset.fkHoverBound)
            return;
        canvas.dataset.fkHoverBound = "1";
        var tip = ensureSparkTip(canvas);
        canvas.addEventListener("mousemove", function (e) {
            var plot = canvas._fkPlot;
            if (!plot || !plot.tracks || !plot.tracks.length || !tip) {
                if (tip)
                    tip.classList.add("invisible");
                return;
            }
            var rect = canvas.getBoundingClientRect();
            var x = e.clientX - rect.left;
            var y = e.clientY - rect.top;
            var denom = Math.max(1, plot.len - 1);
            var idx = Math.round(((x - plot.padL) / Math.max(1, plot.plotW)) * denom);
            if (idx < 0)
                idx = 0;
            if (idx >= plot.len)
                idx = plot.len - 1;
            var best = null;
            var i;
            for (i = 0; i < plot.tracks.length; i++) {
                var t = plot.tracks[i];
                if (!t.arr || !t.arr.length)
                    continue;
                var raw = Number(t.arr[Math.min(idx, t.arr.length - 1)]) || 0;
                var base = t.stackedOn ? (Number(t.stackedOn[Math.min(idx, t.stackedOn.length - 1)]) || 0) : 0;
                var tot = raw + base;
                var px = plot.padL + (idx / denom) * plot.plotW;
                var py = plot.padT + plot.plotH - (Math.min(Math.max(tot, 0), plot.max) / plot.max) * plot.plotH;
                var dist = Math.abs(py - y) + Math.abs(px - x) * 0.15;
                if (!best || dist < best.dist)
                    best = { dist: dist, v: tot, color: t.color, x: px, y: py };
            }
            if (!best || best.dist > 22) {
                tip.classList.add("invisible");
                return;
            }
            tip.textContent = plot.fmt(best.v);
            tip.style.color = best.color;
            tip.style.left = Math.max(0, Math.min(best.x + 6, plot.cssW - 56)) + "px";
            tip.style.top = Math.max(0, best.y - 16) + "px";
            tip.classList.remove("invisible");
        });
        canvas.addEventListener("mouseleave", function () {
            if (tip)
                tip.classList.add("invisible");
        });
    }

    /** выровнять длины рядов qBit/демон для стека */
    function alignSeries(a, b) {
        var aa = a ? a.slice() : [];
        var bb = b ? b.slice() : [];
        var n = Math.max(aa.length, bb.length);
        while (aa.length < n)
            aa.unshift(aa.length ? aa[0] : 0);
        while (bb.length < n)
            bb.unshift(bb.length ? bb[0] : 0);
        return { a: aa, b: bb };
    }

    function redrawPopoverCharts(onlyKey) {
        /* холст можно обновлять при выделении; текст/позицию — нет */
        syncScaleSelUi();
        var keys = onlyKey ? [onlyKey] : Object.keys(popovers);
        var ki;
        for (ki = 0; ki < keys.length; ki++) {
            var key = keys[ki];
            var p = popovers[key];
            if (!p)
                continue;
            var meta = POP_META[key];
            var el = p.el;
            updateXaxisLabels(el);
            var series = seriesForScale(key === "cache" ? hist.cacheMain : (hist[key] || []));
            var mainCv = el.querySelector(".fk-syspop-main-cv");
            if (mainCv && meta.hasMain) {
                if (key === "cache") {
                    drawSpark(mainCv, series, cacheWriteSparkColor(series), true, el);
                }
                else if (key === "shellRam") {
                    var pr = seriesForScale(hist.panelRam);
                    var cr = hasDaemonRam() ? seriesForScale(hist.colRam) : [];
                    if (!pr.length && series.length) {
                        pr = series.slice();
                        if (cr.length) {
                            var di;
                            for (di = 0; di < pr.length; di++) {
                                var ci = cr[Math.min(di, cr.length - 1)] || 0;
                                pr[di] = Math.max(0, pr[di] - ci);
                            }
                        }
                    }
                    if (cr.length) {
                        var aligned = alignSeries(pr, cr);
                        drawSpark(mainCv, aligned.a, "#a855f7", false, el, {
                            series2: aligned.b,
                            color2: "rgba(120,120,120,0.85)",
                            fill2: "rgba(120,120,120,0.20)",
                            fitData: true
                        });
                    }
                    else {
                        drawSpark(mainCv, pr.length ? pr : series, "#a855f7", false, el, { fitData: true });
                    }
                }
                else if (key === "sysRam") {
                    var vmS = hasSysVmem() ? seriesForScale(hist.sysVmem) : [];
                    if (vmS.length) {
                        var alVm = alignSeries(series, vmS);
                        var yMax = last.sysRamTotal || 8;
                        if (last.sysVmemKind === "swap" && last.sysVmemTotal != null)
                            yMax = (last.sysRamTotal || 0) + last.sysVmemTotal;
                        drawSpark(mainCv, alVm.a, "#a855f7", false, el, {
                            series2: alVm.b,
                            color2: "#0d9488",
                            fill2: "rgba(13,148,136,0.14)",
                            stack: false,
                            max: yMax
                        });
                    }
                    else {
                        drawSpark(mainCv, series, "#a855f7", false, el);
                    }
                }
                else if (key === "sysCpu") {
                    /* CPU системы: шкала всегда 0…100%, не подгонять под пик */
                    drawSpark(mainCv, series, "#f59e0b", true, el, { max: 100, fixedScale: true });
                }
                else if (key === "shellCpu") {
                    drawSpark(mainCv, series, "#f59e0b", true, el);
                }
                else {
                    drawSpark(mainCv, series, meta.isCpu ? "#f59e0b" : "#a855f7", meta.isCpu, el);
                }
            }

            if (key === "sysCpu") {
                redrawCoresIn(el, "fkSysPop");
            }
            else if (key === "shellCpu") {
                var panelEl = el.querySelector("#fkSysPopPanelCpu");
                var colEl = el.querySelector("#fkSysPopColCpu");
                if (panelEl)
                    setTextIfChanged(panelEl, fmtCpu(last.panelCpu));
                if (hasDaemonCpu()) {
                    if (colEl)
                        setTextIfChanged(colEl, fmtCpu(last.colCpu));
                    drawSpark(el.querySelector("#fkSysPopColCv"), seriesForScale(hist.colCpu), "#22c55e", true, el);
                }
                drawSpark(el.querySelector("#fkSysPopPanelCv"), seriesForScale(hist.panelCpu), "#3b82f6", true, el);
                redrawCoresIn(el, "fkQbitPop");
            }
            else if (key === "cache") {
                var wEl = el.querySelector("#fkCachePopWrite");
                var rEl = el.querySelector("#fkCachePopRead");
                var qEl = el.querySelector("#fkCachePopQueue");
                setTextIfChanged(wEl, fmtPct(last.writeOver));
                setTextIfChanged(rEl, fmtPct(last.readOver));
                setTextIfChanged(qEl, fmtMs(last.avgQueue));
                var writeSeries = seriesForScale(hist.writeOver);
                drawSpark(el.querySelector("#fkCachePopWriteCv"), writeSeries, cacheWriteSparkColor(writeSeries), true, el);
                drawSpark(el.querySelector("#fkCachePopReadCv"), seriesForScale(hist.readOver), "#3b82f6", true, el);
                /* очередь в мс — не %, своя шкала по данным */
                drawSpark(el.querySelector("#fkCachePopQueueCv"), seriesForScale(hist.avgQueue), "#f59e0b", false, el, { fitData: true });
            }
        }
    }

    function refreshAllPopovers(forceCharts, reposition) {
        if (isSelectingInPopover()) {
            if (forceCharts)
                redrawPopoverCharts();
            return;
        }
        Object.keys(popovers).forEach(function (key) {
            refreshPopoverKey(key);
        });
        if (forceCharts)
            redrawPopoverCharts();
        if (reposition)
            placeAllPopovers();
    }

    function refreshPopover() {
        if (!anyPopoverOpen())
            return;
        if (isSelectingInPopover())
            return;
        refreshAllPopovers(false, false);
        redrawPopoverCharts();
    }

    function refreshPopoverKey(key) {
        var p = popovers[key];
        if (!p)
            return;
        if (isSelectingInPopover())
            return;
        var meta = POP_META[key];
        var el = p.el;
        var curEl = el.querySelector("[data-cur]");
        var avgEl = el.querySelector("[data-avg]");
        var maxEl = el.querySelector("[data-max]");
        if (key === "cache") {
            setTextIfChanged(curEl, fmtPct(last.writeOver));
            setTextIfChanged(avgEl, fmtPct(avg10m(hist.writeOver)));
            setTextIfChanged(el.querySelector("[data-cache-qcur]"), fmtMs(last.avgQueue));
            setTextIfChanged(el.querySelector("[data-cache-qavg]"), fmtMs(avg10m(hist.avgQueue)));
            setTextIfChanged(el.querySelector("[data-cache-jobs]"),
                last.queuedJobs != null ? String(last.queuedJobs) : "0");
            setTextIfChanged(el.querySelector("[data-cache-qsize]"), fmtBytes(last.queuedSize));
            setTextIfChanged(el.querySelector("[data-cache-buf]"), fmtBytes(last.buffersSize));
            setTextIfChanged(el.querySelector("[data-cache-hits]"), fmtPct(last.readHits));
        }
        else {
            var fmt = meta.isCpu ? fmtCpu : fmtRam;
            setTextIfChanged(curEl, fmt(curValForKey(key)));
            setTextIfChanged(avgEl, fmt(avg10m(hist[key] || [])));
            if ((key === "sysRam" || key === "shellRam") && maxEl)
                setTextIfChanged(maxEl, fmt(ramMaxAll(key, hist[key] || [])));
            if (key === "sysRam") {
                var valsBox = el.querySelector(".fk-syspop-vals");
                var vRow = el.querySelector("[data-vmem-row]");
                if (hasSysVmem()) {
                    if (!vRow && valsBox) {
                        valsBox.insertAdjacentHTML("beforeend",
                            "<div class=\"fk-syspop-vals-row\" data-vmem-row>" +
                            "<span class=\"fk-syspop-val\">VMEM: <b class=\"fk-syspop-num\" data-vmem-cur>" +
                            fmtRam(last.sysVmem) + "</b>" +
                            (last.sysVmemTotal != null ? " / <span data-vmem-tot>" + fmtRam(last.sysVmemTotal) + "</span>" : "") +
                            "</span>" +
                            "<span class=\"fk-syspop-val fk-syspop-vmem-kind\">" + sysVmemKindLabel() + "</span>" +
                            "</div>");
                    }
                    else if (vRow) {
                        setTextIfChanged(vRow.querySelector("[data-vmem-cur]"), fmtRam(last.sysVmem));
                        setTextIfChanged(vRow.querySelector("[data-vmem-tot]"), fmtRam(last.sysVmemTotal));
                        setTextIfChanged(vRow.querySelector(".fk-syspop-vmem-kind"), sysVmemKindLabel());
                    }
                }
                else if (vRow && vRow.parentNode) {
                    vRow.parentNode.removeChild(vRow);
                }
            }
        }
        if (key === "shellRam") {
            setTextIfChanged(el.querySelector("#fkSysPopPanelRss"), fmtRssMiB(last.panelRam));
            var wantDaemonRam = hasDaemonRam();
            var hasDaemonRamUi = !!el.querySelector("#fkSysPopColRss");
            if (wantDaemonRam !== hasDaemonRamUi) {
                var ramHost = el.querySelector(".fk-syspop-collector");
                if (ramHost)
                    ramHost.outerHTML = collectorHtml();
            }
            else if (wantDaemonRam) {
                setTextIfChanged(el.querySelector("#fkSysPopColRss"), fmtRssMiB(last.colRam));
                setTextIfChanged(el.querySelector("[data-col-avg]"), fmtRssMiB(avg10m(hist.colRam)));
                setTextIfChanged(el.querySelector("[data-col-max]"),
                    fmtRssMiB(ramMaxAll("colRam", hist.colRam)));
            }
        }
        if (key === "shellCpu") {
            var wantDaemonCpu = hasDaemonCpu();
            var hasDaemonCpuUi = !!el.querySelector("#fkSysPopColCpu");
            var composeTitle = el.querySelector("[data-compose-title]");
            setTextIfChanged(composeTitle, wantDaemonCpu
                ? "Состав: qBittorrent + демон статистики"
                : "Состав: qBittorrent");
            if (wantDaemonCpu && !hasDaemonCpuUi) {
                var compact = el.querySelector(".fk-syspop-cores-compact");
                if (compact) {
                    compact.insertAdjacentHTML("beforeend",
                        "<div class=\"fk-syspop-core-row fk-syspop-daemon\">" +
                        "<b class=\"fk-syspop-core-val fk-syspop-c-daemon\" id=\"fkSysPopColCpu\">" + fmtCpu(last.colCpu) + "</b>" +
                        "<canvas class=\"fk-syspop-core-cv\" id=\"fkSysPopColCv\" width=\"200\" height=\"36\"></canvas>" +
                        "</div>");
                }
            }
            else if (!wantDaemonCpu && hasDaemonCpuUi) {
                var drow = el.querySelector(".fk-syspop-daemon");
                if (drow)
                    drow.parentNode.removeChild(drow);
            }
        }
        /* описание — фиксированный текст: писать только если изменилось */
        setTextIfChanged(el.querySelector("[data-hint]"), hintForKey(key));
        if (key === "sysCpu")
            refreshCoresBox(el, "fkSysPop");
        if (key === "shellCpu")
            refreshCoresBox(el, "fkQbitPop");
        updateXaxisLabels(el);
    }

    function applyCollector(data) {
        var needCpu = want.webCpu || graphWant.webCpu;
        var needRam = want.webRam || graphWant.webRam;
        if ((!needCpu && !needRam) || !data || typeof data !== "object")
            return false;
        var ok = false;
        if (needCpu) {
            var cpuOk = false;
            if (data.fk_panel_cpu != null && !isNaN(Number(data.fk_panel_cpu))) {
                last.panelCpu = ema("panelCpu", Number(data.fk_panel_cpu));
                push(hist.panelCpu, last.panelCpu);
                cpuOk = true;
            }
            if (data.fk_col_cpu != null && !isNaN(Number(data.fk_col_cpu))) {
                last.colCpu = ema("colCpu", Number(data.fk_col_cpu));
                push(hist.colCpu, last.colCpu);
                cpuOk = true;
            }
            if (cpuOk) {
                ok = true;
                if (want.webCpu)
                    syncWebCpuLabel(true);
            }
        }
        if (needRam) {
            var ramOk = false;
            if (data.fk_panel_rss_kb != null && !isNaN(Number(data.fk_panel_rss_kb))) {
                last.panelRam = ema("panelRam", Number(data.fk_panel_rss_kb) / 1024);
                ramOk = true;
            }
            if (data.fk_col_rss_kb != null && !isNaN(Number(data.fk_col_rss_kb))) {
                last.colRam = ema("colRam", Number(data.fk_col_rss_kb) / 1024);
                ramOk = true;
            }
            if (data.fk_panel_vms_kb != null && !isNaN(Number(data.fk_panel_vms_kb)))
                last.panelVmem = Number(data.fk_panel_vms_kb) / 1024;
            if (data.fk_col_vms_kb != null && !isNaN(Number(data.fk_col_vms_kb)))
                last.colVmem = Number(data.fk_col_vms_kb) / 1024;
            if (data.fk_mem_total_kb != null && !isNaN(Number(data.fk_mem_total_kb))) {
                var mt = Number(data.fk_mem_total_kb) / 1024;
                if (mt > 0)
                    last.sysRamTotal = mt;
            }
            if (ramOk) {
                ok = true;
                if (want.webRam)
                    syncWebRamLabel(true);
            }
        }
        return ok;
    }

    function notifyQbitGraph() {
        try {
            if (!(window.qBittorrent && window.qBittorrent.FkSpeedGraph
                && typeof window.qBittorrent.FkSpeedGraph.onQbitMetrics === "function"))
                return;
            var cpu = null;
            if (last.panelCpu != null || last.colCpu != null)
                cpu = combinedWebCpu();
            var ramMb = null;
            if (last.panelRam != null || last.colRam != null)
                ramMb = (last.panelRam || 0) + (last.colRam || 0);
            /* VMEM на графике торрента — тот же swap/zram, что в ОЗУ системы (не VmSize процесса) */
            var sysVmemOk = hasSysVmem();
            var vmemMb = sysVmemOk ? last.sysVmem : null;
            var vmemTot = sysVmemOk ? last.sysVmemTotal : null;
            var total = last.sysRamTotal;
            window.qBittorrent.FkSpeedGraph.onQbitMetrics({
                cpu: cpu,
                ramMb: ramMb,
                vmemMb: vmemMb,
                ramPct: (ramMb != null && total > 0) ? (100 * ramMb / total) : null,
                vmemPct: (vmemMb != null && vmemTot != null && vmemTot > 0)
                    ? (100 * vmemMb / vmemTot) : null,
                vmemLive: sysVmemOk
            });
        }
        catch (e) { /* ignore */ }
    }

    function parseSystem(data) {
        if (!data || typeof data !== "object")
            return null;
        // приоритет: /proc/stat от демона, иначе RCI
        var cpu = data.fk_sys_cpu;
        if (cpu == null)
            cpu = data.cpuload;
        if (cpu == null)
            cpu = data.cpu_load;
        var totalMb = null;
        var usedMb = null;
        // Keenetic: "занято/всего" в КиБ — как в веб-морде роутера
        if (typeof data.memory === "string" && data.memory.indexOf("/") >= 0) {
            var parts = data.memory.split("/");
            usedMb = Number(parts[0]) / 1024;
            totalMb = Number(parts[1]) / 1024;
        }
        else if (data.memtotal != null) {
            totalMb = Number(data.memtotal) / 1024;
            var avail = Number(data.memfree || 0) + Number(data.membuffers || 0) + Number(data.memcache || 0);
            usedMb = (Number(data.memtotal) - avail) / 1024;
        }
        return {
            cpu: cpu != null && !isNaN(Number(cpu)) ? Number(cpu) : null,
            ramUsed: usedMb != null && !isNaN(usedMb) ? usedMb : null,
            ramTotal: totalMb != null && !isNaN(totalMb) ? totalMb : null
        };
    }

    function applySystem(data) {
        var sys = parseSystem(data);
        if (!sys)
            return false;
        if (want.cpu && sys.cpu != null) {
            last.sysCpu = ema("sysCpu", sys.cpu);
            push(hist.sysCpu, last.sysCpu);
            setLabel("fkSysCpu", fmtCpu(last.sysCpu));
        }
        if ((want.cpu || want.webCpu || graphWant.cpu) && data && Array.isArray(data.fk_cores)) {
            var cores = [];
            var i;
            for (i = 0; i < data.fk_cores.length; i++) {
                var c = Number(data.fk_cores[i]);
                cores.push(isNaN(c) ? 0 : c);
            }
            pushCores(cores);
        }
        // total нужен и для % RAM/VMEM на графике торрента
        if (sys.ramTotal != null)
            last.sysRamTotal = sys.ramTotal;
        if (want.ram) {
            if (sys.ramUsed != null) {
                last.sysRam = ema("sysRam", sys.ramUsed);
                push(hist.sysRam, last.sysRam);
                noteRamPeak("sysRam", last.sysRam);
            }
            if (last.sysRamTotal != null)
                setLabel("fkSysRam", fmtRamBar());
            applySysVmem(data);
        }
        return (want.cpu && last.sysCpu != null) || (want.ram && last.sysRamTotal != null);
    }

    function applySysVmem(data) {
        if (!data || typeof data !== "object")
            return;
        var kind = data.fk_vmem_kind;
        var totKb = numOrNull(data.fk_vmem_total_kb);
        var usedKb = numOrNull(data.fk_vmem_used_kb);
        if (!kind || totKb == null || totKb <= 0) {
            last.sysVmem = null;
            last.sysVmemTotal = null;
            last.sysVmemKind = null;
            return;
        }
        last.sysVmemKind = kind === "zram" ? "zram" : "swap";
        last.sysVmemTotal = totKb / 1024;
        var usedMb = usedKb != null ? usedKb / 1024 : 0;
        if (usedMb < 0)
            usedMb = 0;
        last.sysVmem = ema("sysVmem", usedMb);
        push(hist.sysVmem, last.sysVmem);
    }

    function notifySpeedGraph(sys) {
        try {
            if (sys && window.qBittorrent && window.qBittorrent.FkSpeedGraph
                && typeof window.qBittorrent.FkSpeedGraph.onSysMetrics === "function") {
                window.qBittorrent.FkSpeedGraph.onSysMetrics(sys);
            }
        }
        catch (e) { /* ignore */ }
    }

    function sampleSysinfo() {
        var now = Date.now();
        if (sampleBusy)
            return;
        if (daemonOk) {
            if (!needsSysFetch())
                return;
        }
        else if (lastProbeAt > 0 && (now - lastProbeAt) < REPROBE_MS) {
            return;
        }
        sampleBusy = true;
        lastProbeAt = now;
        fetch(JSON_URL + "?t=" + Date.now(), { cache: "no-store", credentials: "same-origin" })
            .then(function (r) {
                if (!r.ok)
                    throw new Error("http " + r.status);
                return r.json();
            })
            .then(function (data) {
                failStreak = 0;
                setDaemonOk(true);
                applyCollector(data);
                var sys = parseSystem(data);
                /* всегда в график — чипы CPU/RAM не зависят от меню ⋮ статус-бара */
                notifySpeedGraph(sys);
                applySystem(data);
                notifyQbitGraph();
            })
            .catch(function () {
                failStreak += 1;
                // без демона — сразу скрыть; при сбое живого — после 3 ошибок подряд
                if (!daemonOk || failStreak >= 3)
                    setDaemonOk(false);
            })
            .then(function () {
                sampleBusy = false;
            });
    }

    function tick() {
        if (!ensureBar())
            return;
        if (typeof document !== "undefined" && document.hidden)
            return;
        if (daemonOk)
            pushWantToDaemon();
        sampleSysinfo();
        normalizeStatusBarSeparators();
        if (daemonOk)
            refreshPopover();
    }

    function start() {
        loadWant();
        loadPollMs();
        /* сбор кэша = сохранённый переключатель; без окна Statistics; при закрытой вкладке тик не идёт */
        cacheCollect = !!want.cache;
        var tries = 0;
        var boot = function () {
            if (!ensureBar() && tries < 60) {
                tries += 1;
                setTimeout(boot, 250);
                return;
            }
            syncMenuChecks();
            applyVisibility();
            syncCacheLabel();
            notifyDaemonState();
            tick();
            restartTickTimer();
        };
        boot();

        document.addEventListener("visibilitychange", function () {
            if (!document.hidden)
                tick();
        });

        document.addEventListener("pointerdown", function (e) {
            var t = e.target;
            if (menuEl && !menuEl.classList.contains("invisible")) {
                if (!(t.closest && (t.closest("#fkSysMenu") || t.closest("#fkSysMenuBtn"))))
                    hideMenu();
            }
            if (!anyPopoverOpen())
                return;
            if (t.closest && (t.closest(".fk-syspop") || t.closest(".fk-sysbar")))
                return;
            hideAllPopovers();
        }, true);

        document.addEventListener("keydown", function (e) {
            if (e.key === "Escape") {
                hideAllPopovers();
                hideMenu();
            }
        });

        window.addEventListener("resize", function () {
            if (anyPopoverOpen())
                placeAllPopovers();
            if (menuEl && !menuEl.classList.contains("invisible"))
                placeMenu();
        });
    }

    function onServerState(ss) {
        try {
            ensureBar();
            if (!want.cache) {
                if (cacheCollect) {
                    cacheCollect = false;
                    wipeCacheMemory();
                    syncCacheLabel();
                    syncCacheSwitchUi();
                }
                return;
            }
            if (!document.getElementById("fkCache"))
                return;
            /* сбор по want.cache (память меню); окно Statistics больше не сбрасывает переключатель */
            if (!cacheCollect)
                cacheCollect = true;
            if (!applyCacheStats(ss)) {
                syncCacheLabel();
                return;
            }
            if (popovers.cache) {
                refreshPopoverKey("cache");
                redrawPopoverCharts("cache");
            }
        }
        catch (e) { /* не ломать sync/maindata */ }
    }

    window.qBittorrent = window.qBittorrent || {};
    window.qBittorrent.FkSysBar = {
        normalizeSeparators: normalizeStatusBarSeparators,
        hasDaemon: function () { return daemonOk; },
        setGraphWant: setGraphWant,
        onServerState: onServerState,
        onStatisticsOpened: onStatisticsOpened,
        onStatisticsClosed: onStatisticsClosed,
        isCacheCollecting: function () { return cacheCollect; }
    };

    if (document.readyState === "loading")
        document.addEventListener("DOMContentLoaded", start);
    else
        start();
})();
