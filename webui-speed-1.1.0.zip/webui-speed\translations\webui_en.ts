<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">About</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Skip hash check</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Content layout:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Original</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create subfolder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Metadata received</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files checked</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop condition:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save at</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent information</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not available</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save files to location:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set as default category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter files...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Date:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Do not download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Comment:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tags:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Limit download rate</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>KiB/s</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Uncategorized</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit category...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop torrents</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>More information</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Information about certificates</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Logout</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Free space: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Saving Management</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open documentation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Failed to update name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Original author</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remember choice</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit web seed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to download file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add web seeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Error:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Options...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Status Bar</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Donate!</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Statistics</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Documentation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search Engine</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Transfers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Top of Queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download speed icon</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS Reader</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Execution Log</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Log</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter by:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save Path</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use regular expression</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloads</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>BitTorrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>IP Filtering</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>IP address:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Server domains:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>SMTP server:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Authentication</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Username:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Listening Port</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connections Limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Proxy Server</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>SOCKS4</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>SOCKS5</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>HTTP</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Host:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Port:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Every day</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Weekdays</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Weekends</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Privacy</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Require encryption</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disable encryption</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>then</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Certificate:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Key:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Domain name:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%L: Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%D: Save path</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>KiB/s</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Change current password</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>seconds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files location:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload rate based</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Anti-leech</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>File pool size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Any interface</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Fastest upload</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Allow encryption</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Fixed slots</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>min</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>KiB</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Round-robin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>MiB</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session timeout:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>ban for:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filters:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Network interface:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS Reader</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source> min</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create subfolder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Original</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Random</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>ms</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Excluded file names</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Run external program</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files checked</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Metadata received</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Fastresume files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>days</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Behavior</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>years</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>months</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>(None)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Mixed mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source> sec</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disk cache:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Write-through</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>WebUI</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Color scheme:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Dark</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Transfer list</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Light</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Send test email</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Action on double-click</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>User interface language:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>No action</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Interface</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Log Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>sec</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rotate API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Generate a key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%M: Comment</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Generate API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copied</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>API Key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Date format:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Browser default</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Localization</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Compact</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Display density:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Flags</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Country/Region</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add peers...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>IP/Address</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Mixed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Do not download</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Trackers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Content</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Transfer</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>ETA:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Uploaded:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeds:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download Speed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peers:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download Limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Wasted:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connections:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Comment:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total Size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Pieces:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Created By:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Added On:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed On:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Created On:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save Path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter files...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filename</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Replacement Input</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Extension</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Replace All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Include files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Include folders</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Case sensitive</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Replace option</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Popularity:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove web seed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Web seed editing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Private:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Availability:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Override Save Location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Monitored folder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default save location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Other...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Type folder here</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>User statistics</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Cache statistics</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Connected peers:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time download:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session waste:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All-time upload:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Performance statistics</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total queued size:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Active (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Errored (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Active (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Moving (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Running (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Running (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop torrents</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tags</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Availability</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reannounce In</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Private</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Popularity</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Status Icon</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Created On</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Updating...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Working</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not working</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker editing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Leeches</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remaining</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Availability</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tier</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download Priority</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Total Size</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add trackers...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Renamed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Original</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>BT Protocol</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Next Announce</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tier:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker error</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unreachable</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Min Announce</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add trackers</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Moving</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Errored</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Missing Files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued for checking</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Downloading</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Checking resume data</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stalled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stopped</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Categories</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tags</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Trackers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set location...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force recheck</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set location</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force reannounce</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tags</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Magnet link</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info hash v1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info hash v2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent ID</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Export .torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename Files...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Renaming</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Force Start</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Location:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New name:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add tags</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Content Path</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use global share limit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set no share limit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Set share limit to</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>ratio</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>total minutes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>inactive minutes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1y %2d</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Plugin path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL or local directory</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Install plugin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All plugins</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search plugins...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All categories</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search in:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent names only</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Only enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>out of</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Everywhere</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Results</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>showing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Select category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Min size prefix</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start a search above.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Max size prefix</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Select plugins</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Install new plugin</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search plugins</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Leechers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeders</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Published On</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Engine URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Engine</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Url</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add tag...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tag:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove tag</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop torrents</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Untagged</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Forum:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>E-mail:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Current maintainer</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Home Page:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Greece</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Special Thanks</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>License</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Translators</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Nationality:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Software Used</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Authors</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>France</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Description page URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open description page</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download link</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search has finished</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Close tab</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Searching...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Search aborted</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Close all tabs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Refresh tab</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use as search text</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New name:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New feed name:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Update all</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Mark items read</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Update all feeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open news URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Feed URL:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New folder...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New subscription</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Folder name:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New subscription...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open link</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Author: </source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source> will match all articles.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rule Definition</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save to:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New rule name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>? to match any single character</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Assign Category:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Example: </source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add new rule...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Must Contain:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use global settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rule renaming</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Always</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source> days</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete rule</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rename rule...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create subfolder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Original</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Tags:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove rule</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add rule</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Trackerless</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove tracker</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker error</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Other error</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unread</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Blocked</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>showing</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Log Type</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Information Messages</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Warning Messages</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Filter logs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>out of</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Timestamp</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Clear All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Log Levels:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reason</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>item</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>IP</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Banned</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Normal Messages</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Critical</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Critical Messages</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>items</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Results</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to create category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to set category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>New Category</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Save path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Category:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Category does not exist</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Cookie</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Expiration Date</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Server response:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Queued</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Comments:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download Torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Status Icon</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Failed</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Finished</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Error Message</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Piece Size</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Completed On</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Hybrid</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Path:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Create Torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Started On</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Web Seeds</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent format:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Source Path</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Added On</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Running</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Source:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Trackers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Piece size:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Fields</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Remove Task</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Export Torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Magnet link</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add torrent links</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>URLs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Speed limit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Download limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>KiB/s</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resize</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>