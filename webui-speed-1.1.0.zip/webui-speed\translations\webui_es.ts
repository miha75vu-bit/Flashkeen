<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">Acerca de</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Categoría:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>No comprobar hash</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Modo de administración del torrent:</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>Diseño de contenido:</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Crear subcarpeta</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>No crear subcarpeta</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metadatos recibidos</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Archivos verificados</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>Condición de parada:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Añadir al principio de la cola</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Descargar en orden secuencial</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Tamaño:</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>Guardar en</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Información del torrent</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>Info hash v1:</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Renombrar torrent</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation>Añadir torrent</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Propiedades del torrent</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Guardar los archivos en:</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>Establecer como categoría predeterminada</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Tasa límite de subida</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrar archivos...</translation>
    </message>
    <message>
        <source>Add Torrent</source>
        <translation type="vanished">Añadir Torrent</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>Usa otra ruta para torrent incompleto</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation>Guardar como archivo .torrent</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Comenzar por las primeras y últimas partes</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation>No se puede descargar el archivo torrent</translation>
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>Info hash v2:</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>Etiquetas:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Archivos</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Tasa límite de bajada...</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Sin categorizar</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Agregar categoría...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Eliminar categoría</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Eliminar categorías sin utilizar</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Nueva categoría</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Editar categoría...</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>Agregar subcategoría...</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Salir de qBittorrent</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite alternativo de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite alternativo de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>El número máximo de descargas activas debe ser mayor que -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>El número máximo de subidas activas debe ser mayor que -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>El número máximo de torrents activos debe ser mayor que -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo de puestos de subida por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Más Información</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Información sobre certificados</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Establecer destino</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lunes</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Martes</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Miércoles</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Jueves</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Viernes</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sábado</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Domingo</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>Imposible conectar a qBittorrent</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>El máximo número de puestos de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>Nombre de categoría invalido:\nPor favor no use caracteres especiales para el nombre de la categoría.</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>El límite de la tasa de subida debe ser mayor que 0.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Espacio libre: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>El tiempo de inactividad del torrent debe ser mayor que 0.</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>Administración de guardado</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>El límite de la tasa de descarga debe ser mayor que 0.</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>Abrir documentación</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>Registrese para manejar vínculos magnéticos...</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>No es posible agregar pares. Por favor asegúrese de respetar el formato IP:puerto.</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>El nombre no puede estar vacío</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>No se ha cambiado el nombre</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>Falló la actualización del nombre</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>El puerto para conexiones entrantes debe estar comprendido entre 0 y 65535.</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>El puerto usado para la interfaz Web debe estar comprendido entre 1 y 65535.</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 ha sido cerrado</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>¡Se requiere JavaScript! Debe habilitar JavaScript para que la Interfaz de Usuario de la Web  funcione correctamente</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>IP externa: N/A</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>Ejemplos de configuración de proxy inverso</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>No se pudo contactar con qBittorrent</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Recordar esta elección</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>¿Seguro que desea eliminar estos %1 torrents de la lista de transferencias?</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>No se pudo eliminar torrents.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>IP externa: %1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>Editar semilla web</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>¿Seguro que desea eliminar '%1' de la lista de transferencias?</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>No se puede configurar la gestión automática de torrents para los torrents seleccionados.</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>No se pueden detener los torrents.</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>No se puede descargar el archivo</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>IP externas: %1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>No se pueden volver a verificar los torrents.</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>Lista de semillas web para añadir (una por línea):</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>No se pueden iniciar los torrents.</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>Añadir semillas web</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation>No se pudo eliminar la clave API.</translation>
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>El límite de tiempo de siembra no debe tener un valor negativo.</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>El límite de ratio de acciones no debe tener un valor negativo.</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation>El intervalo de rotación de pares debe ser mayor o igual a 0.</translation>
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation>No se pudo analizar la respuesta.</translation>
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation>No se pudo rotar la clave API.</translation>
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation>La rotación de pares debe estar entre 0 y 100.</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation>La memoria disponible al comprobar los torrents debe ser mayor que 0 y menor que 1024.</translation>
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation>No se pueden cargar las preferencias del programa; es probable que qBittorrent sea inaccesible.</translation>
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation>El límite de rotación de pares debe estar entre 0 y 100.</translation>
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation>El DSCP de par debe estar entre 0 y 255.</translation>
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation>No se pudieron guardar las preferencias, es posible que qBittorrent no esté disponible.</translation>
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation>No se pueden añadir torrents.</translation>
    </message>
    <message>
        <source>Error:</source>
        <translation>Error:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Opciones...</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Barra de herramientas</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Barra de estado</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Velocidad en la barra de título</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Donar!</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Agregar archivo torrent...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Documentación</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Agregar enlace torrent...</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Límite de velocidad de subida global</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Límite de velocidad de descarga global</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>¿Está seguro de que quiere cerrar qBittorrent?</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>Filtrar lista de torrents...</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Transferencias</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>Mover arriba en la cola</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>Mover Arriba Cola</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>Final de la Cola</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>Mover al final de la cola</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>Principio de la Cola</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>Mover Abajo Cola</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>Mover abajo en la cola</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>Mover al principio de la cola</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>Su navegador no soporta esta funcionalidad</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>Para usar esta funcionalidad, se debe acceder a la interfaz Web a través de HTTPS</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>Estado de la conexión: Bajo Cortafuegos</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>Estado de la conexión: Conectado</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>Límites de velocidad alternativos: Desactivados</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>Icono de velocidad de descarga</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>Límites de velocidad alternativos: Activados</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>Icono de velocidad de subida</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>Estado de la conexión: Desconectado</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>Lector de RSS</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>Barra lateral de filtros</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Registro de ejecución</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Registro</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[D: %1, U: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>Filtrar por:</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>Ruta de Destino</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>Usar expresion regular</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>¿Quieres iniciar todos los torrents?</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Empezar</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>Administrar Cookies...</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>No se puede exportar el archivo torrent.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>¿Quieres detener todos los torrents?</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>Empezar todo</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>Detener todo</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Crear torrent</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation>Filtrar elementos de semillas...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Notificarme por correo electrónico de la finalización de las descargas</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>Filtrado IP</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar el uso de límites alternativos</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrents en cola</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>interfaz Web (Control remoto)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>Direcciones IP:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Dominios de servidor:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Usar HTTPS en lugar de HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Eludir la autenticación para clientes en localhost</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Eludir la autenticación para clientes en la lista blanca de subredes IP</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Actualizar mi nombre de dominio dinámico</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantener torrents incompletos en:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Copiar archivos .torrent en:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar archivos .torrent de descargas finalizadas a:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Reservar el espacio en el disco para todos los archivos</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Agregar la extensión .!qB a los archivos incompletos</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Agregar automáticamente los torrents de:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requiere una conexión segura (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP y μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Puerto de escucha</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Puerto utilizado para conexiones entrantes:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar reenvío de puertos UPnP / NAT-PMP de mi router</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Límites de conexión</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Máximo de conexiones por torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Máximo de conexiones totales:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Máximo de puestos de subida por torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Máximo total de puestos de subida:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy para las conexiones a los pares</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta del filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Direcciones IP prohibidas manualmente...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Aplicar a los trackers</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Limites globales de velocidad</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Subida:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Bajada:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Desde las:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Hasta:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Cuándo:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Todos los días</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Días laborales</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Fines de semana</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Configuración de los limites</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límite para el exceso de transporte (Overhead)</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar límite para conexiones µTP</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (red descentralizada) para encontrar más pares</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercambio de pares (PeX) para encontrar más pares</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar busqueda local de pares para encontrar más pares</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Modo de cifrado:</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Exigir cifrado</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Deshabilitar cifrado</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Activar modo anónimo</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Máximo de descargas activas:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Máximo de subidas activas:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Máximo de torrents activos:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>No contar torrents lentos en estos límites</translation>
    </message>
    <message>
        <source>then</source>
        <translation>luego</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar UPnP / NAT-PMP para redirigir el puerto de mi router</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Clave:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registro</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Nombre de dominio:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parámetros soportados (sensible a mayúsculas):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Nombre del torrent</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Categoría</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Ruta del contenido (misma ruta que la raíz para torrents muilti-archivo)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Ruta Raíz (primer subdirectorio del torrent)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Ruta de destino</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Cantidad de archivos</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamaño del torrent (bytes)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker actual</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Consejo: Encapsula el parámetro con comillas para evitar que el texto sea cortado en un espacio (ej: "%N")</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>Activar protección de clickjacking</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Activar protección CSRF (Cross-site Request Forgery)</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>Después eliminar el archivo .torrent</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>Umbral de vel. de descarga:</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>Umbral de vel. de subida:</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>Cambiar contraseña actual</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>Ubicación de guardado predeterminada:</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>No iniciar las descargas de forma automática</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>Cambiar torrent a modo manual</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>Cuando cambia la categoría del torrent:</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>Reubicar los torrents afectados</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar límite a los pares en LAN</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 significa ilimitado</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>Reubicar torrent</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>Cuando la ubicación de guardado predeterminada cambia:</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>Habilitar la validación del encabezado del Host</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Seguridad</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>Cuando cambia la ruta de destino de la categoría:</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Cambiar los torrents afectados a modo manual</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>Ubicación de archivos:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Temporizador de inactividad de Torrent:</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>Administración de Torrents predeterminada:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Al agregar un torrent</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>Algoritmo modo mixto μTP-TCP:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>Según tasa de subida</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Etiquetas (separadas por comas)</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Tamaño backlog de Socket:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Habilitar super semilla para torrent</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>Preferir TCP</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>Memoria pendiente al revisar torrents:</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>Anti-leech</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>Cuando la tasa alcance</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>Permitir múltiples conexiones desde la misma dirección IP:</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>Tamaño de la reserva de archivos:</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>Cualquier interfaz</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>Siempre anunciar a todos los niveles:</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>Puerto rastreador incrustado:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>Subida más rápida</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>Eliminar el torrent y sus archivos</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>Sección qBittorrent</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>Enviar factor de marca de agua del buffer:</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>Sección libtorrent</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>Volver a revisar torrents al completar:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>Permitir el cifrado</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>Enviar sugerencias de piezas de subida:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>Habilitar rastreador incrustado:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Eliminar torrent</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>Subprocesos asíncronos de E/S:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>Enviar marca de agua de búfer:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Proporcional a los pares (ahoga el TCP)</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>Slots fijos</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <source>min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>Subir algoritmo atascado:</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>Límite de siembra</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>Round-robin</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>Comportamiento de carga de slots:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>Enviar marca de agua bufer bajo:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>Guardar intervalo de datos resumidos:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>Siempre anunciar a todos los rastreadores en un nivel:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>Hora de término de la sesión:</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>Resolver pares de paises:</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>vetar por:</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>Vetar el cliente después de fracasos consecutivos:</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Encabezado: valores de pares, uno por línea</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>Añadir encabezados HTTP personalizados</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>Filtros:</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>Habilitar la obtención de feeds RSS</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>Porcentaje del limite de rotación de pares:</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Descargador automático de torrent RSS</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>Interfaz de red</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>Lector de RSS</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>Editar reglas de descarga automática...</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Descargar episodios REPACK/PROPER</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>Intervalo de actualización de feeds:</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>Porcentaje de desconexión de la rotación de pares</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artículos por feed:</translation>
    </message>
    <message>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>Intervalo de desconexión de rotación de pares:</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>Dirección IP opcional para enlazar:</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>No permitir la conexión a pares en puertos privilegiados:</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Habilitar auto descarga de torrents RSS</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>Filtro Inteligente de Episodios por RSS</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>Validar el certificado de seguimiento HTTPS:</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>Protocolo de conexión entre pares:</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Diseño de contenido de torrent:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Crear subcarpeta</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>No crear subcarpetas</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>Conexiones salientes por segundo:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: ID de torrent</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>Reanunciar a todos los rastreadores cuando la IP o el puerto cambia:</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>Lista de proxies de confianza:</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>Habilitar el soporte de proxy inverso</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J: Informacion hash v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: Informacion hash v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>Dirección IP informada a los rastreadores (requiere reiniciar):</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Establecer en 0 para permitir que su sistema elija un puerto no usado</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>Mitigación de falsificación de solicitudes del lado del servidor (SSRF)</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>Tamaño de la cola de disco:</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>Registrar advertencias de rendimiento</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>Máximo de solicitudes pendientes a un único par:</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>Máximo de torrents de comprobación activos:</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>Archivos mapeados en memoria</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>compatible con POSIX</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>Controla el intervalo de actualización del estado interno que, a su vez, afectará las actualizaciones de la interfaz de usuario</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>Modo de lectura de E/S de disco:</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>Deshabilitar caché del sistema operativo</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>Modo de escritura de E/S de disco:</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>Usar afinidad de extensión de pieza:</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>Aviso de HTTP simultáneo máximo</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>Activar caché del S.O.</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>Intervalo de actualización:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>Nombres de archivos excluidos</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>Admite nombre de dominio internacionalizado (IDN):</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>Lista blanca para filtrar valores de cabeceras de hosts HTTP.
Para defenderse de ataques DNS rebinding,
no debería utilizar nombres de dominio utilizados por el servidor de la interfaz Web.

Use ';' para dividir múltiples entradas. Puede usar el comodin '*'.</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>El certificado HTTPS no debe estar vacío</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>Especifique IP de proxy inverso (o subredes, por ejemplo, 0.0.0.0/24) para usar la dirección de cliente reenviada (encabezado X-Reenviado-para encabezado). Usar ';' para dividir varias entradas.</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>La clave HTTPS no debe estar vacía</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>Ejecutar programa externo</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Archivos verificados</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>Activar el reenvío de puertos para el rastreador integrado:</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>Si se verifica, las búsquedas del nombre de host se realizan a través del proxy.</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metadatos recibidos</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Condición de parada del Torrent:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Ejemplo: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>Base de datos SQLite (experimental)</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>Reanudar el tipo de almacenamiento de datos (requiere reiniciar):</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>Archivos de reanudación rápida</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>Respaldar el archivo de registros después de:</translation>
    </message>
    <message>
        <source>days</source>
        <translation>días</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>Eliminar los registros anteriores a:</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>Usar proxy para propósitos de BitTorrent</translation>
    </message>
    <message>
        <source>years</source>
        <translation>años</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <source>months</source>
        <translation>meses</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>Recordar la configuración de cambio de nombre múltiple</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>Usar proxy para propósitos generales</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>Usar proxy para propósitos de RSS</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>Tamaño de buffer de socket cliente [0: por defecto de sistema]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>Puertos de salida (Max) [0: desactivado]:</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>Tamaño de buffer de socket de recepción [0: por defecto de sistema]:</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Añadir al principio de la cola</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>Parar la cuenta atrás de tracker [0: desactivado]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>Puertos de salida (Min) [0: desactivado]</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>Duración de la cesión UPnP [0: cesión permanente]:</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Límite de profundidad de Bdecode:</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Límite de token de Bdecode:</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>Cuando el tiempo total de siembra alcance</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Ninguno)</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Ruta del ejecutable de Python (puede requerir reinicio)</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>Restablece a predeterminados si está vacío</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>Realizar búsqueda de hots via proxy</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>Si el &amp;quot;modo mixto&amp;quot; está habilitado, los torrents I2P también pueden obtener pares de otras fuentes además del rastreador y conectarse a direcciones IP normales, sin proporcionar ninguna anonimización. Esto puede ser útil si el usuario no está interesado en la anonimización de I2P, pero aún desea poder conectarse con pares I2P.</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>Nodos de arranque DHT:</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>Cuando el tiempo de siembra inactiva alcanza</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>Modo mixto</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>Límite de tamaño de archivo .torrent</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>(Auto detectar si está vacío)</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>Mantén los archivos no seleccionados en la carpeta ".unwanted"</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>Habilite la Marca de la Web (MOTW) para archivos descargados (requiere MacOS o Windows):</translation>
    </message>
    <message>
        <source> sec</source>
        <translation>seg</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>Cantidad saliente de I2P:</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>Cantidad entrante de I2P:</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>Hilos de hashing:</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>Límite de uso de la memoria física (RAM)</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>Usar la interfaz Web alternativa</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>Intervalo de caducidad de caché de disco:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>Longitud de salida I2P:</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P (Experimental)</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>Tipo de E/S de disco (requiere reiniciar):</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>La ubicación alternativa de los archivos WebUI no puede estar en blanco.</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>Caché de disco</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>Escritura por medio de</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>Interfaz de usuario de la Web</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>La contraseña de WebUI debe tener al menos 6 caracteres.</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>Fusionar lecturas y ; escrituras:</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>Longitud de entrada I2P:</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>El nombre de usuario de WebUI debe tener al menos 3 caracteres.</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>Retraso en la solicitud del mismo host:</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>Personalizar el nombre de la instancia de la aplicación:</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>Esquema de colores:</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>Mostrar IP externa en la barra de estado</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>Rastreadores obtenidos</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar al eliminar torrents</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>Ignorar errores SSL:</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Oscuro</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>Eliminar archivos permanentemente</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>Alternar colores en la lista de transferencias</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>Mostrar la URL completa del anuncio en la columna Rastreador</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>Lista de transferencias</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>El puerto de anuncio debe estar entre 0 y 65535.</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Claro</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>Agregar automáticamente estos trackers a las descargas:</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Torrents descargando:</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>Iniciar / Parar torrent</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>Enviar correo electrónico de prueba</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>Habilitar la bandera segura de cookies (requiere conexión HTTPS o localhost)</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Acción a realizar con un doble-click</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>Intervalo de guardado de estadísticas:</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Muestra una ventana de confirmación al borrar torrents</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>Finalizada ejecución en torrent:</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>Se intentó enviar un correo electrónico. Revisa tu bandeja de entrada para confirmar el éxito</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>Añadir automáticamente rastreadores desde la URL a las nuevas descargas:</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Modo de eliminación de contenido de torrent:</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>Mover los archivos a la papelera (si es posible)</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Parar torrents</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>Usar directorios de Categoría en Modo Manual</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>Lista de interfaz Web alternativa</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>Añadida ejecución en torrent:</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>Puerto informado a los rastreadores (requiere reinicio) [0: puerto de escucha]:</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>Idioma de la interfaz de usuario:</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>Fusionar rastreadores a un torrent existente</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation>Confirmar la nueva comprobación del torrent:</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>Configuración de interfaz web personalizada</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>Las siguientes configuraciones son solo para la interfaz web</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>Prelectura/prescritura simple</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Resolver la ruta de ubicación relativa contra la ruta de categoría apropiada en lugar de la predeterminada.</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Sin acción</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>Auto ocultar filtros de estado cero</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>Archivos de Registro</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>Habilitar la representación optimizada de tablas (experimental)</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>Nota: La contraseña se guardo sin cifrar</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>Intervalo de expiración de la caché de resolución de nombre de host interno</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>seg</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation>Rotar la clave API</translation>
    </message>
    <message>
        <source>Generate a key</source>
        <translation>Generar una clave</translation>
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation>Al añadir un torrent duplicado</translation>
    </message>
    <message>
        <source>Delete API key</source>
        <translation>Eliminar la clave API</translation>
    </message>
    <message>
        <source>%M: Comment</source>
        <translation>%M: Comentario</translation>
    </message>
    <message>
        <source>Generate API key</source>
        <translation>Generar clave API</translation>
    </message>
    <message>
        <source>Copied</source>
        <translation>Copiado</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation>Restablecer selección de filtro</translation>
    </message>
    <message>
        <source>API Key</source>
        <translation>Clave API</translation>
    </message>
    <message>
        <source>Copy API key</source>
        <translation>Copiar clave API</translation>
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation>Punto de código de servicios diferenciados (DSCP) para conexiones con pares</translation>
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation>El nombre de usuario de WebUI no debe contener dos puntos.</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>Formato de fecha:</translation>
    </message>
    <message>
        <source>Browser default</source>
        <translation>Navegador por defecto</translation>
    </message>
    <message>
        <source>Localization</source>
        <translation>Localización</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>Compacto</translation>
    </message>
    <message>
        <source>Display density:</source>
        <translation>Densidad de visualización:</translation>
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation>Añada el texto al título de la ventana para ayudar a distinguir las instancias de qBittorrent.</translation>
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation>Resolver nombres de host de los pares:</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Banderas</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Descarga</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Importancia</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Archivos</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Vetar al par de forma permanente</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>¿Seguro que quieres prohibir permanentemente a los pares seleccionados?</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>Copiar IP: puerto</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>País/Región</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>Añadir pares</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>Cliente de identificación de pares</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>IP/Dirección</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Mezclado</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>Fuentes HTTP</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Descargado:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tiempo activo:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Tiempo restante:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Subido:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Semillas:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Velocidad de descarga:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Velocidad de subida:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Pares:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Límite de descarga:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Desperdiciado:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Conexiones:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Ratio de compartición:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Anunciar en:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Ultima vez visto completo:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Tamaño total:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Piezas:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Creado por:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Agregado el:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Completado el:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Creado el:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (tienes %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 en esta sesión)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 máx)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 prom.)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrar archivos...</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (sembrado para %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>Informacion Hash v2:</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>Informacion Hash v1:</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Usar expresiones regulares</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nombre de archivo</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>Nombre de archivo + Extensión</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>Enumerar archivos</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>Renombrado fallido: el archivo o carpeta ya existe</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>Alternar Selección</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>Entrada de reemplazo</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Reemplazar</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>Extension</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>Reemplazar Todo</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>Incluir archivos</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>Incluir carpetas</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>Buscar archivos</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Distingue Mayúsculas y Minúsculas</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>Coincidir con todas las ocurrencias</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>Copiar URL de la semilla Web</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>Opción de reemplazo</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>Editar URL de la semilla Web</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>URL de la semilla Web:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>Ratio/Tiempo Activo (en meses), indica qué tan popular es el torrent</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>Popularidad:</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>¿A qué parte del nombre de archivo se aplica?</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>Eliminar semilla Web</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>Editando semilla Web</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>Añadir semillas web...</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>Privado:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Disponibilidad:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Carpeta Monitoreada</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Cambiar ubicación de guardado</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Carpeta Monitoreada</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Ubicación de guardado predeterminada</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>Otros...</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Escriba carpeta aquí</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Estadísticas del usuario</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Estadísticas de la caché</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Uso de la caché de lectura:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Tiempo promedio en cola:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>Pares conectados:</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>Ratio de comparticíon:</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>Total bajado:</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>Desperdicio de sesión:</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>Total subido:</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>Tamaño total del buffer:</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Estadísticas de rendimiento</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Trabajos de I/O en cola:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Sobrecarga de la caché de escritura:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Sobrecarga de la caché de lectura:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Tamaño total de cola:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Descargando (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Sembrando (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Completados (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Activos (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Inactivos (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Con errores (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Descargando (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Sembrando (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Completados (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Activos (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Inactivos (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Con errores (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>Subida estancada (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>Descarga estancada (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>Descarga estancada (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>Detenido (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>Subida estancada (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>Detenido (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>Comprobando (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>Comprobando (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>Moviendo (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>Moviendo (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>En ejecución (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>Detenido (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>Detenido (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>En ejecución (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. descarga</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tiempo Restante</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Agregado</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límite descarga</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límite Subida</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tiempo Activo</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Ruta Destino</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límite de ratio</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Visto Completo</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última Actividad</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamaño Total</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Disponibilidad</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>Reanunciar en</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privado</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>Informacion Hash v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>Informacion Hash v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>Ruta de destino incompleta</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>Popularidad</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Icono de estado</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation>Sesión cargada</translation>
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation>Sesión descargada</translation>
    </message>
    <message>
        <source>Created On</source>
        <translation>Creado el</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>URL del tracker:</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Todavía no contactado</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>Semillas</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>No funciona</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>Copiar URL del tracker</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>Editar URL del tracker:</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>Editando tracker</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>Pares</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Eliminar tracker</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Restante</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Disponibilidad</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>Nivel</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Prioridad de descarga</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>Tamaño total</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>Veces Descargado</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>Añadir trackers...</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>Renombrado</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/Punto final de anuncio</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>Protocolo BT</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>Siguiente anuncio</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation>Nivel:</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Error del rastreador</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>Inalcanzable</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation>Forzar recomunicación al tracker(s) seleccionado</translation>
    </message>
    <message>
        <source>Min Announce</source>
        <translation>Anuncio mínimo</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>Forzar recomunicación con todos los trackers</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de trackers a agregar (uno por línea):</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>Añadir trackers</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>hace %1</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>Moviendo</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[F] Sembrando</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>Sembrando</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>En cola</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>Con errores</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[F] Descargando</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>Descargando metadatos</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>Verificando</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>Faltan archivos</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>En cola para su verificación</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>Verificando datos de continuación</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>Detenido</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (sembrado para %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[F] Descargando metadatos</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Detenido</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Rastreadores</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>Colapsar/expandir</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>Contraer/expandir categoría</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límite de velocidad de descarga del torrent</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límite de velocidad de subida del torrent</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Límitar ratio de compartición...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de subida...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Tasa límite de descarga...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover al principio</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover al final</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Establecer destino...</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Descargar antes primeras y últimas partes</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Administración automática de torrents</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nueva...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Descategorizar</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Forzar verificación de archivo</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Modo supersiembra</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Descargar en orden secuencial</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Nueva categoría</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Establecer destino</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Forzar recomunicación</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>Editar categoría</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>Etiquetas separadas por comas:</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Enlace magnético</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>Eliminar todo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Cola</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Agregar...</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>Informacion hash v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>Informacion hash v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>ID de Torrent</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>Exportar .torrent</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>Renombrar archivos...</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>Renombrando</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>Forzar inicio</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El modo automático significa que varias propiedades del torrent (por ejemplo, guardar ruta) serán decididas por la categoría asociada</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Empezar</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>Añadir etiquetas</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation>Ruta de contenido</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límites de ratio de subida/descarga</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Usar límite de ratio global</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Sin límites de ratio</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Establecer límite de ratio en</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>ratio</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>minutos totales</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>minutos inactivos</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Eliminar torrent</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>Eliminar el torrent y su contenido</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Parar torrents</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Habilitar la super-siembra para el torrent</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation>Acción a seguir cuando se alcance el límite</translation>
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>Eliminar torrent(s)</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>Elimina también los archivos de contenido.</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Eliminar tracker</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Descargar de URLs</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1y %2d</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>Ruta de destino vacía</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>Ruta del plugin:</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>URL o directorio local</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>Instalar plugin</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>Semillas:</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>Todos los plugins</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>Plugins de búsqueda...</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>Todas</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>Buscar en:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>Solo nombres de Torrent</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>Solo habilitados</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>de</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>En todas partes</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>Aumente el ancho de la ventana para mostrar filtros adicionales</translation>
    </message>
    <message>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>mostrando</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>Haga clic en el botón "Buscar complementos..." en la parte inferior derecha de la ventana para instalar algunos.</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>No hay complementos de búsqueda instalados.</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>Seleccionar categoría</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>Prefijo de tamaño mínimo</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>Inicie una búsqueda arriba.</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>Prefijo de tamaño máximo</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>Seleccionar plugins</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>Instalar nuevo plugin</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>Puedes obtener nuevos plugins de motores de busqueda aquí:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>Plugins de búsqueda instalados:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Advertencia: Asegúrese de cumplir con las leyes de copyright de su país cuando descarga torrents de estos motores de búsqueda.</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>Plugins de búsqueda</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>Semillas</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>Publicado el</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>URL del motor</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>Motor</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>Añadir pares</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>Lista de pares a agregar (una IP por línea):</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formato: IPv4:puerto / [IPv6]:puerto</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>Nueva etiqueta</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>Agregar etiqueta...</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>Eliminar etiquetas sin usar</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>Nombre de etiqueta no válido</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>Eliminar etiqueta</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>Sin etiquetar</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Localizador de rastreadores:</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Foro:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>Encargado actual</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Página web:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>Agradecimientos especiales</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un cliente BitTorrent avanzado programado en C++, basado en el toolkit Qt y en libtorrent-rasterbar.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>Acerca de qBittorrent</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>Traductores</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent fue compilado con las siguientes librerías:</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>Nacionalidad:</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>Software utilizado</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>La base de datos gratuita IP to Country Lite de DB-IP se usa para resolver los pares de países. La base de datos está licenciada bajo Creative Commons Attribution 4.0 International License</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Autores</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>Mascota de qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>Icono de qBittorrent</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>Todas las direcciones</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>Todas las direcciones IPv6</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>Todas las direcciones IPv4</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descarga</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>URL de la página de descripción</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>Abrir la página de descripción</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>Enlace de descarga</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>La búsqueda ha finalizado</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>Ha ocurrido un error durante la búsqueda...</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>Cerrar pestaña</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Buscando...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Búsqueda abortada</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>Cerrar todas las pestañas</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation>Pestaña de actualización</translation>
    </message>
    <message>
        <source>Open download window</source>
        <translation>Abrir ventana de descarga</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation>Usar como texto de búsqueda</translation>
    </message>
    <message>
        <source>Stop search</source>
        <translation>Detener la búsqueda</translation>
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>Renombrando</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Elija un nuevo nombre para este canal RSS</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Elija un nombre de carpeta</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nuevo nombre de feed:</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Actualizar todo</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>Descargador RSS...</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Marcar elementos como leídos</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Actualizar todos los feeds</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Copiar URL del feed</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (doble clic para descargar)</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Abrir URL de noticias</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>URL Feed:</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Nueva carpeta...</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nueva Subscripcion</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Nombre de la carpeta:</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>Escriba una URL de fuente RSS</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>¡La obtención de feeds RSS está deshabilitada ahora! Puede habilitarlo en la configuración de la aplicación.</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>Confirmación de eliminación</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>¿Está seguro de que desea eliminar las fuentes RSS seleccionadas?</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nueva suscripción...</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Descargar torrent</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>Guardar URL de feed...</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>No se puede actualizar la URL</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>La URL no ha cambiado</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>La URL no puede estar vacía</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>Abrir enlace</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>Reglas de descarga</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>Artículos RSS coincidentes</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* para coincidir con cero o más caracteres</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation> coincidirá con todos los artículos.</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>Reglas de filtro de episodios:</translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>¡La descarga automática de torrents RSS está deshabilitada ahora! Puede habilitarlo en la configuración de la aplicación.</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>Definición de regla</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Guardar en:</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>Usar expresiones regulares</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Nombre de regla nueva</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>El filtro debe terminar con punto y coma</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? para que coincida con cualquier carácter</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>Coincide con los artículos según el filtro de episodios.</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>Asignar categoría:</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Modo Regex: use expresiones regulares compatibles con Perl</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>| se utiliza como operador OR</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>Borrar episodios descargados</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Los espacios en blanco cuentan como operadores Y (todas las palabras, en cualquier orden)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>Una expresión con una cláusula %1 vacía (p. Ej. %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>Ejemplo:</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Añadir nueva regla...</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>¿Está seguro de que desea borrar la lista de episodios descargados para la regla seleccionada?</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>Debe contener:</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Rango infinito: &lt;b&gt;1x25-;&lt;/b&gt; coincide con los 25 episodios y posteriores de la temporada uno, y todos los episodios de temporadas posteriores</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>Guardar en un directorio diferente</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>No debe contener:</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Número único: &lt;b&gt;1x25;&lt;/b&gt; coincide con el episodio 25 de la primera temporada</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>Se admiten tres tipos de rango para episodios:</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>¿Está seguro de que desea eliminar las reglas de descarga seleccionadas?</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>Usar configuración global</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Rango normal: &lt;b&gt;1x25-40;&lt;/b&gt; coincide con los episodios 25 a 40 de la primera temporada</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Escriba el nombre de la nueva regla</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Renombrar regla</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>El número de episodio es un valor positivo obligatorio</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation> coincidirá con 2, 5, 8 a 15, 30 y episodios posteriores de la primera temporada</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar la eliminación de la regla</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>Ultima coincidencia: hace %1 días</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>Filtro de episodio:</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>Descargador de Rss</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>El número de temporada debe ser distinto de cero</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar regla a los canales:</translation>
    </message>
    <message>
        <source> days</source>
        <translation>días</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>Usar Filtro Inteligente de Episodios</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Si el orden de las palabras es importante use * en vez de espacios.</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor, escriba el nombre de la nueva regla de descarga.</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>Modo comodín: puedes usar</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation>excluirá todos los artículos.</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>Ignorar las siguientes coincidencias para (0 para desactivar)</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Renombrar regla...</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>Ultima coincidencia: Desconocida</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>Borrar episodios descargados</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>Filtro de episodio inteligente comprobará el número de episodio para evitar la descarga de duplicados.
Admite los formatos: S01E01, 1x1, 2017.12.31 y 31.12.2017 (los formatos de fecha también son compatibles, como separador)</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Diseño de contenido de torrent:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Crear subcarpeta</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>No crear subcarpeta</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>Añadir etiquetas</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>Añadir regla</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>Agregar detenido:</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation>Confirmación de borrar episodios descargados</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>Sin tracker</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Eliminar tracker</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Error del rastreador</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation>Otro error</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>Canales RSS</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Bloqueado</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>mostrando</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar Todo</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Tipo de Registro</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>Mensajes de Información</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>Mensajes de aviso</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>Filtrar registros</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>IPs bloqueadas</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>fuera de</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>Marca de tiempo</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>Limpiar Todo</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>Niveles de registro:</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Motivo</translation>
    </message>
    <message>
        <source>item</source>
        <translation>elemento</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>Prohibido</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>Mensajes Normales</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>Crítico</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>Mensajes Críticos</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>items</source>
        <translation>elementos</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Informacion</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>Elija un nivel de registro...</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>¿Estás seguro de que quieres eliminar el rastreador "%1" de todos los torrents?</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>No se pudo editar la categoría</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>No se pudo crear la categoría</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>No se pudo establecer la categoría</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>Guardar ruta para torrents incompletos:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Nueva categoría</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Categoría:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Ruta:</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>Use otra ruta para torrents incompletos:</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation>La categoría no existe</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>Dominio</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>Administrar Cookies</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>Añadir Cookie</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>Fecha de caducidad</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>Habilitar administración de torrent automática.</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>¿Está seguro de que desea activar la administración automática de Torrent para el/los Torrent(s) seleccionados? Pueden que sean reubicados.</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>¿Esta seguro que desea comprobar los torrents seleccionados?</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>Confirmación de comprobación</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>Cerrar pestaña</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>Interfaz web de qBittorrent</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>¡Se requiere JavaScript! Debe habilitar JavaScript para que la Interfaz de Usuario de la Web  funcione correctamente</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>Respuesta del servidor:</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>No se puede iniciar sesión, probablemente el servidor no esté disponible.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Nombre de usuario o contraseña inválidos.</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>Privado</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Origen</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>En cola</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>No se puede crear torrent.</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>Torrent privado 
                            (no se distribuye en la red DHT)</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>No se puede exportar el archivo torrent.</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>Crear Nuevo Torrent</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Comentarios:</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>Descargar torrent</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Icono de estado</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>URLs de las semillas Web:</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Errado</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Finalizado</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>Mensaje de error</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>Alinear al límite de la parte para archivos 
       de más de:</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>Seleccione el archivo/carpeta para compartir:</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>Tamaño de la parte</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>Completado</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>Híbrido</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>No se pueden cargar las tareas de creación de torrent</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>Optimizar
                   la alineación</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>¿Está seguro de que desea eliminar las tareas seleccionadas?</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Ruta:</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>Crear Torrent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>Comenzó el</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Semillas web</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>Comenzar
                 a sembrar
                 inmediatamente</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Formato del torrent:</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>Ruta de origen</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>Agregado</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>Ejecutando</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Crear torrent</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>Origen:</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Rastreadores</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Tamaño de la pieza:</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Campos</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>Eliminar tarea</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>Exportar torrent</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">Descargar</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Enlace magnético</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Agregar enlaces torrent</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Un enlace por línea (pueden ser enlaces HTTP, enlaces magnet o info-hashes)</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URLs</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>Agregar enlaces torrent</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation>Límite:</translation>
    </message>
    <message>
        <source>Speed limit</source>
        <translation>Límite de velocidad</translation>
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>Límite de bajada:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation>Redimensionar Todo</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>Redimensionar</translation>
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation>¿Generar una clave API? Esta clave se puede usar para interactuar con la API de qBittorrent.</translation>
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation>¿Eliminar esta clave API? La clave actual dejará de funcionar inmediatamente.</translation>
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation>¿Desea cambiar esta clave API? La clave actual dejará de funcionar inmediatamente y se generará una nueva.</translation>
    </message>
</context>
</TS>