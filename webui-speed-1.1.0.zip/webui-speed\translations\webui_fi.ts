<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">Yleistä</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Kategoria:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Käynnistä torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Ohita tarkistus</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Torrentien hallintatila:</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>Sisällön ulkoasu:</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Alkuperäinen</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Luo alikansio</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Älä luo alikansiota</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuaalinen</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metatiedot vastaanotettu</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Tiedostot tarkistettu</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>Pysäytysehto:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Lisää jonon kärkeen</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Lataa järjestyksessä</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Koko:</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>Tallennuskohde</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Torrentin tiedot</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Tallennuspolku:</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>Infotarkistussumma v1:</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Nimeä torrent uudelleen</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation>Lisää torrent</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Tärkeysaste</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Korkea</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Torrentin asetukset</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normaali</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Latauskansio:</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>Aseta oletuskategoriaksi</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Rajoita lähetysnopeutta</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Suodata tiedostoja...</translation>
    </message>
    <message>
        <source>Add Torrent</source>
        <translation type="vanished">Lisää torrent</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>Käytä keskeneräisille torrenteille eri sijaintia</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Päiväys:</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation>Tallenna .torrent-tiedostona</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Suurin</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Älä lataa</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Lataa ensin ensimmäinen ja viimeinen osa</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Kommentti:</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation>Torrent-tiedostoa ei voitu ladata</translation>
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>Infotarkistussumma v2:</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>Tunnisteet:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Tiedostot</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Rajoita latausnopeutta</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>Kt/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Luokittelemattomat</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Lisää kategoria...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Poista kategoria</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Poista käyttämättömät kategoriat</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Uusi kategoria</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Muokkaa kategoriaa...</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Poista torrentit</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>Lisää alikategoria...</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Käynnistä torrentit</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Pysäytä torrentit</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Lopeta qBittorrent</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Yleisen lähetysnopeusrajoituksen täytyy olla suurempi kuin 0, tai poissa käytöstä.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Yleisen latausnopeusrajoituksen täytyy olla suurempi kuin 0, tai poissa käytöstä.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Vaihtoehtoisen lähetyksen rajan pitää olla suurempi kuin 0, tai poissa käytöstä.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Vaihtoehtoisen latauksen rajan pitää olla suurempi kuin 0, tai poissa käytöstä.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Aktiivisten latauksien enimmäismäärä pitää olla suurempi kuin -1</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Aktiivisten jakojen enimmäismäärä pitää olla suurempi kuin -1</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Aktiiivisten torrenttien enimmäismäärä pitää olla suurempi kuin -1</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Yhteyksien enimmäismäärän pitää olla suurempi kuin 0 tai poistettu käytöstä.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Yhteyksien torrenttikohtaisen maksimimäärän pitää olla suurempi kuin 0 tai poistettu käytöstä.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Lähetyslohkojen torrenttikohtaisen enimmäismäärän pitää olla suurempi kuin 0 tai poistettu käytöstä.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Toteuta</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Lisää tietoa</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Tietoa varmenteista</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Määritä sijainti</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Maanantai</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Tiistai</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Keskiviikko</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Torstai</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Perjantai</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lauantai</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sunnuntai</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Kirjaudu ulos</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent ei vastaa</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>Global number of lähetys slots raja täytyy olla suurempi kuin 0 or ei käytössä.</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>Virheellinen category name:\nPlease do not use any special characters in the category name.</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>lähetys rate threshold täytyy olla suurempi kuin 0.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Vapaata tilaa: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>Torrent inactivity timer täytyy olla suurempi kuin 0.</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>Tallennuksen hallinta</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>lataa rate threshold täytyy olla suurempi kuin 0.</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>Avaa ohje</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>Rekisteröi magneettilinkkien käsittelijäksi...</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>Toimintoa ei voitu suorittaa: add peers. Please ensure you are adhering to the IP:port format.</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>Nimi ei voi olla tyhjä</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>Nimi ei muuttunut</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>Nimen päivittäminen epäonnistui</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>The portti used for incoming yhteydet täytyy olla välillä 0 and 65535.</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>Alkuperäinen kehittäjä</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>The portti used for the WebUI täytyy olla välillä 1 and 65535.</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 on sammutettu</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript vaaditaan! Ota JavaScript käyttöön, jotta WebUI toimii oikein</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>Ulkoinen IP: ei saatavilla</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>Käänteisen välityspalvelimen määritysesimerkkejä</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>qBittorrentiin ei saatu yhteyttä</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Muista valinta</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>Haluatko varmasti poistaa nämä %1 torrentia siirtolistalta?</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>Torrentteja ei voitu poistaa.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Verkko-osoite</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>Ulkoinen IP: %1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>Muokkaa web-jakolähdettä</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>Are you sure you want to Poista %1 from the transfer luettelo?</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>Toimintoa ei voitu suorittaa: set Auto Torrent Management for the selected torrents.</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>Torrentteja ei voitu pysäyttää.</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>Tiedostoa ei voi ladata</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>Ulkoiset IP:t: %1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>Torrentteja ei voitu tarkistaa uudelleen.</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>luettelo of web seeds to Lisää (one per line):</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>Torrentteja ei voitu käynnistää.</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>Lisää web-jakolähteitä</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation>Toimintoa ei voitu suorittaa: delete API key.</translation>
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>Seeding aika raja must not have a negative value.</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>Share ratio raja must not have a negative value.</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation>vertainen turnover interval täytyy olla suurempi kuin or equal to 0.</translation>
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation>Vastausta ei voitu jäsentää.</translation>
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation>Toimintoa ei voitu suorittaa: rotate API key.</translation>
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation>vertainen turnover täytyy olla välillä 0 and 100.</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation>Outstanding muisti when tarkistus torrents täytyy olla suurempi kuin 0 and pienempi kuin 1024.</translation>
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation>Toimintoa ei voitu suorittaa: load program preferences, qBittorrent is probably unreachable.</translation>
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation>vertainen turnover cutoff täytyy olla välillä 0 and 100.</translation>
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation>vertainen DSCP täytyy olla välillä 0 and 255.</translation>
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation>Toimintoa ei voitu suorittaa: save preferences, qBittorrent is probably unreachable.</translation>
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation>Torrentteja ei voitu lisätä.</translation>
    </message>
    <message>
        <source>Error:</source>
        <translation>Virhe:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Työkalut</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Tiedosto</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Asetukset...</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Työkalupalkki</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Tilapalkki</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Nopeudet otsikkorivillä</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Lahjoita!</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Tilastot</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Tietoja</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Lisää torrent...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Dokumentaatio</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Avaa torrent osoitteesta...</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Kyllä</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ei</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Yleinen lähetysnopeusrajoitus</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Yleinen latausnopeusrajoitus</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Haluatko varmasti lopettaa qBittorrentin?</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Vaihtoehtoiset nopeusrajoitukset</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Hakukone</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>Suodata torrent-luettelo...</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Siirrot</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>Siirrä ylös jonossa</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>Siirrä ylös jonossa</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>Jonon viimeiseksi</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>Siirrä jonon viimeiseksi</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>Jonon kärkeen</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>Siirrä alas jonossa</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>Siirrä alas jonossa</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>Siirrä jonon ensimmäiseksi</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>Selaimesi ei tue tätä ominaisuutta</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>To use this feature, the WebUI needs to be accessed over HTTPS</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>Yhteyden tila: palomuurin takana</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>Yhteyden tila: yhdistetty</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>Vaihtoehtoiset nopeusrajoitukset: pois</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>Latausnopeuden kuvake</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>Vaihtoehtoiset nopeusrajoitukset: päällä</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>Lähetysnopeuden kuvake</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>Yhteyden tila: yhteys katkaistu</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS-lukija</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>Suodattimien sivupalkki</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Suoritusloki</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Loki</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[D: %1, U: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>Suodatin:</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>Tallennussijainti</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Pysäytä</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>Käytä säännöllistä lauseketta</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>Haluatko käynnistää kaikki torrentit?</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Käynnistä</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>Evästeiden hallinta...</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Torrent-tiedostoa ei voitu viedä</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>Haluatko pysäyttää kaikki torrentit?</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>Käynnistä kaikki</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>Pysäytä kaikki</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrentin luonti</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation>Suodata syötteen kohteita...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Lataukset</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Yhteys</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Nopeus</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Sähköposti-ilmoitus latauksen valmistuttua</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP-suodatus</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Aseta aikataulu vaihtoehtoisille nopeusrajoituksille</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrentien jonotus</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Web-käyttöliittymä (Etäohjaus)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>IP osoite:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Palvelimen verkkotunnukset:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Käytä HTTPS:ää HTTP:n sijaan</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Ohita tunnistautuminen localhostista saapuvien asiakkaiden kohdalla</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Ohita tunnistautuminen valkolistattujen IP-aliverkkojen asiakkaiden kohdalla</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Päivitä dynaamisen verkkotunnukseni nimi</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Säilytä keskeneräiset torrentit kohteeseen:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopioi .torrent-tiedostot kohteeseen:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Kopioi valmistuneiden latausten .torrent-tiedostot kohteeseen:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Varaa kaikille tiedostoille levytila ennakkoon</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Lisää .!qB pääte keskeneräisille tiedostoille</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Lisää torrentit automaattisesti kohteesta:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP-palvelin:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Tämä palvelin vaatii suojatun yhteyden (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Tunnistautuminen</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Käyttäjänimi:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasana:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP ja μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Kuunteluportti</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Portti sisääntuleville yhteyksille:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Käytä UPnP-/NAT-PMP-portinohjausta reitittimeltä</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Yhteyksien rajat</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Yhteyksien enimmäismäärä torrenttia kohden:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Kaikkien yhteyksien enimmäismäärä:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Lähetyspaikkojen enimmäismäärä torrentia kohden:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Kaikkien lähetyspaikkojen enimmäismäärä:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Välityspalvelin</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tyyppi:</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Isäntä:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Portti:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Käytä välityspalvelinta vertaisyhteyksille</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Suodatustiedoston sijainti (.dat, .p2p, p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Manuaalisesti kielletyt IP-osoitteet...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Käytä seurantapalvelimille</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Yleiset nopeusrajoitukset</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Lähetys:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Lataus:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Vaihtoehtoiset nopeusrajoitukset</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Alkaen:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Loppuu:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Ajankohta:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Joka päivä</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Arkisin</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Viikonloppuisin</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Nopeusrajoitusasetukset</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Käytä nopeusrajoitusta siirron rasiteliikenteelle</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Käytä nopeusrajoitusta µTP-protokollaan</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Yksityisyys</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Käytä DHT:tä (hajautettua verkkoa) useampien käyttäjien löytämiseen</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Käytä PeX:tä löytääksesi enemmän käyttäjiä</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Käytä paikallista hakua löytääksesi enemmän käyttäjiä (LPD)</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Salaustila:</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Vaadi salaus</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Ei salausta</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Käytä anonyymitilaa</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Aktiivisia latauksia enintään:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Aktiivisia lähetettäviä torrentteja enintään:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Aktiivisia torrentteja enintään:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Älä laske hitaita torrenteja näihin rajoituksiin</translation>
    </message>
    <message>
        <source>then</source>
        <translation>sitten</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Käytä UPnP:tä / NAT-PMP:tä porttiohjaukseen reitittimeltä</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Varmenne:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Avain:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Rekisteröidy</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Verkkotunnuksen nimi:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Tuetut parametrit (kirjainkoolla on merkitystä):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Torrentin nimi</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Kategoria</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Sisällön sijainti (vastaa monitiedostoisen torrentin juurikansiota)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Juurisijainti (torrentin ensimmäisen alihakemiston polku)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Tallennussijainti</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Tiedostojen määrä</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrenin koko (tavua)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Nykyinen seurantapalvelin</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minuuttia</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>Kt/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>Käytä clickjacking-suojausta</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Käytä Cross-Site Request Forgery (CSRF) -suojausta</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>Poista .torrent-tiedostot lisäämisen jälkeen</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>Latausnopeuden raja:</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>Lähetysnopeuden raja:</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>Vaihda nykyinen salasana</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>Tallennuksen oletussijainti:</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>Älä aloita latausta automaattisesti</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>Vaihda torrent manuaaliseen tilaan</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>Kun torrentin kategoria muutetaan:</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>Uudelleensijoita vaikuttuneet torrentit</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Käytä nopeusrajoitusta paikallisverkossa (LAN) oleviin vertaisiin</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 tarkoittaa rajoittamatonta</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>Uudelleensijoita torrentti</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>Tallennuksen oletussijainnin muuttuessa:</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>Käytä Host-otsakkeen validointia</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Tietoturva</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>Kategorian tallennussijainnin muuttuessa:</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>sekuntia</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Vaihda vaikuttuneet torrentit manuaaliseen tilaan</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>Tiedostojen sijainti:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuaalinen</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Torrentin passiivisuusajastin:</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>Torrentien oletusarvoinen hallintatila:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Kun lisätään torrent-tiedostoa</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>μTP-TCP mixed mode algorithm:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>Lähetysnopeuteen perustuva</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Tunnisteet (pilkuin eroteltuna)</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Socket backlog size:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Käytä torrentille super seeding -tilaa</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>Suosi TCP:tä</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>Muistin varaus tarkistettaessa torrent-tiedostoja:</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>Pelkän latauksen vastainen</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>Jakosuhteen muuttuessa</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>Salli useita yhteyksiä samasta IP-osoitteesta:</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>Tiedosto pool size:</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>Mikä tahansa liitäntä</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>Always announce to all tiers:</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>Upotetun seurantapalvelimen portti:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>Nopein lähetys</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>Poista torrent ja sen tiedostot</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>qBittorrentin asetukset</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>Send buffer watermark factor:</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>libtorrentin asetukset</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>Recheck torrents on completion:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>Salli salaus</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>Send lähetys piece suggestions:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>Ota käyttöön embedded seurantapalvelin:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Poista torrent</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>Asynkroniset I/O-säikeet:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>Send buffer watermark:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Vertaissuhteutus (TCP-kiihdytys)</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>Kiinteät paikat</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <source>min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>lähetys choking algorithm:</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>Jakamisen rajoitukset</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>Kt</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>Kiertovuorottelu</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>lähetys slots behavior:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>Mt</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>Send buffer low watermark:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>Tallenna resume tiedot interval:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>Always announce to all trackers in a tier:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>Istunnon aikakatkaisu:</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>Selvitä vertaisten maat:</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>eston kesto:</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>Estä asiakas, kun perättäisiä epäonnistumisia:</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Header: value pairs, one per line</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>Lisää mukautetut HTTP-otsakkeet</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>Suodattimet:</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>Ota käyttöön RSS-syötteiden haku</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>vertainen turnover threshold percentage:</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>RSS-torrenttien automaattinen lataaja</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>Verkkosovitin:</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS-lukija</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>Muokkaa automaattisten latausten sääntöjä...</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Lataa REPACK/PROPER-jaksot</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>RSS-syötteen päivitystiheys:</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>vertainen turnover disconnect percentage:</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Artikkeleiden enimmäismäärä syötettä kohden:</translation>
    </message>
    <message>
        <source> min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>vertainen turnover disconnect interval:</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>Optional IP address to bind to:</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>Disallow yhteys to vertaiset on privileged ports:</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Ota käyttöön RSS-torrenttien automaattinen lataus</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>Älykäs RSS-jaksosuodatin</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>Validate HTTPS seurantapalvelin certificate:</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>Vertaisyhteyksien protokolla:</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Torrentin sisällön asettelu:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Luo alikansio</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Alkuperäinen</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Älä luo alikansiota</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>Outgoing yhteydet per second:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Satunnainen</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: Torrent ID</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>Reannounce to all trackers when IP or portti changed:</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>Luotettujen välityspalvelinten luettelo:</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>Käytä käänteisen välityspalvelimen tukea</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J: Info hash v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: Info hash v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>IP address reported to trackers (vaatii uudelleenkäynnistyksen):</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Set to 0 to let your system pick an unused portti</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>Server-side request forgery (SSRF) mitigation:</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>Disk queue size:</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>Lokita suorituskykyvaroitukset</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>enimmäis outstanding requests to a single vertainen:</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>Max aktiivinen tarkistus torrents:</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>Muistikartoitettu tiedosto</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Oletus</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>POSIX-määritysten mukainen</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>Määrittää sisäisen tilapäivitystiheyden, joka puolestaan vaikuttaa käyttöliittymän päivittymiseen.</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>Disk IO read mode:</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>Älä käytä käyttöjärjestelmän välimuistia</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>Disk IO write mode:</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>Use piece extent affinity:</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>Max concurrent HTTP announces:</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>Ota käyttöön käyttöjärjestelmän välimuisti</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>Päivitystiheys:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>Poissuljetut tiedostonimet</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>Support internationalized domain nimi (IDN):</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>HTTPS certificate should not be empty</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>HTTPS avain should not be empty</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>Suorita ulkoinen ohjelma</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Tiedostot tarkastettu</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>Ota käyttöön portti forwarding for embedded seurantapalvelin:</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>If checked, hostname lookups are done via the proxy.</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metatiedot vastaanotettu</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Torrentin pysäytysehto:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Esimerkki: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>SQLite-tietokanta (kokeellinen)</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>Resume tiedot storage type (vaatii uudelleenkäynnistyksen):</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>Pikajatka tiedostoja</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>Ota lokista varmuuskopio, kun sen koko ylittää:</translation>
    </message>
    <message>
        <source>days</source>
        <translation>päivää</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Toiminta</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>Poista varmuuskopiot, jotka ovat vanhempia kuin:</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>Käytä välityspalvelinta BitTorrent-liikenteeseen</translation>
    </message>
    <message>
        <source>years</source>
        <translation>vuotta</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Tallennussijainti:</translation>
    </message>
    <message>
        <source>months</source>
        <translation>kuukautta</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>Remember Multi-Rename asetukset</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>Käytä välityspalvelinta yleisiin tarkoituksiin</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>Käytä välityspalvelinta RSS-tarkoituksiin</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>Socket send buffer size [0: system Oletus]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>Outgoing ports (Max) [0: ei käytössä]:</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>Socket receive buffer size [0: system Oletus]:</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Lisää jonon kärkeen</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>Stop seurantapalvelin timeout [0: ei käytössä]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>Outgoing ports (Min) [0: ei käytössä]:</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>UPnP lease duration [0: permanent lease]:</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Bdecode depth raja:</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Bdecode token raja:</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>Kun kokonaisjakoaika saavuttaa</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Ei mikään)</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Python executable polku (may require restart):</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>Resets to Oletus if empty</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>Selvitä isäntänimi välityspalvelimen kautta</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get vertaiset from other sources than the seurantapalvelin, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P vertaiset.</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>DHT bootstrap nodes:</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>Kun passiivinen jakoaika saavuttaa</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>Yhdistelmätila</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>.Torrent Tiedosto size raja:</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>(Havaitse automaattisesti jos tyhjä)</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>Säilytä valitsemattomat tiedostot ".unwanted"-kansiossa</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>Ota käyttöön Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</translation>
    </message>
    <message>
        <source> sec</source>
        <translation>s</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>I2P outbound quantity:</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>I2P inbound quantity:</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>Hashing threads:</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>Physical muisti (RAM) usage raja:</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>Käytä vaihtoehtoista WebUI:ta</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>Disk cache expiry interval:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>I2P outbound length:</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P (kokeellinen)</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>Disk IO type (vaatii uudelleenkäynnistyksen):</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>The alternative WebUI files location ei voi be blank.</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>Disk cache:</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>Write through on tallennustapa, jossa tiedot kirjoitetaan välimuistiin ja vastaavaan päämuistipaikkaan samanaikaisesti.</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>WebUI</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>The WebUI salasana täytyy olla at least 6 characters long.</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>Coalesce reads &amp;amp; writes:</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>I2P inbound length:</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>The WebUI käyttäjänimi täytyy olla at least 3 characters long.</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>Saman isännän pyyntöviive:</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>Customize application instance nimi:</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>Väriteema:</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>Näytä ulkoinen IP tilarivillä</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>Noudetut seurantapalvelimet</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>Vahvista torrentin poisto</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>Ohita SSL-virheet:</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Tumma</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>Poista tiedostot pysyvästi</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>Käytä vaihtelevia rivivärejä</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>Display full announce URL in the seurantapalvelin column</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>Siirtoluettelo</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>The announce portti täytyy olla välillä 0 and 65535.</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Vaalea</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>Automatically append these trackers to new downloads:</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Torrentteja ladatessa:</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>Käynnistä/pysäytä torrent</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>Lähetä testisähköposti</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Valmistuneet torrentit:</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>Ota käyttöön cookie Secure flag (requires HTTPS or localhost yhteys)</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Toiminta kaksoisnapsautuksella</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>Tallenna statistics interval:</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Näyttää vahvistusikkunan torrentia poistaessa</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>Suorita torrentin valmistuttua:</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>Attempted to send email. Check your inbox to confirm success</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>Automatically append trackers from URL to new downloads:</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Torrent content removing mode:</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>Siirrä tiedostot roskakoriin (jos mahdollista)</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Pysäytä torrent</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>Use Category paths in Manual Mode</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>Vaihtoehtoisten WebUI-käyttöliittymien luettelo</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>Suorita torrentin lisäämisen jälkeen:</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>portti reported to trackers (vaatii uudelleenkäynnistyksen) [0: listening portti]:</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>Käyttöliittymän kieli:</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>Yhdistä seurantapalvelimet olemassa olevaan torrentiin</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation>Vahvista torrent recheck:</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>Mukautetun WebUI:n asetukset</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>Seuraavat asetukset koskevat vain WebUI:ta</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>Simple pread/pwrite</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Selvitä suhteellinen tallennussijainti tallennuksen oletussijainnin sijaan sopivan kategorian sijainnilla</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Ei toimintoa</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>Piilota nollatilaiset suodattimet automaattisesti</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Käyttöliittymä</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>Lokitiedostot</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>Ota optimoitu taulukon piirto käyttöön (kokeellinen)</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>Huomautus: salasana tallennetaan salaamattomana</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>Internal hostname resolver cache expiry interval</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>s</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation>Rotate API avain</translation>
    </message>
    <message>
        <source>Generate a key</source>
        <translation>Luo avain</translation>
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation>When adding a duplicate Torrent</translation>
    </message>
    <message>
        <source>Delete API key</source>
        <translation>Poista API-avain</translation>
    </message>
    <message>
        <source>%M: Comment</source>
        <translation>%M: Comment</translation>
    </message>
    <message>
        <source>Generate API key</source>
        <translation>Luo API-avain</translation>
    </message>
    <message>
        <source>Copied</source>
        <translation>Kopioitu</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Käyttäjä</translation>
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation>Nollaa suodatinvalinta</translation>
    </message>
    <message>
        <source>API Key</source>
        <translation>API-avain</translation>
    </message>
    <message>
        <source>Copy API key</source>
        <translation>Kopioi API-avain</translation>
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation>Differentiated Services Code Point (DSCP) for yhteydet to vertaiset</translation>
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation>The WebUI käyttäjänimi must not contain a colon.</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>Päivämäärän muoto:</translation>
    </message>
    <message>
        <source>Browser default</source>
        <translation>Selaimen oletus</translation>
    </message>
    <message>
        <source>Localization</source>
        <translation>Lokalisointi</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>Tiivis</translation>
    </message>
    <message>
        <source>Display density:</source>
        <translation>Näyttötiheys:</translation>
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation>It appends the text to the window title to help distinguish qBittorrent instances</translation>
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation>Selvitä vertaisten isäntänimet:</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>Portti</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Liput</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Yhteys</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Asiakassovellus</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Edistyminen</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Latausnopeus</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Lähetysnopeus</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Ladattu</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Lähetetty</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Merkityksellisyys</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Tiedostot</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Estä vertainen pysyvästi</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Haluatko varmasti estää valitut vertaiset pysyvästi?</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>Kopioi IP:portti</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>Maa/alue</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>Lisää vertaisia...</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>Vertaisen asiakassovelluksen tunniste</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>IP/Osoite</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normaali</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Korkea</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Korkein</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Sekalainen</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Älä lataa</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Yleiset</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Seurantapalvelimet</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Lataajat</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP-lähteet</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Sisältö</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Ladattu:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Siirto</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aikaa aktiivisena:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Aika:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Lähetetty:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Jakajia:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Latausnopeus:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Lähetysnopeus:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Lataajia:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Latausraja:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Lähetysraja:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Hukattu:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Yhteydet:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Kommentti:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Jakosuhde:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Julkaise uudelleen:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Viimeksi nähty valmistuneen:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Koko yhteensä:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Osia:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Luonut:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Lisätty:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Valmistunut:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Luotu:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Tallennussijainti:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ei koskaan</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (hallussa %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (tässä istunnossa %2)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (enintään %2)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 yhteensä)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (keskimäärin %2)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Tärkeysaste</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Suodata tiedostoja...</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Nimeä uudelleen...</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (jaettu %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>Infotarkistussumma v2:</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>Infotarkistussumma v1:</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Edistyminen:</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Käytä säännöllisiä lausekkeita</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Tiedostonimi</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>Tiedostonimi + pääte</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>Numeroi tiedostot</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>Nimeäminen epäonnistui: tiedosto tai kansio on jo olemassa</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>Vaihda valintaa</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>Korvaava teksti</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Korvaa</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>Tiedostopääte</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>Korvaa kaikki</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>Sisällytä tiedostot</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>Sisällytä kansiot</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>Etsi tiedostoista</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Huomioi kirjainkoko</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>Täsmää kaikki esiintymät</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>Kopioi web-jakolähteen URL</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>Korvausvalinta</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>Muokkaa web-jakolähteen URL-osoitetta...</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>Web-jaon URL-osoite</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Kyllä</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>Ratio / aika aktiivinen (in months), indicates how popular the Torrent is</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>Suosio:</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>Mihin tiedostonimen osaan käytetään</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ei</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>Poista web-jako</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>Web-jaon muokkaus</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>Lisää web-jakolähteitä...</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>Yksityinen:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Saatavuus:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Valvottu Kansio</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Ylitä tallennussijainti</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Valvottu kansio</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Oletus tallennussijainti</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>Muu...</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Kirjoita kansio tähän</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Tilastot</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Käyttäjätilastot</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Välimuistitilastot</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Luetut välimuistin osumat:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Keskimääräinen aika jonossa:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>Yhdistetyt vertaiset:</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>Jakosuhde yhteensä:</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>Yhteensä ladattu:</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>Hukattu tässä istunnossa:</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>Lähetetty kaikkiaan:</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>Puskurien koko yhteensä:</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Suorituskykytilastot</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Jonoon asetetut I/O-työt:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Kirjoitusvälimuistin ylikuormitus:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Lukuvälimuistin ylikuormitus:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Jonotettu koko yhteensä:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 solmua</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Kaikki (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Ladataan (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Jakaa (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Valmiina (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Aktiivisena (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Ei aktiivisena (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Virheelliset (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Kaikki (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Ladataan (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Jakaa (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Valmiina (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Aktiivisena (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Ei aktiivisena (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Virheelliset (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>Pysähtynyt lähetys (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>Pysähtynyt lataus (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>Pysähtynyt lataus (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>Pysähtynyt (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>Pysähtynyt lähetys (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>Pysähtynyt (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>Tarkistetaan (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>Tarkistetaan (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>Siirretään (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>Siirretään (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>Käynnissä (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>Pysäytetty (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>Pysäytetty (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>Käynnissä (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Poista torrentit</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Käynnistä torrentit</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Pysäytä torrentit</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Jakajia</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Lataajia</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Latausnopeus</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Lähetysnopeus</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Jakosuhde</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Aikaa valmistumiseen</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategoria</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tunnisteet</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Lisätty</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Valmistunut</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Seurantapalvelin</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Latausraja</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Lähetysraja</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Ladattu</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Lähetetty</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Jäljellä</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Aikaa aktiivisena</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Tallennussijainti</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Valmistunut</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Jakosuhteen raja</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Viimeksi nähty valmistuneen</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Viimeisin toiminta</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Koko yhteensä</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Saatavuus</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>Reannounce In</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Yksityinen</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Edistyminen</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>Info Hash v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>Info Hash v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>Keskeneräisen tallennussijainti</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>Suosio</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Tilakuvake</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation>Session Uploaded</translation>
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation>Session Downloaded</translation>
    </message>
    <message>
        <source>Created On</source>
        <translation>Created On</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Käyttäjät</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Viesti</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>Seurantapalvelimen osoite:</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Päivitetään...</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Toiminnassa</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Pois käytöstä</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Ei yhteyttä vielä</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>Jakajia</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Ei toimi</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>Kopioi seurantapalvelimen osoite</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>Muokkaa seurantapalvelimen osoitetta...</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>Seurantapalvelimen muokkaus</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>Lataajat</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Poista seurantapalvelin</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Jäljellä</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Saatavuus</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>Taso</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Latauksen tärkeys</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Edistyminen</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>Koko yhteensä</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>Latauskerrat</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>Lisää seurantapalvelimia...</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>Nimetty uudelleen</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Alkuperäinen</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/Announce Endpoint</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>BT Protocol</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>Next Announce</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation>Taso:</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Seurantapalvelimen virhe</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>Ei saavutettavissa</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation>Pakota uudelleenilmoitus valituille seurantapalvelimille</translation>
    </message>
    <message>
        <source>Min Announce</source>
        <translation>Min Announce</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>Pakota uudelleenjulkaisu kaikille seurantapalvelimille</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lisättävien seurantapalvelimien lista (yksi per rivi):</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>Lisää seurantapalvelimia</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 sitten</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Valmistunut</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>Siirretään</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[P] Jaetaan</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>Jaetaan</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Jonossa</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[P] Ladataan</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>Ladataan metatietoja</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>Tarkistetaan</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>Puuttuvia tiedostoja</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>Tarkistusjonossa</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Ladataan</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>Tarkistetaan jatkotietoja</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>Pysähtynyt</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (jaettu %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[P] Ladataan metatioetoja</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Pysäytetty</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Kategoriat</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tunnisteet</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Seurantapalvelimet</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>Supista/laajenna</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>Supista/laajenna kategoria</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Torrentin latausnopeuden rajoitus</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Torrentin lähetysnopeuden rajoitus</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Nimeä uudelleen</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Rajoita jakosuhdetta...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Rajoita lähetysnopeus...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Rajoita latausnopeus...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Siirrä ylös jonossa</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Siirrä alas jonossa</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Siirrä jonon kärkeen</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Siirrä jonon viimeiseksi</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Aseta kohdekansio...</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Lataa ensin ensimmäinen ja viimeinen osa</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Automaattinen torrentien hallintatila</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategoria</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Uusi...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Palauta</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Pakota uudelleentarkistus</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>super seed -tila</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Nimeä uudelleen...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Lataa järjestyksessä</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Uusi kategoria</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Aseta sijainti</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Pakota uudelleenjulkaisu</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>Muokkaa kategoriaa</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>Pilkulla erotetut tunnisteet:</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Tunnisteet</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnet-linkki</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>Poista kaikki</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Jono</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Lisää...</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>Infotarkistussumma v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>Infotarkistussumma v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>Torrentin tunniste</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>Vie .torrent</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>Nimeä tiedostot uudelleen...</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>Nimetään uudelleen</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>Pakota käynnistys</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Pysäytä</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automaattisessa tilassa monet torrenttien määritykset, kuten tallennussijainti, asetetaan liitetyn kategorian perusteella</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Käynnistä</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Uusi nimi:</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>Lisää tunnisteita</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation>Sisällön polku</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Torrentin lähetys/lataus suhteen rajoitus</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Käytä yleistä jako rajoitusta</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Älä aseta jakorajoitusta</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Aseta jakorajoitukseksi</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>Jakosuhde</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>yhteensä minuutteja</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>ei käynnissä minuutteja</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Oletus</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Poista torrentti</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>Poista torrent ja sen sisältö</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Pysäytä torrent</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Käytä torrentille superjakoa</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation>Toiminto rajan täyttyessä</translation>
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>Poista torrenteja</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>Poista myös sisältötiedostot</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Poista seurantapalvelin</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Lataa verkko-osoitteista</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>t</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>Kt</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>Mt</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>Gt</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>Tt</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>Pt</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>Et</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1 h %2 min</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1 d %2 h</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>alle minuutti</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 min</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1y %2d</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>Tallennussijainti on tyhjä</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>Liitännäisen sijainti:</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>Osoite tai paikallinen kansio</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>Asenna liitännäinen</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>Jakajia:</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>Kaikki liitännäiset</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Koko:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Pysäytä</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>Etsi liitännäisiä...</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>Kaikki kategoriat</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>Etsitään:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Suodatin</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>Vain torrentin nimestä</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>Vain käytössä olevat</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>/</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>Kaikkialta</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>Levennä ikkunaa nähdäksesi lisäsuodattimet</translation>
    </message>
    <message>
        <source>to</source>
        <translation>–</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Tulokset</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>näytetään</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>Click the "haku plugins..." button at the bottom right of the window to install some.</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>Hakulisäosia ei ole asennettu.</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>Valitse kategoria</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>Vähimmäiskoon etuliite</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>Aloita haku yllä.</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>Enimmäiskoon etuliite</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>Valitse liitännäiset</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>Poista asennus</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>Asenna uusi liitännäinen</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>Saat uusia hakukoneliitännäisiä täältä:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>Asennetut hakuliitännäiset:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Käytössä</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Varoitus: Muista noudattaa maasi tekijänoikeuslakeja, kun lataat torrentteja mistä tahansa näistä hakukoneista.</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Tarkista päivitykset</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>Hakuliitännäiset</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>Lataajia</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>Jakoja</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>Julkaistu</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>Hakukoneen URL</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>Hakukone</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Käytössä</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Kyllä</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ei</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>Lisää vertaisia</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>Lista lisättävistä vertaisista (yksi IP riviä kohden):</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Muoto: IPv4:portti / [IPv6]:portti</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>Uusi tunniste</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>Lisää tunniste...</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>Tunniste:</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>Poista käyttämättömät tunnisteet</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>Virheellinen tunnisteen nimi</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>Poista tunniste</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Poista torrentit</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Käynnistä torrentit</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Pysäytä torrentit</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>Ilman tunnistetta</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Viat:</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Tietoja</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Foorumi:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>Sähköposti:</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>Nykyinen ylläpitäjä</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Verkkosivusto:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>Kreikka</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>Erityiskiitokset</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Monipuolinen BitTorrent-asiakasohjelmisto, ohjelmoitu C++:lla. Pohjautuu Qt:hen ja libtorrent-rasterbariin.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nimi:</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>Tietoa qBittorrentista</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Lisenssi</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>Kääntäjät</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent rakennettiin käyttäen seuraavia kirjastoja:</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>Kansallisuus:</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>Käytetyt ohjelmistot</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>Vapaata ja ilmaista "IP to Country Lite" DB-IP:n ylläpitämää tietokantaa käytetään erottelemaan ja näyttämään vertaiskäyttäjien maat. Tämän tietokannan käyttölupa toimii Creative Commons Attributions 4.0 License:n alaisuudessa</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Tekijät</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Ranska</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>qBittorrent-maskotti</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>qBittorrent-kuvake</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>Kaikki osoitteet</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>Kaikki IPv6-osoitteet</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>Kaikki IPv4-osoitteet</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Lataa</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>Kuvaussivun osoite</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>Avaa kuvaussivu</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>Lataa linkki</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Haku on päättynyt</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>Haun aikana tapahtui virhe...</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>Sulje välilehti</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Haetaan...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Haku keskeytettiin</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>Sulje kaikki välilehdet</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation>Päivitä välilehti</translation>
    </message>
    <message>
        <source>Open download window</source>
        <translation>Avaa latausikkuna</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation>Käytä hakutekstinä</translation>
    </message>
    <message>
        <source>Stop search</source>
        <translation>Pysäytä haku</translation>
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>Nimetään uudelleen</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Uusi nimi:</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>Päiväys:</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Valitse uusi nimi tälle RSS-syötteelle</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Valitse kansion nimi</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Uusi syötteen nimi:</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Päivitä kaikki</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS-lataaja...</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Merkitse kohteet luetuiksi</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Päivitä kaikki syötteet</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Kopioi syötteen osoite</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrentit: (kaksoisnapsauta ladataksesi)</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Avaa uutisten osoite</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Nimeä uudelleen...</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>Syötteen osoite:</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Uusi kansio...</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Uusi tilaus</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Päivitä</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Kansion nimi:</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>Anna RSS-syötteen verkko-osoite.</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>RSS-syötteiden haku on nyt poistettu käytöstä! Voit ottaa sen käyttöön sovellusasetuksista.</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>Poistamisen vahvistus</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Haluatko varmasti poistaa valitut RSS-syötteet?</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Uusi tilaus...</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Lataa torrentti</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>Muokkaa syötteen osoitetta...</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>URL-osoitetta ei voitu päivittää</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>URL ei muuttunut</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>URL-osoite ei voi olla tyhjä</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>Avaa linkki</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Tekijä: </translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>Lataussäännöt</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>Vastaavat RSS-artikkelit</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* vastaamaan nolla tai enemmän mitä tahansa merkkiä</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation>tulee täsmäämään kaikkien nimikkeiden kanssa.</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>Jaksosuodattimen säännöt:</translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>RSS-torrenttien automaattinen lataus on nyt poistettu käytöstä! Voit ottaa sen käyttöön sovellusasetuksista.</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>Säännön määrittäminen</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Tallenna kohteeseen:</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>Käytä säännöllisiä lausekkeita</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Uuden säännön nimi</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>Suodattimen on päätyttävä puolipisteeseen</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? vastaamaan mitä tahansa yksittäistä merkkiä</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>Täsmää nimikkeisiin jotka perustuvat jaksosuodattimeen.</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>Määritä kategoria:</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regex-tila: käytä Perl-yhteensopivia säännöllisiä lausekkeita</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>| käytetään OR-operaattorina</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>Tyhjennä ladatut jaksot</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Tyhjät välit lasketaan JA toimintoina (kaikki sanat, mikä tahansa järjestys)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>Pyyntö tyhjällä %1 lausekkeella (esim. %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>Esimerkki:</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Lisää uusi sääntö...</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Oletko varma että haluat tyhjentää ladattujen jaksojen luettelon valitulle säännölle?</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>Täytyy sisältää:</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Rajoittamaton alue: &lt;b&gt;1x25-;&lt;/b&gt; poimii jaksot 25 ja siitä ylöspäin kaudesta yksi, myös kaikki jaksot myöhemmistä kausista</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>Tallenna toiseen hakemistoon</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>Ei saa sisältää:</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Yksi numero: &lt;b&gt;1x25;&lt;/b&gt; vastaa ensimmäisen kauden jaksoa 25</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>Jaksoille tuetaan kolmea aluetyyppiä:</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Haluatko varmasti poistaa valitut lataussäännöt?</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>Käytä yleisiä asetuksia</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Normaali jakauma: &lt;b&gt;1x25-40;&lt;/b&gt; vastaa ensimmäisen kauden jaksoja 25-40</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Anna uuden säännön nimi</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Säännön nimeäminen uudelleen</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Aina</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>Jakson numero on oltava positiivinen arvo</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation>poimii 2, 5, 8 ja läpi 15, 30 sekä jaksot siitä eteenpäin kaudesta yksi</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Säännön poistamisen vahvistus</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>Viimeisin täsmäys: %1 päivää sitten</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>Jaksosuodatin:</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>RSS-lataaja</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Tuotantokauden numero on oltava enemmän kuin nolla</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ei koskaan</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>Käytä sääntöä syötteisiin:</translation>
    </message>
    <message>
        <source> days</source>
        <translation> päivää</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>Käytä älykästä jaksosuodatinta</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Jos sanajärjestys on tärkeä, käytä * välilyönnin sijaan.</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Anna uuden lataussäännön nimi.</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>Jokerimerkkitila: voit käyttää</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation>Sulkee pois kaikki artikkelit.</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Poista sääntö</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>Sivuuta myöhemmät täsmäykset tälle (0 kytkee pois)</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Nimeä sääntö uudelleen...</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>Viimeisin täsmäys: ei tiedossa</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>Tyhjennä ladatut jaksot...</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>Älykäs jaksosuodatin tarkistaa jaksonumeron estääkseen kaksoiskappaleiden latauksen.
Nämä muodot ovat tuetut: S01E01, 1x1, 2017.12.31 ja 31.12.2017 (päiväysmuodot tukevat myös väliviivaa ( - ) erottajana)</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Torrentin sisällön asettelu:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Luo alikansio</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Alkuperäinen</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Älä luo alikansiota</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>Lisää tunnisteet:</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>Poista sääntö</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>Lisää sääntö</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>Lisää pysäytettynä:</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation>Ladattujen jaksojen tyhjennyksen vahvistus</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>Poista torrentit</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>Ilman seurantapalvelinta</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Käynnistä torrentit</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Poista seurantapalvelin</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Pysäytä torrentit</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Seurantapalvelimen virhe</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation>Muu virhe</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS-syötteet</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Lukematon</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>Yleiset</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Estetty</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>näytetään</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Tunniste</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Lokityyppi</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>Tiedotusviestit</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>Varoitusviestit</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>Suodata lokeja</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Estetyt IP-osoitteet</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>/</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>Aikaleima</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>Tyhjennä kaikki</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Viesti</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>Lokitasot:</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Syy</translation>
    </message>
    <message>
        <source>item</source>
        <translation>kohde</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>Estetty</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>Normaalit viestit</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>Kriittinen</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>Kriittiset viestit</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normaali</translation>
    </message>
    <message>
        <source>items</source>
        <translation>kohdetta</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Tulokset</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>Valitse lokitaso...</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>Are you sure you want to Poista seurantapalvelin %1 from all torrents?</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>Kategorian muokkaaminen ei onnistu</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>Kategorian luominen ei onnistu</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>Kategoriaa ei voitu asettaa</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>Keskeneräisten torrentien tallennussijainti:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Oletus</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Uusi kategoria</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Tallennussijainti:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Kyllä</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Kategoria:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ei</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>Käytä keskeneräisille torrenteille eri sijaintia:</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation>Category does not exist</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>Verkkotunnus</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>Evästeiden hallinta</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>Lisää eväste</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>Vanhenemispäivä</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Arvo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>Käytä torrentien automaattista hallintaa</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>Haluatko varmasti ottaa käyttöön automaattiset muokkaukset valitulle torrentille? Ne voidaan sijoittaa uudelleen.</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Haluatko varmasti tarkistaa uudelleen valitut torrentit?</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>Uudelleentarkistuksen vahvistus</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>Sulje välilehti</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>qBittorrentin WebUI</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript vaaditaan! Ota JavaScript käyttöön, jotta WebUI toimii oikein</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Kirjaudu</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>Palvelimen vastaus:</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>Kirjautuminen epäonnistui; palvelimeen ei todennäköisesti saada yhteyttä.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Käyttäjänimi</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Virheellinen käyttäjätunnus tai salasana.</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>Yksityinen</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Lähde</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Jonossa</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>Torrentia ei voitu luoda.</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>Yksityinen
                torrent (ei jaeta DHT-verkossa)</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Torrent-tiedostoa ei voitu viedä</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>Luo uusi torrent</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Kommentit:</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>Lataa torrent</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Tilakuvake</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>Web-jaot:</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Epäonnistui</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Valmis</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>Virheviesti</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>Align to piece boundary for files larger
                than:</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>Valitse jaettava tiedosto tai kansio:</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>Palan koko</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Edistyminen</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>Valmistunut</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>Hybridi</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>Torrentin luontitehtäviä ei voitu ladata</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>Optimize
                    alignment</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Seurantapalvelimien osoitteet:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>Haluatko varmasti poistaa valitut tehtävät?</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>Luo torrent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>Aloitettu</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Web-jakolähteet</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>Aloita
                jakaminen
                heti</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Torrentin muoto:</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>Lähdepolku</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>Lisätty</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>Käynnissä</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrentin luonti</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>Lähde:</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Seurantapalvelimet</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Osakoko:</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Kentät</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>Poista tehtävä</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>Vie torrent</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">Lataa</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnet-linkki</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Lisää torrent-linkit</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Yksi linkki riviä kohden (tuetaan HTTP-linkkejä, Magnet-linkkejä ja infotarkistussummia)</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL-osoitteet</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>Lisää torrent-linkkejä</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation>Raja:</translation>
    </message>
    <message>
        <source>Speed limit</source>
        <translation>Nopeusraja</translation>
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>Lähetysraja:</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>Latausraja:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>Kt/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation>Muuta kaikkien sarakkeiden kokoa</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>Muuta kokoa</translation>
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation>Luodaanko API-avain? Tätä avainta voidaan käyttää qBittorrentin API-rajapinnan käyttämiseen.</translation>
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation>Poistetaanko tämä API-avain? Nykyinen avain lakkaa välittömästi toimimasta.</translation>
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation>Kierrätetäänkö tämä API-avain? Nykyinen avain lakkaa välittömästi toimimasta, ja uusi avain luodaan.</translation>
    </message>
</context>
</TS>