<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">Névjegy</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Kategória:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Torrent indítása</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Hash ellenőrzés kihagyása</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Torrentkezelési mód:</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>Tartalom elrendezés:</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Eredeti</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Almappa létrehozása</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Ne hozzon létre almappát</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Kézi</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatikus</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metaadat fogadva</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Fájlok ellenőrizve</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>Stop feltétel:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nincs</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Hozzáadás a várólista elejére</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Letöltés egymás utáni sorrendben</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Méret:</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>Mentés helye</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Torrent információk</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Mentési útvonal:</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>Info hash v1:</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Torrent átnevezése</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation>Torrent hozzáadása</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>Nem elérhető</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorítás</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Magas</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Torrent beállítások</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normál</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Fájlok mentési helye:</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>Beállítás alapértelmezett kategóriának</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Feltöltési sebesség korlátozása</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Fájlok szűrése...</translation>
    </message>
    <message>
        <source>Add Torrent</source>
        <translation type="vanished">Torrent Hozzáadása</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>Használjon másik elérési utat a befejezetlen torrenthez</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Dátum:</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation>Mentés .torrent fájlként</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Összes</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maximális</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Ne töltse le</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Első és utolsó szelet letöltése először</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Megjegyzés:</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation>Torrent fájl letöltése sikertelen</translation>
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>Info hash v2:</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>Címkék:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Fájlok</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Letöltési sebesség korlátozása</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Összes</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Nem kategorizált</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Kategória hozzáadása…</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Kategória eltávolítása</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Nem használt kategóriák eltávolítása</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Új kategória</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Kategória szerkesztése…</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Torrentek eltávolítása</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>Alkategória hozzáadása…</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Torrentek indítása</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Torrentek leállítása</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>qBittorrent bezárása</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Globális feltöltési sebességkorlátnak 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Globális letöltési sebeségkorlátnak 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Alternatív feltöltési sebességkorlátnak 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Alternatív letöltési sebességkorlátnak 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Maximum aktív letöltéseknek nagyobbnak kell lennie, mint -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Maximum aktív feltöltéseknek nagyobbnak kell lennie, mint -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Maximum aktív torrenteknek nagyobbnak kell lennie, mint -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Maximális kapcsolatok számának 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximális kapcsolatok számának torrentenként 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Maximális feltöltési szálak korlátnak torrentenként 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Ismeretlen</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Alkalmaz</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Hozzáad</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>További információ</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Információk a tanúsítványokról</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Hely megadása</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Hétfő</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Kedd</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Szerda</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Csütörtök</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Péntek</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Szombat</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Vasárnap</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Kijelentkezés</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Mentés</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorent kliens nem elérhető</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>Globális feltöltési szálak korlátnak 0-nál nagyobbnak, vagy kikapcsoltnak kell lennie.</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>Érvénytelen kategórianév:\nNe használjon különleges karaktereket a kategórianévben.</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>Feltöltési sebességnek nagyobbnak kell lennie, mint 0.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Szerkesztés</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Szabad lemezterület: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>Torrent inaktivitás időzítőjének nagyobbnak kell lennie mint 0.</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>Mentéskezelés</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>A letöltési sebességkorlátnak nagyobbnak kell lennie, mint 0.</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>Dokumentáció megnyitása</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>Regisztrálja a magnet linkek kezeléséhez...</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>Nem sikerült peereket hozzáadni. Kérjük ellenőrizze, hogy megfelel-e az IP:port formátumnak</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>A név nem lehet üres</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>A név nem változott</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>A név frissítése nem sikerült</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>A bejövő kapcsolatokhoz használt portnak 0 és 65535 között kell lennie.</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>Eredeti szerző</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>Web UI-hoz használt portnak 1 és 65535 közé kell esnie.</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 leállítva</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript szükséges! A WebUI megfelelő működéséhez engedélyeznie kell a JavaScriptet.</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>Külső IP: N/A</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>Reverse proxy beállítási példák</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>Nem sikerült kapcsolatba lépni a qBittorrenttel</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Válasz megjegyzése</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>Biztosan eltávolítja a következő %1 torrentet az átviteli listából?</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>Torrentek törlése nem lehetséges.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>Külső IP: %1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>Web seed szerkesztése</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>Biztosan el szeretné távolítani a(z) %1 torrentet az átviteli listából?</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>Az automatikus torrent kezelés beállítása nem lehetséges a kiválasztott torrentekhez.</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>Torrentek megállítása nem lehetséges.</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>A fájl letöltése nem lehetséges.</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>Külső IP-k: %1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>A torrentek újraellenőrzése nem lehetséges.</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>Hozzáadandó web seedek listája (soronként egy):</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>Nem lehet elindítani a torrenteket.</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>Web seedek hozzáadása</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation>API kulcs törlése sikertelen.</translation>
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>A seedelési időkorlát nem lehet negatív érték.</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>A megosztási arány nem lehet negatív érték.</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation>Peer cserélődési időköznek 0-nál nagyobbnak vagy azzal egyenlőnek kell lennie.</translation>
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation>Nem sikerült feldolgozni a választ.</translation>
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation>Nem sikerült forgatni az API kulcsot.</translation>
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation>Peer cserélődési értéknek 0 és 100 közé kell esnie.</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation>Torrentek ellenőrzésekor a fennálló memória értékének 0 és 1024 között kell lennie.</translation>
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation>Nem sikerült betölteni a beállításokat. A qBittorrent valószínűleg nem elérhető.</translation>
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation>Peer cserélődési küszöbnek 0 és 100 között kell lennie.</translation>
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation>Peer DSCP-nek 0 és 255 közé kell esnie.</translation>
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation>Nem sikerült menteni a beállításokat, qBittorrent valószínűleg nem elérhető.</translation>
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation>Torrentek hozzáadása nem sikerült.</translation>
    </message>
    <message>
        <source>Error:</source>
        <translation>Hiba:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Szerkesztés</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Eszközök</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fájl</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Súgó</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Nézet</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Beállítások...</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Felső eszköztár</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Állapotsor</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Sebesség a címsoron</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Adományozz!</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Statisztika</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Névjegy</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Torrent fájl hozzáadása...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Dokumentáció</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Torrent link hozzáadása...</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nem</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Globális feltöltési sebesség korlát</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Globális letöltési sebességkorlát</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Biztosan ki akar lépni a qBittorrentből?</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternatív sebességkorlátok</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Keresőmotor</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>Torrent lista szűrése...</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Keresés</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Átvitelek</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>Mozgatás feljebb a sorban</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>Mozgatás fentebb a sorban</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>Sor alja</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>Mozgatás a sor aljára</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>Sor teteje</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>Mozgatás lentebb a sorban</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>Mozgatás lejjebb a sorban</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>Mozgatás a sor tetejére</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>A böngésződ nem támogatja ezt a funkciót</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>Ennek a szolgáltatásnak a használatához a WebUI-t HTTPS-en keresztül kell elérni</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>Kapcsolat állapota: Tűzfallal blokkolva</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>Kapcsolat állapota: Kapcsolódva</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>Alternatív sebességkorlátok: Kikapcsolva</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>Letöltési sebesség ikon</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>Alternatív sebességkorlátok: Bekapcsolva</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>Feltöltési sebesség ikon</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>Kapcsolat állapota: Szétkapcsolva</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS olvasó</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>Szűrők oldalsáv</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eltávolítás</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Napló</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Napló</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[L: %1, F: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>Szűrés erre:</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>Mentés helye</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Leállítás</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>Reguláris kifejezések használata</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>Szeretné elindítani az összes torrentet?</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>&amp;Sütik kezelése…</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Nem sikerült a torrent fájl exportálása</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>Szeretné leállítani az összes torrentet?</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>Összes indítása</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>Összes leállítása</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrent készítő</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation>Csatorna elemeinek szűrése...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Beállítások</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Letöltések</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Kapcsolat</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Sebesség</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>E-mail értesítés letöltés végeztével</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP-szűrés</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Alternatív sebességkorlátok ütemezése</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrent ütemezés</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Webes felhasználói felület (Távoli elérés)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>IP-cím:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Szerver domainek:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>HTTPS használata HTTP helyett</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Hitelesítés mellőzése a helyi gépen lévő klienseknél</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Hitelesítés mellőzése a fehérlistára tett IP alhálózatokban lévő klienseknél</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Dinamikus domain név frissítése</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Átmeneti fájlok helye:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>.torrent fájlok másolása ide:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Elkészült letöltések .torrent fájlainak másolása a következő helyre:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Minden fájl helyének lefoglalása előre</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>.!qB kiterjesztés használata félkész fájloknál</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Torrentek automatikus hozzáadása innen:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP-szerver:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Ez a szerver biztonságos kapcsolatot (SSL) igényel</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Hitelesítés</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Felhasználónév:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Jelszó:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP és μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Használt port</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port a bejövő kapcsolatokhoz:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>UPnP / NAT-PMP használata a portok átirányítására</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Kapcsolati korlátok</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Torrentenkénti kapcsolatok maximális száma:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Globális kapcsolatok maximális száma:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Torrentenkénti feltöltési szálak maximális száma:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Globális feltöltési szálak maximális száma:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Proxy szerver</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Típus:</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Kiszolgáló:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Proxy használata a peerkapcsolatokhoz</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Szűrő útvonala (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Kézzel tiltott IP-címek…</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Alkalmazás a trackerekre</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Globális sebességkorlátok</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Feltöltés:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Letöltés:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Alternatív sebességkorlátok</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Feladó:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Eddig:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Ekkor:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Minden nap</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Hétköznapokon</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Hétvégéken</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Sebességkorlátok beállítása</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Sebességkorlát alkalmazása a fejléc (overhead) többletre is.</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Sebességkorlát alkalmazása µTP protokollra is</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Magánszféra</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>DHT (decentralizált hálózat) engedélyezése, hogy több peert találjon</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Peercsere (PeX) engedélyezése, hogy több peert találjon</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Helyi peerek felkutatásának (LPD) engedélyezése, hogy több peert találjon</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Titkosítás módja:</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Titkosítás megkövetelése</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Titkosítás kikapcsolása</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Anonymous mód engedélyezése</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Aktív letöltések maximális száma:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Aktív feltöltések maximális száma:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Aktív torrentek maximális száma:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Lassú torrentek figyelmen kívül hagyása a korlátoknál</translation>
    </message>
    <message>
        <source>then</source>
        <translation>aztán</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>UPnP / NAT-PMP használata a portok átirányítására</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Tanúsítvány:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Kulcs:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Regisztráció</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Domain név:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Támogatott paraméterek (kis- és nagybetű érzékeny):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Torrent neve</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Kategória</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Tartalom útvonala (többfájlok torrenteknél ugyanaz mint a gyökér útvonal)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Gyökér útvonala (első torrent alkönyvtár útvonala)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Mentés útvonala</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Fájlok száma</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrent mérete (bájtok)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Jelenlegi tracker</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Tipp: Tegye a paramétereket idézőjelbe, hogy elkerülje azt, hogy az üres karaktereknél kettévágásra kerüljenek (például "%N")</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>perc</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>Kattintáseltérítés védelem engedélyezése</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Engedélyezze a kereszt webhely kérelem hamisítás védelmét (CSRF)</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>Utána törölje a .torrent fájlokat</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>Letöltési sebességkorlát:</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>Feltöltési sebességkorlát:</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>Jelenlegi jelszó megváltoztatása</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatikus</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>Alapértelmezett mentési útvonal:</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>Ne induljon el a letöltés automatikusan</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>Torrent kézi módba váltása</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>Amikor a torrent kategória megváltozik:</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>Érintett torrentek áthelyezése</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Sebességkorlát alkalmazása peerekre a LAN-on</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 azt jelenti, hogy korlátlan</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>Torrent áthelyezése</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>Amikor az alapértelmezett mentési útvonal megváltozik:</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>Kiszolgáló fejléc érvényesítés engedélyezése</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Biztonság</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>Ha a kategória mentési útja megváltozott:</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>másodperc</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Érintett torrentek kézi módba váltása</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>Fájlok helye:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Kézi</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Torrent inaktivitási időzítő:</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>Alapértelmezett torrentkezelési mód:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Torrent hozzáadásakor</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>μTP-TCP kevert-mód algoritmus:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>Feltöltési sebesség alapján</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Címkék (vesszővel elválasztva)</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Szoftvercsatorna várósor méret:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Super seed engedélyezése a torrentnek</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>TCP előnyben részesítése</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>Torrent ellenőrzéskor kiemelt memória mérete</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>Anti-leech</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>Amikor az arányt eléri</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>Több kapcsolat engedélyezése ugyanarról az IP-címről</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>Fájlkészlet mérete</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>Bármely csatoló</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>Mindig jelentsen az összes szintnek</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>Beépített tracker portja:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>Leggyorsabb feltöltés</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>Torrent és fájljai eltávolítása</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>qBittorrent beállítások</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>Buffer watermark factor küldése</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>libtorrent beállítások</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>Torrentek újraellenőrzése a letöltésük végeztével:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>Titkosítás engedélyezése</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>Feltöltési darab javaslatok küldése:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>Beépített tracker bekapcsolása:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Torrent eltávolítása</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>Aszinkron I/O szálak:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>Buffer watermark küldése:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Peer arányos (TCP-t visszafogja)</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>Rögzített szálak</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Speciális beállítások</translation>
    </message>
    <message>
        <source>min</source>
        <translation>perc</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>Feltöltéskorlátozási algoritmus</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>Seedelési korlátok</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>Körmérkőzés</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>Feltöltési szálak működése:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>Buffer low watermark küldése:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>Folytatási adatfájl mentésének intervalluma:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>Mindig jelentsen az egy szinten lévő összes tracker felé:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>Munkamenet időtúllépés:</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>Peer országának megjelenítése:</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>tiltás:</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>Kliens tiltása egymást követő hibák után:</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Fejléc : értékpárok, soronként egy</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>Egyéni HTTP fejlécek hozzáadása</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>Szűrők:</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>RSS csatornák lekérdezésének engedélyezése</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>Peer cserélődési küszöb százalék:</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Automata RSS torrent letöltő</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>Hálózati csatoló:</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS olvasó</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>Automatikus letöltési szabályok szerkesztése…</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>REPACK/PROPER epizódok letöltése</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>Csatornák frissítési időköze:</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>Peer cserélődési lekapcsolási százalék:</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Csatornánkénti elemek maximum száma:</translation>
    </message>
    <message>
        <source> min</source>
        <translation>perc</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>Peer cserélődési lekapcsolási intervallum:</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>Választható IP-cím, amelyhez az alkalmazás kötődjön:</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>Tiltsa le a kapcsolatot az peerek felé a kiváltságos portokon:</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Az RSS torrentek automatikus letöltésének engedélyezése</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>RSS okos epizód szűrő</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>Érvényesítse a HTTPS tracker tanúsítványokat</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>Peer kapcsolati protokoll:</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Torrent tartalom elrendezése:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Almappa létrehozása</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Eredeti</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Ne hozzon létre almappát</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>Másodpercenkénti kimenő kapcsolatok:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Véletlenszerű</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: Torrent azonosító</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>Újrajelentés az összes tracker felé ha változik az IP vagy port:</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>Megbízható proxyk listája:</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>Engedélyezze a fordított proxy támogatását</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J: Info hash v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: Info hash v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>A trackerek felé jelentett IP-cím (újraindítást igényel):</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Állítsa 0-ra, hogy a rendszer válasszon egy nem használt portot</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>Védekezés a szerver-oldali kéréshamisítás (SSRF) ellen:</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>Lemez sorbanállás mérete:</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>Teljesítmény figyelmeztetések naplózása</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>Maximális függőben lévő kérések egyetlen peerhez:</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>Torrentek aktív ellenőrzésének maximális száma:</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>Memóriában lefoglalt fájlok</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Alapértelmezett</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>POSIX-kompatibilis</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>Ez szabályozza a belső állapotfrissítési időközt, ami viszont hatással lesz a felhasználói felület frissítéseire</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>Lemez IO olvasási mód:</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>Operációs rendszer gyorsítótár letiltása</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>Lemez IO írási mód:</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>Szeletméret-affinitás használata:</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>Maximális egyidejű HTTP bejelentés:</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>Operációs rendszer gyorsítótár engedélyezés</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>Frissítési időköz:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>Kizárt fájlnevek</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>Nemzetköziesített domain nevek (IDN) támogatása:</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>Fehérlista a HTTP Kiszolgáló fejléc értékek szűrésére.
A DNS újrakötési támadások ellen,
írja be a WebUI szerver domain neveit.

Használja a ';' karaktert az elválasztásra, ha több is van. A '*' helyettesítő karakter is használható.</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>A HTTPS-tanúsítvány mezője nem lehet üres</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>Adjon meg fordított proxy IP-címeket (vagy alhálózatokat, pl. 0.0.0.0/24) továbbított kliens cím használatához (X-Forwarded-For fejléc). Használja a ';' karaktert a felosztáshoz, ha több bejegyzést ad meg.</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>A HTTPS-kulcs nem lehet üres</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>Külső program futtatása</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Fájlok ellenőrizve</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>Porttovábbítás a beépített tracker számára:</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>Ha be van jelölve, a kiszolgáló nevek proxyn keresztül lesznek feloldva.</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metaadat fogadva</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Torrent stop feltétel:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nincs</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Példa: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>SQLite adatbázis (kísérleti)</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>Folytatási-adat tároló típusa (újraindítást igényel)</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>Gyors-folytatás fájlok</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>Naplófájl biztonsági mentése ennyi után:</translation>
    </message>
    <message>
        <source>days</source>
        <translation>nap</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Működés</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>Naplófájlok biztonsági mentéseinek törlése ennyi után:</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>Proxy használata BitTorrent célokra</translation>
    </message>
    <message>
        <source>years</source>
        <translation>év</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Mentési útvonal:</translation>
    </message>
    <message>
        <source>months</source>
        <translation>hónap</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>Multi-Átnevezési beállítások megjegyzése</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>Proxy általános célokra történő használata</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>Proxy használata RSS célokra</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>Socket küldő puffer mérete [0: rendszer alapértelmezett]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>Kimenő portok (Max) [0: kikapcsolva]:</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>Socket fogadó puffer mérete [0: rendszer alapértelmezett]</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Hozzáadás a várólista elejére</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>Stop tracker időtúllépés [0: kikapcsolva]</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>Kimenő portok (Min) [0: kikapcsolva]:</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>UPnP bérlés időtartama [0: állandó bérlés]:</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Bdecode mélység korlát:</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Bdecode token korlát:</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>Amikor a teljes seed időt eléri</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Nincs)</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Python útvonala (újraindítást igényelhet):</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>Alapértelmezettre visszaáll ha üres</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>Kiszolgálónév lekérdezése proxyn keresztül</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>Ha a &amp;quot;kevert mód&amp;quot; engedélyezett, az I2P torrenteknek is megengedett, hogy partnereket szerezzenek a trackeren kívüli forrásokból is, és rendes IP-címekhez csatlakozzanak, anonimizálást nem biztosítva. Ez hasznos lehet, ha a felhasználó nem érdekelt az I2P anonimizálásában, de mégis szeretne I2P partnerekhez csatlakozni.</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>DHT bootstrap csomópontok:</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>Amikor az inaktív seed időt eléri</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>Kevert mód</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>.torrent fájl méret korlát:</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>(Auto felismerés ha üres)</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>Tartsa a nem kiválasztott fájlokat ".unwanted" mappában</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>Engedélyezze a Mark-of-the-Web (MOTW) használatát letöltött fájlokhoz (macOS vagy Windows szükséges):</translation>
    </message>
    <message>
        <source> sec</source>
        <translation>mp</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>I2P kimenő mennyiség:</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>I2P bejövő mennyiség:</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>Hash ellenőrző szálak:</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>Fizikai memória (RAM) használati korlát:</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>Alternatív WebUI használata</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>Merevlemez gyorsítótár lejáratának ideje:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>I2P kimenő hossza:</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P (kísérleti)</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>Lemez IO típusa (újraindítást igényel):</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>Az alternatív WebUI-fájlok helye nem lehet üres.</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>Lemez gyorsítótár:</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>Write-through</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>WebUI</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>A WebUI jelszónak legalább 6 karakter hosszúnak kell lennie.</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>Olvasások és írások egyesítése:</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>I2P bejövő hossza:</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>A WebUI felhasználónévnek legalább 3 karakter hosszúnak kell lennie.</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>Ugyanazon kiszolgáló-kérés késleltetése:</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>Alkalmazáspéldány nevének testreszabása:</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>Színséma:</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>Külső IP megjelenítése az állapotsoron</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>Lekért trackerek</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>Torrentek törlésének megerősítése</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>SSL hibák figyelmen kívül hagyása:</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Sötét</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>Fájlok végleges törlése</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>Váltakozó sorszínezés használata</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>A teljes bejelentési URL megjelenítése a Tracker oszlopban</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>Átviteli lista</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>A bejelentési portnak 0 és 65535 között kell lennie.</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Világos</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>Ezen trackerek automatikus hozzáadása az új letöltésekhez:</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Letöltés alatt lévő torrenteknél:</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>Torrent elindítása / leállítása</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>Teszt email küldése</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Letöltött torrenteknél:</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>A Secure jelző engedélyezése a sütiknél (HTTPS vagy helyi kapcsolat szükséges)</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Művelet dupla-kattintás esetén</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>Statisztika mentési intervallum:</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Torrent törlésekor megerősítő párbeszédpanel megjelenítése</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>Futtatás torrent befejezésekor:</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>Email küldés megkísérelve. Ellenőrizze a megadott email fiókot a sikeres küldés megerősítéséhez.</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>Az URL-en található trackerek automatikus hozzáadása az új letöltésekhez:</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Torrent tartalom eltávolítási mód:</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>Fájlok áthelyezése a kukába (ha lehetséges)</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Torrent leállítása</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>Használja a kategória elérési útjait kézi módban</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>Alternatív WebUI-k listája</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>Futtatás torrent hozzáadásakor:</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>Trackerek felé jelentett port (újraindítást igényel) [0: használt port]</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>Felhasználói felület nyelve:</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>Trackerek egyesítése meglévő torrenthez</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation>Torrent újraellenőrzés megerősítése:</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>Egyéni WebUI beállítások</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>A következő beállítások csak WebUI-ra vonatkoznak</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>Simple pread/pwrite</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Oldja fel a relatív mentési útvonalat a megfelelő kategória elérési útjával az alapértelmezett helyett</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Nincs művelet</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>Üres szűrők automatikus elrejtése</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Felület</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>Napló Fájlok</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>Optimalizált táblázatmegjelenítés engedélyezése (kísérleti)</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>Megjegyzés: A jelszó titkosítás nélkül kerül elmentésre</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>Belső hosztnév-feloldó gyorsítótárának lejárati intervalluma</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>mp</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation>API kulcs forgatása</translation>
    </message>
    <message>
        <source>Generate a key</source>
        <translation>Kulcs generálása</translation>
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation>Már létező torrent hozzáadásakor</translation>
    </message>
    <message>
        <source>Delete API key</source>
        <translation>API Kulcs törlése</translation>
    </message>
    <message>
        <source>%M: Comment</source>
        <translation>%M: Megjegyzés</translation>
    </message>
    <message>
        <source>Generate API key</source>
        <translation>API kulcs generálása</translation>
    </message>
    <message>
        <source>Copied</source>
        <translation>Másolva</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Felhasználó</translation>
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation>Szűrőválasztás visszaállítása</translation>
    </message>
    <message>
        <source>API Key</source>
        <translation>API Kulcs</translation>
    </message>
    <message>
        <source>Copy API key</source>
        <translation>API kulcs másolása</translation>
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation>Differentiated Services Code Point (DSCP) a peerekhez való kapcsolatokhoz</translation>
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation>A WebUI felhasználónév nem tartalmazhat kettőspontot.</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>Dátum formátum:</translation>
    </message>
    <message>
        <source>Browser default</source>
        <translation>Böngésző alapértelmezett</translation>
    </message>
    <message>
        <source>Localization</source>
        <translation>Nyelvi beállítások</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>Kompakt</translation>
    </message>
    <message>
        <source>Display density:</source>
        <translation>Megjelenítési sűrűség:</translation>
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation>A qBittorent példányok megkülönböztetésének megkönnyítése érdekében a szöveget az ablak címéhez csatolja</translation>
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation>Peer kiszolgálónevek feloldása:</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Jelzők</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Kapcsolat</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Kliens</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Folyamat</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Letöltési sebesség</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Feltöltési sebesség</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Letöltve</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Feltöltve</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Relevancia</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Fájlok</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Peer kitiltása végleg</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Biztos vagy benne, hogy végleg letiltod a kiválasztott peereket?</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>IP:port másolása</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>Ország/régió</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>Peerek hozzáadása...</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>Peer ID Kliens</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>IP/Cím</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Átlagos</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Magas</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maximális</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Kevert</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Ne töltse le</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Általános</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackerek</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peerek</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP Források</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Tartalom</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Letöltve:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Átvitel</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aktív idő:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Várható befejezési idő:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Feltöltve:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Seedek:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Letöltési sebesség:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Feltöltési sebesség:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Peerek:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Letöltési korlát:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Feltöltési korlát:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Elpazarolva:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Kapcsolatok:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Információ</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Megjegyzés:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Megosztási arány:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Újrajelentés:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Legutóbb befejezettként látva:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Teljes méret:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Szeletek:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Létrehozta:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Hozzáadva:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Elkészült ekkor:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Készítés ideje:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Mentés útvonala:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Soha</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (van %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 ez a munkamenet)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 maximum)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 összesen)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (átlag %2)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorítás</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Fájlok szűrése...</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Átnevezés...</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (seedelve %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>Info Hash v2:</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>Info Hash v1:</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Folyamat:</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Reguláris kifejezések használata</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Fájlnév</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>Fájlnév + Kiterjesztés</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>Fájlok felsorolása</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>Átnevezés sikertelen: a fájl vagy mappa már létezik</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>Kijelölés kapcsolása</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>Csere beviteli mező</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Csere</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>Kiterjesztés</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>Összes cseréje</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>Beleértve a fájlokat</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>Beleértve a mappákat</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>Fájlok keresése</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Nagy- és kisbetű érzékeny</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>Minden előfordulás egyezzen</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>Web seed URL másolása</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>Átnevezési opciók</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>Web seed URL szerkesztése...</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>Web seed URL:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>Arány / Aktív idő (hónapokban), jelzi, mennyire népszerű a torrent</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>Népszerűség:</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>Melyik fájlnévrészre alkalmazza</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nem</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>Web seed eltávolítása</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>Web seed szerkesztés</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>Web seedek hozzáadása...</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>Privát</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Elérhetőség:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Megfigyelt mappa</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Mentési hely felülírása</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Megfigyelt mappa</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Alapértelmezett mentési hely</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>Egyéb...</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Írja ide a könyvtár nevét</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Statisztika</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Felhasználói statisztikák</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Gyorsítótár statisztika</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Olvasási gyorsítótár találatok:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Átlagos idő a várakozási sorban:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>Kapcsolódott peerek:</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>Összesített megosztási arány:</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>Összesített letöltés:</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>Munkamenet selejtje:</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>Összesített feltöltés:</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>Teljes buffer méret:</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Teljesítmény statisztika</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Sorban várakozó I/O feladatok:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Írási gyorsítótár túlterheltsége:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Olvasási gyorsítótár túlterheltsége:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Összes sorban várakozó mérete:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 csomópont</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Összes (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Letöltés (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Seedelés (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Kész (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Aktív (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Inaktív (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Hibás (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Összes (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Letöltés (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Seedelés (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Kész (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Aktív (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Inaktív (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Hibás (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>Elakadt feltöltés (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>Elakadt letöltés (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>Elakadt letöltés (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>Elakadt (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>Elakadt feltöltés (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>Elakadt (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>Ellenőrzés (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>Ellenőrzés (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>Áthelyezés (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>Áthelyezés (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>Folyamatban (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>Megállítva (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>Megállítva (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>Folyamatban (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Torrentek eltávolítása</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Torrentek indítása</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Torrentek leállítása</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Név</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Méret</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Állapot</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seedek</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peerek</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Letöltési sebesség</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Feltöltési sebesség</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Arány</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Várható befejezési idő:</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategória</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Címkék</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Hozzáadva</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Elkészült ekkor</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Letöltés korlát</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Feltöltés korlát</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Letöltve</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Feltöltve</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Hátralévő</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Aktív idő</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Mentés útvonala</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Befejezett</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Arány korlát</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Legutóbb befejezettként látva</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Utolsó aktivitás</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Teljes méret</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Elérhetőség</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>Újrajelentés</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privát</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Folyamat</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>Info Hash v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>Info Hash v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>Befejezetlen mentés helye</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>Népszerűség</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Állapot ikon</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation>Munkamenet alatt feltöltve</translation>
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation>Munkamenet alatt letöltve</translation>
    </message>
    <message>
        <source>Created On</source>
        <translation>Létrehozva</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>Állapot</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Peerek</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Üzenet</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>Tracker URL:</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Frissítés...</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Működik</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Letiltva</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Még nem kapcsolódott</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>Seedek</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Nem működik</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>Tracker URL másolása</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>Tracker URL szerkesztése...</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>Tracker szerkesztés</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>Leechek</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Tracker eltávolítása</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Hátralévő</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Elérhetőség</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>Szint</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Letöltési prioritás</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Folyamat</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>Teljes méret</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>Letöltések száma</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>Trackerek hozzáadása...</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>Átnevezve</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Eredeti</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/Bejelentés végpont</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>BT Protokoll</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>Következő Bejelentés</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation>Szint:</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Tracker hiba</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>Elérhetetlen</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation>Kényszerített újrajelentés a kijelölt trackerek felé</translation>
    </message>
    <message>
        <source>Min Announce</source>
        <translation>Min Bejelentés</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>Kényszerített újrajelentés minden tracker felé</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Hozzáadandó trackerek listája (soronként egy):</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>Trackerek hozzáadása</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 ideje</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Befejezett</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>Áthelyezés</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[K] Seedelés</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>Seedelés</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Sorban áll</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[K] Letöltés</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>Metaadatok letöltése</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>Ellenőrzés</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>Hiányzó fájlok</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>Ellenőrzésre várakozik</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Letöltés</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>Folytatáshoz szükséges adatok ellenőrzése</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>Elakadt</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (seedelve %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[K] Metaadatok letöltése</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Megállítva</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Állapot</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Kategóriák</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Címkék</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackerek</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>Összecsuk/kinyit</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>Kategória összecsukása/kinyitása</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Torrent letöltés sebességkorlátozás</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Torrent feltöltés sebességkorlátozás</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Átnevezés</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Megosztási arány korlát...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Feltöltési sebesség korlátozása...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Letöltési sebesség korlátozása...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Feljebb mozgat</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Lejjebb mozgat</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Legfelülre mozgat</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Legalulra mozgat</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Hely megadása...</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Első és utolsó szelet letöltése először</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Automatikus torrentkezelés</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategória</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Új…</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Alaphelyzetbe állít</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Kényszerített újraellenőrzés</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Szuper seed üzemmód</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Átnevezés...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Letöltés egymás utáni sorrendben</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Új kategória</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Hely megadása</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Kényszerített újrajelentés</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>Kategória Szerkesztése</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>Vesszővel elválasztott címkék:</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Címkék</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnet link</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>Összes eltávolítása</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Másolás</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Sor</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Hozzáadás…</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>Info hash v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>Info hash v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>Torrent azonosító</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>.torrent fájl exportálása</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eltávolítás</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>Fájlok átnevezése...</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>Átnevezés</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Megjegyzés</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>Kényszerített indítás</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Hely:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Leállítás</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Az automatikus mód azt jelenti, hogy a különböző torrenttulajdonságok (pl. a mentési útvonal) a hozzátartozó kategória alapján kerülnek eldöntésre</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Új név:</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>Címkék hozzáadása</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation>Tartalom Útvonal</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Torrent fel/letöltés arány korlátozás</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Globális megosztási korlát használata</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Ne állítson be megosztási korlátot</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Megosztási korlát beállítása:</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>arány</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>összes perc</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>inaktív perc</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Alapértelmezett</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Torrent eltávolítása</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>Torrent és tartalmának eltávolítása</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Torrent leállítása</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Super seed engedélyezése a torrentnél</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation>Művelet ha a korlát elérésre kerül</translation>
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>Torrent(ek) eltávolítása</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>Tartalom fájlokat is távolítsa el</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Tracker eltávolítása</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Letöltés URL-ekből</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1ó %2p</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1nap %2ó</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Ismeretlen</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1perc</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1perc</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1 év %2 nap</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>Mentési útvonal üres</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>Bővítmény elérési útja:</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>URL vagy helyi könyvtár</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>Bővítmény telepítés</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>Seedek:</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>Minden bővítmény</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Méret:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Leállítás</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Keresés</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>Kereső bővítmények</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>Összes kategória</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>Keresés itt:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Szűrő</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>Csak torrentnevekben</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>Csak az engedélyezettek</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>/</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>Mindenhol</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>Növelje az ablak szélességét további szűrők megjelenítéséhez</translation>
    </message>
    <message>
        <source>to</source>
        <translation>eddig</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Találatok</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>megjelenítése</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>Az ablak jobb alsó sarkában található „Modulok keresése…” gomb megnyomásával telepíthet néhányat.</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>Nincsenek telepítve keresőbővítmények.</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>Kategória kiválasztása</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>Min méret prefix</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>Indítson keresést fent.</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>Max méret prefix</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>Bővítmények kiválasztása</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>Eltávolítás</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>Új bővítmény telepítése</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>Itt találhat új keresőmotor bővítményeket:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Bezárás</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>Telepített keresőbővítmények:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Engedélyezve</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Figyelmeztetés: Győződjön meg róla, hogy a keresőmotorok bármelyikéből származó torrentek letöltésekor betartja az ország szerzői jogi törvényeit.</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Frissítések ellenőrzése</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>Keresőbővítmények</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Méret</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>Leecherek</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>Seederek</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>Közzétéve</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>Motor URL</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>Motor</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Engedélyezve</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Verzió</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nem</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>Peerek hozzáadása</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>Hozzáadandó peerek listája (soronként egy):</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formátum: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>Új címke</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>Címke hozzáadása…</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>Címke:</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>Nem használt címkék eltávolítása</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>Érvénytelen címkenév</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>Címke eltávolítása</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Torrentek eltávolítása</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Torrentek indítása</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Torrentek leállítása</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>Összes</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>Címkézetlen</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Hibakövető:</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Névjegy</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Fórum:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>Jelenlegi karbantartó</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Weblap:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>Görögország</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>Külön köszönet</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Egy kifinomult, C++-ban fejlesztett BitTorrent kliens, Qt és libtorrent-rasterbar programkönyvtárakra alapozva.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Név:</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>A qBittorrent névjegye</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licenc</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>Fordítók</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>A qBittorrent a következő könyvtárak felhasználásával került kiadásra:</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>Nemzetiség:</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>Használatban lévő szoftver</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>A DB-IP ingyenes IP to Country Lite adatbázisát a peerek országának meghatározására használjuk. Az adatbázis Creative Commons Nevezd meg! 4.0 nemzetközi licenc alatt érhető el.</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Szerzők</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Franciaország</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>qBittorrent kabala</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>qBittorrent ikon</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>Összes cím</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>Összes IPv6-cím</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>Összes IPv4-cím</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>Másolás</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Letöltés</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>Adatlap URL</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>Adatlap megnyitása</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>Letöltési link</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>A keresés befejeződött</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>Hiba történt a keresés közben…</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>Fül bezárása</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Keresés…</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Keresés megszakítva</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>Az összes fül bezárása</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation>Fül frissítése</translation>
    </message>
    <message>
        <source>Open download window</source>
        <translation>Nyissa meg a letöltési ablakot</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation>Keresési szövegként való használat</translation>
    </message>
    <message>
        <source>Stop search</source>
        <translation>Keresés leállítása</translation>
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>Átnevezés</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Új név:</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>Dátum:</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Válasszon új nevet ehhez az RSS-csatornához</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Kérem válasszon egy mappanevet</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Új csatornanév:</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Összes frissítése</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Törlés</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS letöltő…</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Elemek olvasottnak jelölése</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Összes csatorna frissítése</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Csatorna URL másolása</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrentek: (dupla kattintás a letöltéshez)</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Hírek URL megnyitása</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Átnevezés...</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>Csatorna URL:</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Új mappa…</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Új feliratkozás</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Frissítés</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Mappanév:</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>Kérem írjon be egy RSS csatorna URL-t</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>Az RSS-hírcsatornák lekérése most le van tiltva! Az alkalmazás beállításaiban engedélyezheti.</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>Törlés megerősítése</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Biztos, hogy törli a kiválasztott RSS-csatornákat?</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Új feliratkozás…</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Torrent letöltése</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>Csatorna URL szerkesztése...</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>URL frissítése nem sikerült</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>URL változatlan</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>URL nem lehet üres</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>Link megnyitása</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Szerző:</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>Letöltési szabályok</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>Egyező RSS elemek</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* – nulla vagy több tetszőleges karakterre illeszkedik</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation>minden elemre illeszkedni fog.</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>Epizód szűrő szabályok:</translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Az RSS torrentek automata letöltése jelenleg tiltott. A beállításokban engedélyezheti ezt a funkciót.</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>Szabály meghatározása</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Mentés helye:</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>Reguláris kifejezések használata</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Új szabály neve</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>Szűrőnek pontosvesszővel kell végződnie</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? – egy tetszőleges karakterre illeszkedik</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>Epizód szűrő alapján társítja a találatokat.</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>Kategória megadása:</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regex mód: Perl-kompatibilis reguláris kifejezések használata</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>| a VAGY operátorként működik</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>Letöltött epizódok törlése</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Üres karakterek ÉS operátorként működnek (minden szó, bármilyen sorrendben)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>Egy üres %1 tagmondattal rendelkező kifejezés (pl. %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>Példa:</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Új szabály felvétele...</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Biztosan törölni szeretnéd a kiválasztott szabályhoz tartozó letöltött epizódokat?</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>Tartalmaznia kell:</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Korlátlan tartomány: &lt;b&gt;1x25-;&lt;/b&gt; az első évad 25. epizódjától kezdve minden rész, és minden epizód a későbbi évadokban</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>Külön könyvtárba mentés</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>Nem tartalmazhatja:</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Egy szám: &lt;b&gt;1x25;&lt;/b&gt; az első évad 25. epizódjának felel meg</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>Epizódok esetén három tartomány típus támogatott:</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Biztosan eltávolítod a kiválasztott szabályokat?</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>Globális beállítások használata</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Normál tartomány: &lt;b&gt;1x25-40;&lt;/b&gt; az első évad 25-40. epizódjának felel meg</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Kérlek add meg a szabály új nevét</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Szabály átnevezése</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Mindig</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>Az epizódszám egy kötelező pozitív érték</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation>az első évad 2., 5., 8.-15., és a 30.- részeire fog szűrni</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Szabály törlés megerősítése</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>Utolsó egyezés: %1 nappal ezelőtt</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>Epizód szűrő:</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>RSS Letöltő</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Évad szám egy kötelező nem-nulla érték</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Soha</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>Szabály alkalmazása a csatornákra:</translation>
    </message>
    <message>
        <source> days</source>
        <translation>nap</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>Okos epizódszűrő használata</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Ha a szósorrend fontos, akkor használjon *-ot üres karakter helyett</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Kérlek add meg az új letöltési szabály nevét.</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>Helyettesítő karakter mód: használható karakterek</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation>minden elemet ki fog hagyni.</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Szabály törlése</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>Ezt követő egyezések figyelmen kívül hagyása (0 a letiltáshoz)</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Szabály átnevezése...</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>Utolsó egyezés: Ismeretlen</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>Letöltött epizódok törlése…</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>Az intelligens epizódszűrő ellenőrzi az epizódszámot, hogy megakadályozza a másolatok letöltését.
Támogatja a formátumokat: S01E01, 1x1, 2017.12.31 és 31.12.2017. (A dátumformátumok is támogatják - elválasztóként)</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Torrent tartalom elrendezése:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Almappa létrehozása</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Eredeti</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Ne hozzon létre almappát</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>Címkék hozzáadása:</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>Szabály eltávolítása</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>Szabály hozzáadása</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>Hozzáad megállítva:</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation>Letöltött epizódok törlésének megerősítése</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>Torrentek eltávolítása</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Összes</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>Tracker nélküli</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Torrentek indítása</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Tracker eltávolítása</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Torrentek leállítása</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Tracker hiba</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation>Egyéb hiba</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS források</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Olvasatlan</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>Általános</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Tiltott</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Ismeretlen</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Összes</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>megjelenítve</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Másolás</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Összes kiválasztása</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Napló típusa</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Törlés</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>Információs üzenetek</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>Figyelmeztető üzenetek</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>Napló szűrése</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Tiltott IP címek</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>/</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Állapot</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>Időbélyeg</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>Összes törlése</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Üzenet</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>Naplózási szintek:</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Indok</translation>
    </message>
    <message>
        <source>item</source>
        <translation>elem</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>Kitiltva</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>Normál üzenetek</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>Kritikus</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>Kritikus üzenetek</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normál</translation>
    </message>
    <message>
        <source>items</source>
        <translation>elem</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Találatok</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>Válasszon naplózási szintet...</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>Biztos, hogy el akarja távolítani a "%1" trackert az összes torrentről?</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>Nem sikerült szerkeszteni a kategóriát</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>Kategória nem hozható létre</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>Nem sikerült a kategória beállítása</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>Mentési útvonal befejezetlen torrentekhez:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Alapértelmezett</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Új kategória</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Mentési útvonal:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Kategória:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nem</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Útvonal:</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>Használjon másik elérési utat a befejezetlen torrentekhez:</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation>Kategória nem létezik</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>Domain</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>Sütik kezelése</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>Cookie hozzáadása</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eltávolítás</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>Lejárati dátum</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Érték</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Név</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Útvonal</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>Automatikus torrentkezelés engedélyezése</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>Biztos benne, hogy engedélyezi az automatikus torrentkezelést a kiválasztott torrent(ek) számára? Lehetséges, hogy át lesznek helyezve.</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Biztos benne, hogy újraellenőrzi a kiválasztott torrenteket?</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>Újraellenőrzés megerősítése</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>Fül bezárása</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>qBittorrent WebUI</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Jelszó</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript szükséges! A WebUI megfelelő működéséhez engedélyeznie kell a JavaScriptet.</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Bejelentkezés</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>Szerver válasza:</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>Nem sikerült bejelentkezni, a szerver talán elérhetetlen.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Felhasználónév</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Érvénytelen felhasználónév vagy Jelszó.</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>Privát</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Forrás</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Sorban áll</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>Nem sikerült létrehozni a torrentet.</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>Privát
                torrent (nem jelenik meg a DHT hálózaton)</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Nem sikerült a torrent fájl exportálása</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>Új torrent létrehozása</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Megjegyzések:</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>Torrent letöltése</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Állapot ikon</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>Web seed URL-ek:</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Sikertelen</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Megjegyzés</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Befejezve</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Beállítások</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>Hiba üzenet</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Állapot</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>Igazítás szelet határhoz ennél nagyobb méretű fájlok
                esetén:</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>Válassza ki a megosztandó fájlt/mappát:</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>Szelet méret</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Folyamat</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>Elkészült ekkor</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>Hibrid</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>Nem sikerült betölteni a torrentlétrehozási feladatokat</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>Elrendezés
                    optimalizálása</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Tracker URL-ek:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>Biztos, hogy törli a kiválasztott feladatokat?</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Útvonal:</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>Torrent létrehozása</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>Elindítva ekkor</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Web seedek</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>Seedelés
                indítása
                azonnal</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formátum</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Torrent formátum:</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>Forrás útvonal</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>Hozzáadva</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>Folyamatban</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrent készítő</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>Forrás:</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackerek</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Szelet méret:</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Mezők</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>Feladat eltávolítása</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>Torrent exportálása</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">Letöltés</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnet link</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Torrent linkek hozzáadás</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Soronként egy link (HTTP linkek, mágnes linkek és az info hashek támogatottak)</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URLek</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>Torrent Linkek Hozzáadása</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation>Korlát:</translation>
    </message>
    <message>
        <source>Speed limit</source>
        <translation>Sebességkorlát</translation>
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>Feltöltési korlát:</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>Letöltési korlát:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation>Összes átméretezése</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>Átméretezés</translation>
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation>Generál egy API kulcsot? Ez a kulcs a qBittorrent API-val történő kommunikációra használható.</translation>
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation>Törli ezt az API kulcsot? A jelenlegi kulcs azonnal megszűnik működni.</translation>
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation>Forgatja ezt az API-kulcsot? A jelenlegi kulcs azonnal megszűnik működni, és egy új kulcs lesz generálva.</translation>
    </message>
</context>
</TS>