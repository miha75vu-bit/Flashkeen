<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nb">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">Om</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Start torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Hopp over sjekksummering</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Torrentbehandlingsmodus:</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>Innholdsoppsett:</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Opprinnelig</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Lag undermappe</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Ikke lag undermappe</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuell</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metadata mottatt</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Filer er kontrollert</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>Stopp-betingelse:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Legg øverst i køen</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Last ned i rekkefølge</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Størrelse:</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>Lagre i</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Informasjon om torrent</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Lagringssti:</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>Info-hash v1:</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Gi torrent nytt navn</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Not available</source>
        <translation>Ikke tilgjengelig</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Høy</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Torrentinnstillinger</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Lagre filer i mappe:</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>Bruk som forvalgt kategori</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Begrens opplastingshastighet</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrer filer …</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>Bruk en annen sti for ufullstendig torrent</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Dato:</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>I/T</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Maksimal</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Ikke last ned</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Last ned første og siste delene først</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>Info-hash v2:</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>Etiketter:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Filer</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Begrens nedlastingshastighet</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Ukategoriserte</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Legg til kategori …</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Fjern kategori</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Fjern ubrukte kategorier</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Rediger kategori …</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Fjern torrenter</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>Legg til underkategori …</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Start torrenter</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stopp torrenter</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Avslutt qBittorrent</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Global opplastingshastighetsgrense må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Global nedlastingshastighetsgrense må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativ opplastingshastighetsgrense må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativ nedlastingshastighetsgrense må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Maksimalt aktive nedlastinger må være større enn -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Maksimalt aktive opplastinger må være større enn -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Maksimalt aktive torrenter må være større enn -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Grensen for maksimalt antall tilkoblinger må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Grensen for maksimalt antall tilkoblinger per torrent må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Grensen for maksimalt antall opplastingsåpninger per torrent må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Mer informasjon</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Informasjon om sertifikater</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Velg plassering</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Mandag</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Tirsdag</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Onsdag</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Torsdag</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Fredag</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lørdag</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Søndag</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Logg ut</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent er ikke oppnåelig</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>Globalt antall opplastingsåpninger må være større enn 0 eller deaktivert.</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>Ugyldig kategorinavn:\nIkke bruk noen spesialtegn i kategorinavnet.</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>Opplastingsforholdsgrense må være større enn 0.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Ledig plass: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>Timer for Torrentaktivitet må være større enn 0.</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>Lagringsbehandling</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>Nedlastingsforholdsgrense må være større enn 0.</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>Åpne dokumentasjon</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>Registrer for å håndtere magnet-lenker …</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>Klarte ikke legge til likemenn. Sørg for at du bruker formatet «IP:port».</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>Navnet kan ikke være tomt</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>Navnet er uendret</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>Klarte ikke oppdatere navn</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>Porten som brukes for innkommende tilkoblinger må være mellom 0 og 65535.</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>Opprinnelig opphavsperson</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>Porten som brukes for nettgrensesnittet må være mellom 1 og 65535.</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 er avsluttet</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript kreves. Du må aktivere JavaScript for at nettgrensesnittet skal virke.</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>Ekstern IP: I/T</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>Eksempler på oppsett av reversert mellomtjener</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>Klarte ikke kontakte qBittorrent</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Husk valg</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>Er du sikker på at du vil fjerne disse %1 torrentene fra overføringslisten?</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>Klarte ikke slette torrenter.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>Nettadresse</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>Ekstern IP: %1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>Rediger nettdeler</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>Er du sikker på at du vil fjerne %1 fra overføringslisten?</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>Klarte ikke ta i bruk automatisk torrentbehandling for de valgte torrentene.</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>Klarte ikke stoppe torrenter.</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>Klarte ikke laste ned fil</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>Eksterne IP-er: %1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>Klarte ikke kontrollere torrenter.</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>Liste over nettdelere som skal legges til (én per linje):</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>Klarte ikke starte torrenter.</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>Legg til nettdelere</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>Delingstidsgrensen kan ikke være negativ.</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>Delingsforholdsgrense kan ikke være negativ.</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Error:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Verktøy</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Alternativer …</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Topp-verktøyslinje</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Statusfelt</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Hastighet i tittellinjen</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Doner!</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Statistikk</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Legg til torrentfil …</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Dokumentasjon</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Legg til torrentlenke …</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Global grense for opplastingshastighet</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Global grense for nedlastingshastighet</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Er du sikker på at du vil avslutte qBittorrent?</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternative hastighetsgrenser</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Søkemotor</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>Filtrer torrentliste …</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Overføringer</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>Flytt opp i køen</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>Flytt opp i køen</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>Nederst i køen</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>Flytt nederst i køen</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>Øverst i køen</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>Flytt ned i køen</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>Flytt ned i køen</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>Flytt øverst i køen</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>Nettleseren din støtter ikke denne funksjonen</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>Nettgrensesnittet må brukes over HTTPS for å kunne bruke denne funksjonen.</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>Tilkoblingsstatus: Bak brannmur</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>Tilkoblingsstatus: Tilkoblet</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>Alternative hastighetsgrenser: Av</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>Ikon for nedlastingshastighet</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>Alternative hastighetsgrenser: På</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>Ikon for opplastingshastighet</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>Tilkoblingsstatus: Frakoblet</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS-leser</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>Sidestolpe med filter</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Utførelseslogg</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Logg</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[D: %1, U: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>Filtrer etter:</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>Lagringssti</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>Bruk regulært uttrykk</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>Vil du starte alle torrenter?</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>Behandle informasjonskapsler …</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Klarte ikke eksportere torrentfil</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>Vil du stoppe alle torrenter?</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>Start alle</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>Stopp alle</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrentoppretter</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Alternativer</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Tilkobling</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Hastighet</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Epost-varsling ved nedlastingsfullførelse</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP-filtrering</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Planlegg bruken av alternative hastighetsgrenser</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrentkødanning</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Nettbrukergrenesnitt (fjernkontroll)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>IP-adresse:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Tjenerdomener:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Bruk HTTPS istedenfor HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Omgå autentisering for klienter på lokalvert</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Omgå autentisering for klienter i hvitlistede IP-subnett</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Oppdater mitt dynamiske domenenavn</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Behold ufullstendige torrenter i:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopier .torrent-filer til:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Kopier .torrent-filer for fullførte nedlastinger til:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Forhåndstildel diskplass for alle filer</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Tilføy .!qB benevnelse for ikke-fullførte filer</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Legg automatisk til torrenter fra:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP-tjener:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Denne tjeneren krever en sikker tilkobling (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Autentisering</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Brukernavn:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Passord:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP og μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Lytteport</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port brukt for innkommende tilkoblinger:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Bruk UPnP / NAT-PMP port-videresending fra min ruter</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Tilkoblingsgrenser</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maksimalt antall tilkoblinger per torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Globalt maksimumsantall for tilkoblinger:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maksimalt antall opplastingsåpninger per torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Globalt maksimumsantall for opplastingsåpninger:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Mellomtjener</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Vert:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Bruk mellomtjener for likemannstilkoblinger</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Filtermappe (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Manuelt bannlyste IP-adresser…</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Bruk for sporere</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Globale hastighetsgrenser</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Opplasting:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Nedlasting:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Alternative hastighetsgrenser</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Fra:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Til:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Når:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Hver dag</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Ukedager</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Helger</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Innstillinger for hastighetsgrenser</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Bruk hastighetsgrense for transportering av tilleggsdata</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Bruk hastighetsgrense for µTP-protokoll</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Personvern</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Aktiver DHT (desentralisert nettverk) for å finne flere likemenn</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Skru på likemennsutveksling (PeX) for å finne flere likemenn</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Aktiver lokal likemannsoppdaging for å finne flere likemenn</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Krypteringsmodus:</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Krev kryptering</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Deaktiver kryptering</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Aktiver anonymitetsmodus</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Maksimalt antall aktive nedlastinger:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Maksimalt antall aktive opplastinger:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Maksimalt antall aktive torrenter:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Ikke ta med trege torrenter i regnskapet for disse grensene</translation>
    </message>
    <message>
        <source>then</source>
        <translation>deretter</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Bruk UPnP / NAT-PMP for å videresende porten fra min ruter</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Sertifikat:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Nøkkel:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrer</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Domenenavn:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Støttede parametre (forskjell på små og store bokstaver):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Torrentnavn</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Kategori</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Innholdsmappe (samme som rotmappe for flerfilstorrenter)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Rotmappe (første undermappe for torrenter)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Lagringsmappe</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Antall filer</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrentstørrelse (Byte)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Nåværende sporer</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Tips: Innkapsle parameter med anførselstegn for å unngå at teksten blir avskåret ved mellomrom (f.eks., "%N")</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minutter</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>Aktiver beskyttelse mot klikkoverstyring</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Skru på «Cross-Site Request Forgery»-beskyttelse (CSRF)</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>Slett .torrentfiler etterpå</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>Nedlastingsforholdsgrense:</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>Opplastingsforholdsgrense:</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>Endre gjeldende passord</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>Forvalgt lagringsmappe:</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>Ikke start nedlastingen automatisk</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>Bytt torrent til manuell modus</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>Når torrentkategori endres:</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>Omplasser berørte torrenter</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Bruk hastighetsgrense for likemenn på lokalnett</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 betyr ubegrenset</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>Flytt torrent</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>Når forvalgt lagringsmappe endres:</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>Skru på validering av «Host»-feltet i hodet</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sikkerhet</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>Når kategoriens lagringssti endres:</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>sekunder</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Bytt berørte torrenter til manuell modus</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>Filenes plassering:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuell</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Torrent-inaktivitetsklokke:</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>Forvalgt torrentbehandlingsmodus:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Når en torrent legges til</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>Algoritme for sammenblandet uTP-TCP-modus:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>Opplastingsforholdsbasert</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Etiketter (adskilt med kommaer)</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Socket-køens størrelse:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Skru på superdeling av torrent</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>Foretrekk TCP</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>Grense for minnebruk ved sjekk av torrenter:</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>Anti-snylting</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>Når forholdet når</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>Tillat flere tilkoblinger fra samme IP-adresse:</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>Filforrådets størrelse:</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>Vilkårlig grensesnitt</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>Alltid annonsér til alle nivåer:</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>Innebygd sporerport:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>Raskeste opplasting</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>Fjern torrent og dens filer</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>qBittorrent-seksjon</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>Send mellomlagringsvannmerkefaktor:</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>libtorrent-seksjon</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>Gjennomsjekk torrenter på nytt ved fullførelse:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>Tillat kryptering</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>Send forslag om opplastingsdeler:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>Aktiver innebygd sporer:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Fjern torrent</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>Usynkrone I/O-tråder:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>Send mellomlagringsvannmerke:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Likemannsproporsjonalitet (Setter flaskehals på TCP)</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>Fastsatte plasser</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <source>min</source>
        <translation> min</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>Kvelningsalgoritme for opplastninger:</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>Delegrenser</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>Rundgang</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>Oppførsel for opplastingsplasser:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>Send lavt mellomlager-vannmerke:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>Intervall for lagring av gjenopptakelsesdata:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>Alltid annonsér til alle sporere på ett nivå:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>Tidsavbrudd for økt:</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>Finn fram til geografisk tilhørighet for likemenn:</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>bannlys i:</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>Bannlys klient etter påfølgende feil:</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Hode: verdipar, ett per linje</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>Legg til brukervalgte HTTP-hoder</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>Slå på innhenting av RSS-informasjonskanaler</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>Terskelprosent for utskiftning av likemenn:</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Automatisk nedlasting av RSS-informasjonskanaler</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>Nettverksgrensesnitt:</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS-leser</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>Rediger automatiske nedlastingsregler …</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Last ned REPACK-/PROPER-episoder</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>Oppdateringsintervall for nyhetsmatinger:</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>Frakoblingsprosent for utskiftning av likemenn:</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Maksimalt antall artikler per mating:</translation>
    </message>
    <message>
        <source> min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>Frakoblingsintervall for utskiftning av likemenn:</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>Valgfri IP-adresse å tilknytte seg:</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>Ikke tillat tilkobling til likemenn på priviligerte porter:</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Slå på automatisk nedlasting av RSS-torrenter</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>RSS-episodesmartfilter</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>Valider sertifikat til HTTPS-sporer:</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>Protokoll for tilkoblinger fra likemenn:</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Oppsett av innhold i torrent:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Lag undermappe</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Opprinnelig</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Ikke lag undermappe</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>Utgående tilkoblinger per sekund:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Tilfeldig</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: Torrent-ID</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>Reannonser til alle sporerne når IP eller port endres:</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>Liste over tiltrodde mellomtjenere:</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>Slå på støtte for reversert mellomtjener</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J: Info-hash v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: Info-hash v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>IP-adressen som skal rapporteres til sporere (krever omstart):</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Sett lik 0 for å la systemet velge en port som ikke brukes</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>Forebygging av forfalskede forespørsler på tjenersiden (SSRF):</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>Køstørrelse på disk:</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>Varsel om logg-ytelse</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>Største antall utestående forespørsler hos én likemann:</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>Største antall aktive kontroller av torrenter:</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>Minneavbildede filer</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Forvalgt</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>Iht. POSIX</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>Styrer internt oppdateringsintervall for status, som igjen påvirker oppdatering av brukergrensesnitt</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>Lesemodus for disk-I/U:</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>Slå av OS-hurtiglager</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>Lesemodus for disk-I/U:</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>La likemenn foretrekke nærliggende deler</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>Største antall samtidige HTTP-annonseringer:</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>Aktiver OS-hurtiglager</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>Oppdateringsintervall:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>Utelatte filnavn</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>Støtte for internasjonale domenenavn (IDN):</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>Hviteliste for filtrering av HTTP-vertshodeverdier.
For å kunne beskytte mot DNS-ombindingsangrep,
burde du skrive inn domenenavn brukt av vevgrensesnittjeneren.

Bruk ";" for å splitte flerfoldige oppføringer. Jokertegnet "*" kan brukes.</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>HTTPS-sertifikatet kan ikke være tomt</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>Angi IP-er til reverserte mellomtjenere (f.eks. 0.0.0.0/24 for subnett) for å bruke videresendte klientaddresser (attributtet X-Forwarded-For). Bruk «;» for å adskille flere oppføringer.</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>HTTPS-nøkkel kan ikke være tom</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>Kjør eksternt program</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Filer er kontrollert</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>Slå på portviderekobling for innebygd sporer:</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>Velg for å slå opp vertsnavn via mellomtjener.</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metadata mottatt</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Stopp-betingelse for torrent:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Eksempel: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>SQLite-database (eksperimentell)</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>Lagringstype for gjenopptakelse (krever omstart):</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>Filer for rask gjenopptakelse</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>Sikkerhetskopier loggfilen etter:</translation>
    </message>
    <message>
        <source>days</source>
        <translation>dager</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Oppførsel</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>Slett sikkerhetskopier av loggføringer som er eldre enn:</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>Bruk mellomtjener for BitTorrent-formål</translation>
    </message>
    <message>
        <source>years</source>
        <translation>år</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Lagringssti:</translation>
    </message>
    <message>
        <source>months</source>
        <translation>måneder</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>Husk oppsett av massiv navneendring</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>Bruk alltid mellomtjener</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>Bruk mellomtjener for informasjonskanaler (RSS)</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>Bufferstørrelse for sending over socket [0: systemets standardverdi]</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>Utgående porter (Maks) [0: Deaktivert]:</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>Bufferstørrelse for mottak over socket [0: systemets standardverdi]</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Legg øverst i køen</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>Tidsavbrudd for sporers stopp-hendelse [0: Deaktivert]</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>Utgående porter (Min) [0: Deaktivert]:</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>UPnP-adressens varighet [0: Fast adresse]:</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Dybdegrense for bdecode:</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Tokengrense for bdecode:</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>Når total delingstid når</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Ingen)</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Sti til python-fortolker (krever omstart):</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>Tilbakestill til standardverdi hvis tom</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>Slå opp vertsnavn via mellomtjener</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>Hvis &amp;quo;blandet modus&amp;quot; er slått på, så vil I2P-torrenter kunne få likemenn fra andre kilder enn sporeren og koble til vanlige IP-adresser uten anonymisering. Dette kan være nyttig hvis brukeren ikke er interessert i anonymisering, men likevel vil koble til I2P-likemenn.</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>Startnoder for DHT:</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>Når inaktiv delingstid når</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>Blandet modus</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>Grense for .torrent-filens størrelse:</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>(Gjenkjenn automatisk hvis tom)</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>Behold fravalgte filer i mappa «.unwanted»</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>Slå på MOTW (internett-markør) for nedlastede filer (krever macOS eller Windows):</translation>
    </message>
    <message>
        <source> sec</source>
        <translation>sek</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>I2P utgående mengde:</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>I2P inngående mengde:</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>Hasher tråder:</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>Grense for bruk av fysisk minne (RAM):</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>Bruk et alternativt nettgrensesnitt</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>Utløpsintervall for hurtiglager på disk:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>I2P utgående lengde:</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P (eksperimentell)</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>Type disk-IU (krever omstart):</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>Filplasseringen til det alternative nettgrensesnittet kan ikke være blank.</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>Disk-hurtiglager:</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>Skriv-gjennom</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>Nettgrensesnitt</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>Passordet for nettgrensesnittet må være minst 6 tegn.</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>Bland sammen lesinger og skrivinger:</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>I2P inngående lengde:</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>Brukernavn for nettgrensesnittet må være minst 3 tegn.</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>Forespørselsforsinkelse samme vert:</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>Tilpass instansnavn:</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>Palett:</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>Vis ekstern IP i statuslinja</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>Hentet sporere</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>Bekreft ved sletting av torrenter</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>Ignorer SSL-feil:</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Mørk</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>Slett filer for godt</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>Bruk alternerende radfarger</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>Vis full annonseringsadresse i sporer-kolonnen</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>Overføringsliste</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>Port for annonsering må være mellom 0 og 65535.</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Lys</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>Automatisk legg til disse sporerne til nye nedlastinger:</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Nedlastende torrenter:</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>Start / stopp torrent</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>Send test-epost</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Fullførte torrenter:</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>Slå på Secure-flagget i informasjonskapsler (krever HTTPS eller localhost-tilkobling)</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Handling ved dobbelklikk</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>Intervall for lagring av statistikk:</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Vis bekreftelsesdialog ved sletting av torrenter</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>Kjør når torrent er fullført:</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>Forsøkte å sende epost. Se i innboksen om det lyktes</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>Automatisk legg til disse sporerne fra adresse til nye nedlastinger:</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Modus for fjerning av torrentinnhold:</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>Flytt filer til papirkurven (hvis mulig)</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Stopp torrent</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>Bruk kategoristier i manuell modus</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>Liste over alternative nettgrensesnitt</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>Kjør når torrent legges til:</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>Porten som skal rapporteres til sporere (krever omstart) [0: lytteport]:</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>Brukergrensesnittets språk:</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>Slå sammen sporere til eksisterende torrent</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation>Bekreft ny gjennomsjekk av torrent:</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>Selvvalgte innstillinger for nettgrensesnitt</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>De følgende innstillingene gjelder kun nettgrensesnitt</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>Enkel pread/pwrite</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Slå opp relativ lagringssti mot passende kategoristi i stedet for den forvalge</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Ingen handling</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>Skjul automatisk filtre som mangler status</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Grensesnitt</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>Loggfiler</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>Slå på optimert tabellopptegning (eksperimentell)</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>Merk: Passordet er lagret ukryptert</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>Utløpsintervall til hurtiglageret for oppslag av internt vertsnavn</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>sek</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Generate a key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%M: Comment</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Generate API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copied</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>API Key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Copy API key</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Date format:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Browser default</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Localization</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Compact</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Display density:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Flagg</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Tilkobling</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Framdrift</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Ned-hastighet</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Opp-hastighet</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Nedlastet</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Opplastet</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Relevans</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Filer</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Bannlys likemann for godt</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Er du sikker på at du vil bannlyse permanent de valgte likemennene?</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>Kopier IP:port</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>Land/region</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>Legg til likemenn …</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>Likemanns-ID-klient</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>IP/Adresse</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Høy</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maksimal</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Blandet</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Ikke last ned</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Sporere</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Likemenn</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP-kilder</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Innhold</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Nedlastet:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Overføring</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Aktivitetstid:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Gjenværende tid:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Opplastet:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Delere:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Nedlastingshastighet:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Opplastingshastighet:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Likemenn:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Nedlastingsgrense:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Opplastingsgrense:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Ødslet:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Tilkoblinger:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Delingsforhold:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Reannonsering om:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Sist sett fullført:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Total størrelse:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Deler:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Opprettet av:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Lagt til:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Fullført:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Opprettet:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Lagringsmappe:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (har %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 denne økta)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 maks)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 totalt)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 gj.sn.)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrer filer …</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Gi nytt navn …</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (delt i %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>Info-hash v2:</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>Info-hash v1:</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>I/T</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Framdrift:</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Bruk regulære uttrykk</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Filnavn</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>Filnavn + filtype</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>Tell opp filer</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>Klarte ikke endre navn: Fil eller mappe finnes allerede</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>Veksle utvalg</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>Gi erstatning</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Erstatt</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>Filtype</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>Erstatt alle</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>Ta med filer</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>Ta med mapper</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>Søk filer</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Skill store/små bokstaver</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>Treff alle forekomster</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>Kopier adresse for nettdeler</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>Valg for erstatning</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>Rediger adresse for nettdeler …</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>Nettdeleradresse:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>Forhold / Tid aktiv (i måneder), antyder hvor populær torrenten er</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>Popularitet:</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>Bruk på hvilken del av filnavnet</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>Fjern nettdeler</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>Nettdeler-redigering</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>Legg til nettdelere …</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>Privat:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Tilgjengelighet:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Overvåket mappe</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Overstyr lagringsplassering</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Overvåket mappe</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Forvalgt lagringsplass</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>Annen …</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Velg mappe her</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Statistikk</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Brukerstatistikk</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Hurtiglager-statistikk</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Treff i lesehurtiglager:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Gjennomsnittlig tid i kø:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>Tilkoblede likemenn:</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>Totalt deleforhold:</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>Totalt nedlastet:</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>Økts-ødsling:</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>Totalt opplastet:</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>Total bufferstørrelse:</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Ytelesesstatistikk</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Inn- ut -jobber i kø:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Overlast i skrivingshurtiglager:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Overlast i lesingshurtiglager:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Total køstørrelse:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 noder</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Alle (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Laster ned (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Deler (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Fullførte (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Aktive (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Inaktive (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Feilede (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Alle (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Laster ned (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Deler (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Fullførte (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Aktive (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Inaktive (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Feilede (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>Laster ikke opp (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>Laster ikke ned (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>Laster ikke ned (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>Laster ikke ned (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>Laster ikke opp (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>Laster ikke ned (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>Kontrollerer (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>Kontrollerer (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>Flytter (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>Flytter (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>Kjører (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>Stoppet (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>Stoppet (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>Kjører (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Fjern torrenter</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Start torrenter</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stopp torrenter</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Størrelse</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Delere</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Likemenn</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Ned-hastighet</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Opp-hastighet</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Forhold</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Gjenværende tid</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiketter</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Lagt til</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Fullført</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Sporer</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Ned-grense</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Opp-grense</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Nedlastet</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Opplastet</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Gjenstående</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Aktivitetstid</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Lagringsmappe</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Fullført</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Forholdsgrense</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Sist sett i fullført tilstand</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Siste aktivitet</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Total størrelse</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Tilgjengelighet</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>Reannonsering om</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privat</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Framdrift</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>Info-hash v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>Info-hash v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>Ufullstendig lagringssti</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>Popularitet</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Statusikon</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Created On</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Likemenn</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Melding</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>Nettadresse til sporer:</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Oppdaterer …</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Virker</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktivert</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Ikke kontaktet ennå</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Irrelevant</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>Delere</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Virker ikke</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>Kopier sporerens nettadresse</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>Rediger sporerens nettadresse …</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>Sporer-redigering</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>Snyltere</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Fjern sporer</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Gjenstående</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Tilgjengelighet</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>Nivå</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Nedlastingsprioritet</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Framdrift</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>Total størrelse</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>Ganger nedlastet</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>Legg til sporere …</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>Endret navn</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/annonseringsendepunkt</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>BT-protokoll</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>Neste annonsering</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Sporerfeil</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>Kan ikke nås</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Min Announce</source>
        <translation>Minste annonsering</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>Tving reannonsering til alle sporerne</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Liste over sporere som skal legges til (én per linje):</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>Legg til sporere</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 siden</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Fullført</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>Flytter</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[F] Deler</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>Deler</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>I kø</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>Feilet</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[F] Laster ned</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>Laster ned metadata</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>Kontrollerer</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>Mangler filer</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>Plassert i kø for gjennomsjekking</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Laster ned</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>Sjekker gjennopptakingsdata</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>Laster ikke ned</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (delt i %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[F] Laster ned metadata</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Stoppet</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Irrelevant</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiketter</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Sporere</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>Fold sammen/ut</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>Fold sammen/ut kategori</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Hastighetsbegrensning for torrentnedlasting</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Hastighetsbegrensning for torrentopplasting</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Gi nytt navn</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Begrens delingsforhold …</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Begrens opplastingshastighet …</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Begrens nedlastingshastighet …</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Flytt oppover</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Flytt nedover</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Flytt til toppen</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Flytt til bunnen</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Velg plassering …</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Last ned de første og siste delene først</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Automatisk torrentbehandling</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Ny …</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Tilbakestill</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Påtving ny gjennomsjekk</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Superdelingsmodus</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Gi nytt navn …</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Last ned i rekkefølge</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Angi plassering</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Tving reannonsering</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>Rediger kategori</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>Kommaseparerte etiketter:</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiketter</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnetlenke</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>Fjern alle</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Kø</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Legg til …</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>Info-hash v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>Info-hash v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>Torrent-ID</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>Eksporter .torrent</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>Gi filer nytt navn …</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>Endrer navn</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>Tving start</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Plassering:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automatisk modus betyr at diverse torrent-egenskaper (f.eks. lagringsmappe) vil bli bestemt av tilknyttet kategori</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nytt navn:</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>Legg til etiketter</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Forholdsbegrensning for torrent-opp-/ned-lasting</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Bruk global delingsforholdsgrense</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Fri forholdsgrense</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Sett delingsgrense til</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>forhold</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>totalt antall minutter</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>antall inaktive minutter</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Forvalgt</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Fjern torrent</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>Fjern torrenten og innholdet</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Stopp torrent</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Skru på superdeling av torrent</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>Fjern torrent(er)</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>Også fjern filene i innholdet</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Fjern sporer</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Last ned fra nettadresser</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1t %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2t</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Ukjent</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1y %2d</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>Lagringsstien kan ikke være tom</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>Sti til programtillegg:</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>Nettadresse eller lokal mappe</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>Installer programtillegg</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>Delere:</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>Alle programtillegg</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>Søk i programtillegg …</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>Alle kategorier</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>Søk i:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>Kun torrentnavn</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>Kun aktiverte</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>av</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>Overalt</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>Øk vindusbredde for å vise flere filtre</translation>
    </message>
    <message>
        <source>to</source>
        <translation>til</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultater</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>viser</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>Klikk knappen «Søk etter programtillegg …» nederst til høyre i vinduet for å installere det.</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>Ingen søkeprogramtillegg installert.</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>Velg kategori</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>Min. størrelsesprefiks</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>Start et søk over.</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>Maks. størrelsesprefiks</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>Velg programtillegg</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>Avinstaller</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>Installer nytt programtillegg</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>Du kan hente nye søkemotor-programtillegg her:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>Installerte søketillegg:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktivert</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Advarsel: Sørg for å overholde ditt lands opphavsrettslovgivning når du laster ned torrenter fra noen av disse søkemotorene.</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Se etter oppdateringer</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>Søketillegg</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>Snyltere</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>Delere</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>Publisert den</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>Motoradresse</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>Motor:</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktivert</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versjon</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nei</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>Legg til likemenn</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>Liste over likemenn som skal legges til (Én IP per linje):</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>Ny etikett</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>Legg til etikett …</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>Etikett:</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>Fjern ubrukte etiketter</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>Ugyldig etikettnavn</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>Fjern etikett</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Fjern torrenter</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Start torrenter</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stopp torrenter</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>Umerket</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Feilsporer:</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Forum:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-post:</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>Nåværende vedlikeholder</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Hjemmeside:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>Hellas</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>Spesiell takk til</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>En avansert BitTorrent-klient programmert i C++, basert på Qt toolkit og libtorrent-rasterbar.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>Om qBittorrent</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Lisens</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>Oversettere</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent ble bygd med følgende biblioteker:</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>Nasjonalitet:</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>Programvare som er brukt</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>DB-IPs fritt tilgjengelige IP-til-land-database brukes for å slå opp likemennenes opphavsland. Denne databasen er lisensiert under Creative Commons Navngivelse 4.0 Internasjonal.</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Opphavspersoner</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Frankrike</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>qBittorrent-maskot</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>qBittorrent-ikon</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>Alle adresser</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>Alle IPv6-adresser</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>Alle IPv4-adresser</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Last ned</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>Adressen til beskrivelsessiden</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>Åpne beskrivelsesside</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>Nedlastingslenke</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Søket er ferdig</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>En feil oppstod under søket …</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>Lukk fane</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Søker …</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Søket ble avbrutt</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>Lukk alle faner</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open download window</source>
        <translation>Åpne nedlastingsvindu</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Stop search</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>Gir nytt navn</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nytt navn:</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>Dato:</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Velg et nytt navn for denne informasjonskanalen</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Velg et mappenavn</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nytt navn for informasjonskanal:</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Oppdater alle</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>Nedlasting av RSS …</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Marker elementer som lest</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Oppdater alle informasjonskanaler</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Kopier URL til informasjonskanal</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrenter: (dobbelklikk for å laste ned)</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Åpne nyhetsnettadresse</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Gi nytt navn …</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>URL til informasjonskanal:</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Ny mappe …</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nytt abonnement</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Oppdater</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Mappenavn:</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>Skriv inn informasjonskanalens nettadresse</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>Automatisk henting av RSS-informasjonskanaler er nå slått av. Du kan slå det på igjen i programinnstillingene.</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>Bekreft sletting</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Er du sikker på at du vil slette de valgte informasjonskanalene?</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nytt abonnement …</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Last ned torrent</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>Rediger informasjonskanalens adresse …</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>Klarte ikke oppdatere adresse</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>Adressen er uendret</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>Adressen kan ikke være tom</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>Åpne lenke</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Utvikler:</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>Nedlastingsregler</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>Samsvarende informasjonskanalartikler</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* for å samsvare med null eller flere av ethvert tegn</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation>vil samsvare med alle artikler.</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>Filtreringsregler for episoder:</translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Automatisk nedlasting av RSS-torrenter er nå slått av. Du kan slå det på igjen i programinnstillingene.</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>Regeldefinisjon</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Lagre til:</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>Bruk regulære uttrykk</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Navn på ny regel</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>Filtre må avsluttes med semikolon</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? for å samsvare med ethvert enkeltstående tegn</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>Samsvarende artikler i henhold til episodefilter.</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>Tilordne kategori:</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regex-modus: Bruk Perl-kompatible regulære uttrykk</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>| brukes som ELLER-operator</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>Fjern nedlastede episoder</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Blanktegn teller som OG-operatorer (alle ord, vilkårlig rekkefølge)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>Et uttrykk med et tomt %1-ledd (f.eks. %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>Eksempel:</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Legg til ny regel …</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Er du sikker på at du vil tømme lista over nedlastede episoder for den valgte regelen?</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>Må inneholde:</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Uendelig gruppering: &lt;b&gt;1x25-;&lt;/b&gt; samsvarer med episode 25 og utover i sesong én og alle episoder i senere sesonger</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>Lagre i annen mappe</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>Kan ikke inneholde:</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Enkeltnummer: &lt;b&gt;1x25;&lt;/b&gt; samsvarer med episode 25 av sesong én</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>Tre grupperingstyper for episoder er støttet: </translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Er du sikker på at du vil fjerne de valgte nedlastingsreglene?</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>Bruk globale innstillinger</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Normalgruppering: &lt;b&gt;1x25-40;&lt;/b&gt; samsvarer med episode 25 til og med 40 av sesong én</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Skriv inn nytt regelnavn</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Endre regelnavn</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>Episodenummeret er en påkrevd verdi som må være over null</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation>vil samsvare med 2, 5, de fra 8 til 15, 30, samt påfølgende episoder av sesong 1</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Bekreft sletting av regel</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>Siste treff: %1 dager siden</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>Episodefilter:</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>RSS-nedlasting</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Sesongnummeret er en påkrevd verdi som må være over null</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>Bruk regel på informasjonskanaler:</translation>
    </message>
    <message>
        <source> days</source>
        <translation>dager</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>Bruk episodesmartfilteret</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Bruk * i stedet for tomrom hvis ord-rekkefølgen er viktig.</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Skriv navnet på den nye nedlastingsregelen.</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>Joker-modus: Du kan bruke</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation>vil utelate alle artikler.</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Slett regel</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>Se bort fra påfølgende treff (0 for å slå av)</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Gi regel nytt navn …</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>Siste treff: Ukjent</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>Fjern nedlastede episoder …</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>Episodesmartfilteret vil sjekke episodenummereringen for å hindre nedlasting av duplikater.
Støtter de følgende formatene: S01E01, 1x1, 2017.12.31, og 31.12.2017 (Datoformater støtter også å bruke - som skilletegn)</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Oppsett av innhold i torrent:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Lag undermappe</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Opprinnelig</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Ikke lag undermappe</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>Legg til etiketter:</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>Fjern regel</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>Legg til regel</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>Legg til stoppet:</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>Fjern torrenter</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>Sporerløse</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Start torrenter</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Fjern sporer</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stopp torrenter</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Sporerfeil</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>Informasjonskanaler</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Ulest</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Blokkert</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>viser</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Velg alle</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Loggtype</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>Informasjonsmeldinger</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>Advarselsmeldinger</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>Filtrer logger</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Blokkerte IP-er</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>av</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>Tidsmerke</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>Fjern alle</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Melding</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>Loggnivåer:</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Årsak</translation>
    </message>
    <message>
        <source>item</source>
        <translation>element</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>Bannlyst</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>Normale meldinger</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>Kritisk</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>Kritiske meldinger</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>items</source>
        <translation>elementer</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultater</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>Velg loggnivå …</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>Er du sikker på at du vil fjerne sporeren %1 fra alle torrenter?</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>Kunne ikke redigere kategorien</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>Kunne ikke opprette kategorien</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>Klarte ikke lagre kategori</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>Lagre sti for ufullstendige torrenter:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Forvalgt</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Lagringssti:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Filsti:</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>Bruk en annen sti for ufullstendige torrenter:</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>Domene</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>Behandle Informasjonskapsler</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>Legg til informasjonskapsel</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>Utløpsdato</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>Slå på automatisk torrentbehandling</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>Vil du virkelig slå på automatisk torrentbehandling for valgt(e) torrent(er)? De kan bli flyttet.</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Er du sikker på at du vil sjekke valgte torrent(er) på nytt?</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>Bekreftelse av ny gjennomsjekking</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>Lukk fane</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>Nettgrensesnitt for qBittorrent</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript kreves. Du må aktivere JavaScript for at nettgrensesnittet skal virke.</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Logg inn</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>Tjenersvar:</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>Klarte ikke logge inn – tjeneren er antakelig utilgjengelig.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Ugyldig brukernavn eller passord.</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>Privat</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Kilde</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>I kø</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>Klarte ikke opprette torrent.</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>Privat
                torrent (vil ikke distribueres på DHT-nettverk)</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Klarte ikke eksportere torrentfil</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>Opprett ny torrent</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Kommentarer:</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>Last ned torrent</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Statusikon</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>Nettdeler-URLer:</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Mislyktes</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Fullført</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>Feilmelding</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>Juster til delgrense for filer større
                enn:</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>Velg en fil/mappe å dele:</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>Stykkestørrelse</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Framdrift</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>Fullført</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>Hybrid</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>Klarte ikke laste oppgaver for opprettelse av torrent</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>Optimaliser
                    justering</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Irrelevant</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Sporer-URLer:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>Er du sikker på at du vil slette de valgte oppgavene?</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Filsti:</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>Opprett torrent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>Startet den</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Nettdelere</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>Start
                deler
                umiddelbart</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Torrent-format:</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>Kildesti</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>Lagt til</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>Kjører</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrentoppretter</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>Kilde:</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Sporere</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Stykkestørrelse:</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Felter</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>Fjern oppgave</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>Eksporter torrent</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">Last ned</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnetlenke</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Legg til torrentlenker</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Én lenke per linje (HTTP-lenker, magnetlenker, og informative verifiseringsnøkler er støttet)</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>Legg til torrentlenke …</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Speed limit</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>Opplastingsgrense:</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>Nedlastingsgrense:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Resize</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>