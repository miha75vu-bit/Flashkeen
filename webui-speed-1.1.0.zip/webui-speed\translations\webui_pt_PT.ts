<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_PT">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">Sobre</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Ignorar verificação do hash</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Modo de gestão do torrent:</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>Disposição do conteúdo:</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Criar subpasta</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Não criar subpasta</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metadados recebidos</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Ficheiros verificados</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>Condição para parar:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Adicionar ao início da fila</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Transferir sequencialmente</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Tamanho:</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>Guardar em</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Informação do torrent</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Caminho de gravação:</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>Hash de informação v1:</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Mudar nome do torrent</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation>Adicionar torrent</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>Indisponível</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Definições do torrent</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Guardar ficheiros em:</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>Definir como categoria predefinida</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Limitar velocidade de upload</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrar ficheiros...</translation>
    </message>
    <message>
        <source>Add Torrent</source>
        <translation type="vanished">Adicionar torrent</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>Usar outro caminho para torrent incompleto</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation>Guardar como ficheiro .torrent</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Máximo</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Não transferir</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Transferir primeiro a primeira e a última peça</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation>Não foi possível transferir o ficheiro torrent</translation>
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>Hash de informação v2:</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>Etiquetas:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Ficheiros</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Limitar velocidade de download</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Sem categoria</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Adicionar categoria...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Remover categoria</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Remover categorias não utilizadas</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Nova categoria</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Editar categoria...</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Remover torrents</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>Adicionar sub-categoria...</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Sair do qBittorrent</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>O limite global da velocidade de upload tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>O limite global da velocidade de download tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>O limite alternativo da velocidade de upload tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>O limite alternativo da velocidade de download tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>O número máximo de transferências ativas tem de ser superior a -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>O número máximo de uploads ativos tem de ser superior a -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>O número máximo de torrents ativos tem de ser superior a -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>O número máximo do limite de ligações tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>O número máximo do limite de ligações por torrent tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>O limite máximo de slots de upload por torrent tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconhecido(a)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Mais informações</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Informação sobre certificados</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Definir localização</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Segunda-feira</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Terça-feira</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Quarta-feira</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Quinta-feira</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sexta-feira</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sábado</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Domingo</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Terminar sessão</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>O cliente qBittorrent encontra-se inacessível</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>O limite global de slots de upload tem de ser superior a 0 ou estar desativado.</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>Nome de categoria inválido:\nNão utilize caracteres especiais no nome da categoria.</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>O limiar da velocidade de upload tem de ser superior a 0.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Espaço livre: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>O tempo de inatividade do torrent deve ser superior a 0.</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>A guardar gestão</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>O limiar da velocidade de download tem de ser superior a 0.</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>Abrir documentação</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>Registar para gerir ligações magnet...</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>Não foi possível adicionar pares. Certifique-se de que está a utilizar o formato IP:port.</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>O nome não pode estar em branco</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>O nome não foi alterado</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>Ocorreu um erro ao atualizar o nome</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>A porta utilizada para as ligações recebidas tem de estar entre 0 e 65535.</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>A porta utilizada para a WebUI tem de estar entre 1 e 65535.</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 foi encerrado</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>É necessário JavaScript! Tem de ativar o JavaScript para que a WebUI funcione corretamente</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>IP externo: N/A</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>Exemplos de configuração de proxy reverso</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>Não foi possível contactar o qBittorrent</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Memorizar escolha</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>Tem a certeza de que pretende remover estes %1 torrents da lista de transferências?</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>Não foi possível eliminar os torrents.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>IP externo: %1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>Editar web seed</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>Tem a certeza de que pretende remover "%1" da lista de transferências?</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>Não foi possível definir a Gestão Automática de Torrents para os torrents selecionados.</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>Não foi possível parar os torrents.</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>Não foi possível transferir o ficheiro</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>IPs externos: %1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>Não foi possível reverificar os torrents.</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>Lista de web seeds a adicionar (uma por linha):</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>Não foi possível iniciar os torrents.</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>Adicionar web seeds</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation>Não foi possível eliminar a chave API.</translation>
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>O limite de tempo de partilha não pode ter um valor negativo.</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>O limite de rácio de partilha não pode ter um valor negativo.</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation>O intervalo de renovação de pares deve ser maior ou igual a 0.</translation>
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation>Não foi possível analisar a resposta.</translation>
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation>Não foi possível regenerar a chave API.</translation>
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation>A renovação de pares deve estar entre 0 e 100.</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation>A memória pendente ao verificar torrents tem de ser superior a 0 e inferior a 1024.</translation>
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation>Não foi possível carregar as preferências do programa. O qBittorrent poderá estar inacessível.</translation>
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation>O limite de renovação de pares deve estar entre 0 e 100.</translation>
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation>O DSCP dos pares deve estar entre 0 e 255.</translation>
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation>Não foi possível guardar as preferências. O qBittorrent poderá estar inacessível.</translation>
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation>Não foi possível adicionar os torrents.</translation>
    </message>
    <message>
        <source>Error:</source>
        <translation>Erro:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Ficheiro</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Opções...</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Barra superior</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Barra de estado</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Velocidade na barra de título</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Doar!</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Estatísticas</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Adicionar ficheiro torrent...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Documentação</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Adicionar ligação torrent...</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Limite global da velocidade para os uploads</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Limite global da velocidade para os downloads</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Tem a certeza que deseja sair do qBittorrent?</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Limites alternativos de velocidade</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Motor de pesquisa</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>Filtrar lista de torrents...</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Pesquisar</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Transferências</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>Mover acima na fila</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>Mover acima na fila</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>Fundo da fila</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>Mover para o fundo da fila</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>Topo da fila</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>Mover abaixo na fila</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>Mover abaixo na fila</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>Mover para o topo da fila</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>O seu browser não suporta esta funcionalidade</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>Para utilizar esta funcionalidade, a WebUI tem de ser acedida através de HTTPS</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>Estado da ligação: Com firewall</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>Estado da ligação: Ligado</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>Limites alternativos de velocidade: Desligados</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>Ícone da velocidade de download</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>Limites alternativos de velocidade: Ligados</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>Ícone da velocidade de upload</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>Estado da ligação: Desligado</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>Leitor de RSS</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>Barra lateral de filtros</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Registo de execução</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Registo</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[D: %1, U: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>Filtrar por:</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>Caminho de gravação</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>Usar expressão regular</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>Pretende iniciar todos os torrents?</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>Gerir cookies...</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Não foi possível exportar o ficheiro torrent</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>Pretende parar todos os torrents?</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>Iniciar todos</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>Parar todos</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Criador de torrents</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation>Filtrar itens do feed...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Transferências</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Ligação</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>Enviar notificação por e-mail ao terminar o download</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>Filtro de IP</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Agendar a utilização dos limites de velocidade alternativos</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Fila de torrents</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Interface web do utilizador (controlo remoto)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>Endereço IP:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Domínios do servidor:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Utilizar o HTTPS como alternativa ao HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Desativar a autenticação para clientes no localhost</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Desativar a autenticação para clientes pertencentes à lista de IPs confiáveis</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Atualizar o nome de domínio dinâmico</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Guardar os torrents incompletos em:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Copiar os ficheiros .torrent para:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar os ficheiros .torrent das transferências terminadas para:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pré-alocar espaço em disco para todos os ficheiros</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Adicionar a extensão .!qB aos ficheiros incompletos</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Adicionar automaticamente os torrents de:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Este servidor requer uma ligação segura (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Autenticação</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nome de utilizador:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Palavra-passe:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP e μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Porta de receção</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Porta utilizada para as ligações recebidas:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Utilizar o reencaminhamento de portas UPnP/NAT-PMP do meu router</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Limites das ligações</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Número máximo de ligações por torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Número máximo de ligações globais:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número máximo de slots de envio por torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Número máximo global de slots de envio:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Servidor:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Porta:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Utilizar proxy para ligações a pares</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Filtrar caminho (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Endereços de IP banidos manualmente...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Aplicar aos trackers</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Limites globais de velocidade</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Envio:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Transferência:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Limites alternativos de velocidade</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>De:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Para:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>Quando:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Diariamente</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Dias da semana</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Fins de semana</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Definições dos limites de velocidade</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar o limite de velocidade à sobrecarga do protocolo</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar os limites de velocidade ao protocolo µTP</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Privacidade</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Ativar DHT (rede descentralizada) para encontrar mais pares</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Ativar Peer Exchange (PeX) para encontrar mais pares</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Ativar descoberta de pares locais para encontrar mais pares</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Modo de encriptação:</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Requer encriptação</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Desativar encriptação</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Ativar o modo anónimo</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Nº máximo de transferências ativas:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Máximo de envios ativos:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Nº máximo de torrents ativos:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Não considerar os torrents lentos para estes limites</translation>
    </message>
    <message>
        <source>then</source>
        <translation>depois</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Utilizar o reencaminhamento de portas UPnP/NAT-PMP do meu router</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Chave:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registar</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Nome do domínio:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parâmetros suportados (sensível a maiúsculas/minúsculas):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Nome do torrent</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Categoria</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Caminho do conteúdo (igual ao caminho raiz para torrents de vários ficheiros)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Caminho raiz (caminho do primeiro subdiretório do torrent)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Caminho de gravação</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Número de ficheiros</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamanho do torrent (bytes)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker atual</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Dica: Encapsule o parâmetro entre aspas para evitar que sejam cortados os espaços em branco do texto (ex: "%N")</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>Ativar a proteção contra o "clickjacking"</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Ativar proteção contra falsificação de pedidos entre sites (CSRF)</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>Eliminar mais tarde os ficheiros .torrent</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>Limiar da velocidade de download:</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>Limiar da velocidade de upload:</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>Alterar a palavra-passe atual</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>Caminho de gravação predefinido:</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>Não iniciar a transferência automaticamente</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>Mudar o torrent para o 'Modo manual'</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>Quando a 'Categoria do torrent' for alterada:</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>Mover os torrents afetados</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar o limite de velocidade aos pares na LAN</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 significa ilimitado</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>Realocar torrent</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>Quando o caminho de gravação predefinido for alterado:</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>Ativar a validação do cabeçalho do Host</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Segurança</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>Quando o caminho de gravação da categoria for alterado:</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Mudar os torrents afetados para o 'Modo manual'</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>Localização dos ficheiros:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Temporizador de inatividade do torrent:</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>Modo de gestão do torrent por defeito:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>Ao adicionar um torrent</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>Algoritmo do modo de mistura uTP-TCP:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>Baseado na velocidade de upload</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Etiquetas (separadas por vírgula)</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Tamanho da lista pendente do socket:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Ativar super-seeding para o torrent</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>Preferir TCP</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>Memória pendente ao verificar torrents:</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>Anti-sanguessuga</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>Quando o rácio atingir</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>Permitir várias ligações a partir do mesmo endereço de IP:</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>Tamanho do pool de ficheiros:</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>Qualquer interface</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>Anunciar sempre para todas as filas:</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>Porta do tracker embutido:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>Upload mais rápido</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>Remover o torrent e os seus ficheiros</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>Secção qBittorrent</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>Fator da marca de água do buffer de envio:</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>Secção libtorrent</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>Verificar torrents ao terminar:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>Permitir encriptação</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>Enviar sugestões de peças para upload:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>Ativar tracker embutido:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Remover torrent</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>Threads assíncronas I/O:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>Marca de água do buffer de envio:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Proporcional aos pares (limita TCP)</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>Slots corrigidos</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <source>min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>Algoritmo choking do upload:</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>Limites de seed</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>Round-robin</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>Comportamento das slots de upload:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>Marca de água inferior do buffer de envio:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>Guardar o intervalo de dados do retomar:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>Anunciar sempre para todos os trackers numa fila:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>Terminado o tempo da sessão:</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>Resolver países dos pares:</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>banir durante:</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>Banir cliente depois de várias falhas consecutivas:</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Cabeçalho: pares de valores, um por linha</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>Adicionar cabeçalhos HTTP personalizados</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>Filtros:</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>Ativar obtenção de feeds RSS</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>Percentagem-limiar de rotatividade de pares:</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Transferidor automático de RSS Torrent</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>Interface de rede:</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>Leitor RSS</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>Editar regras da transferência automática...</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Transferir episódios REPACK/PROPER</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>Intervalo de atualização dos feeds:</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>Percentagem de desligamento por rotatividade de pares:</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artigos por feed:</translation>
    </message>
    <message>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>Intervalo de desligamento por rotatividade de pares:</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>Endereço IP opcional ao qual associar:</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>Não permitir ligação com pares em portas privilegiadas:</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Ativar a transferência automática de torrents RSS</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>Filtro inteligente de episódios RSS</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>Validar certificado HTTPS do tracker:</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>Protocolo de ligação de pares:</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Disposição do conteúdo do torrent:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Criar subpasta</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Não criar subpasta</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>Ligações de saída por segundo:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Aleatória</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: ID do torrent</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>Reanunciar para todos os trackers quando o IP ou porta forem alterados:</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>Lista de proxies confiáveis:</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>Ativar o suporte para proxy reverso</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J: Informação de hash v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: Informação de hash v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>Endereço IP comunicado aos trackers (requer reinício):</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Defina como 0 para permitir que o sistema escolha uma porta não utilizada</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>Mitigação de falsificação de pedidos do lado do servidor (SSRF):</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>Tamanho da fila do disco:</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>Registar avisos de desempenho</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>Máximo de pedidos pendentes a um único par:</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>Máximo de torrents ativos em verificação:</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>Ficheiros mapeados na memória</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predefinido</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>Compatível com POSIX</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>Controla o intervalo de atualização do estado interno que, por sua vez, afetará as atualizações da interface do utilizador</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>Modo de leitura de E/S do disco:</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>Desativar cache do sistema</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>Modo de gravação de E/S do disco:</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>Utilizar afinidade da extensão das peças:</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>Máximo de anúncios HTTP em simultâneo:</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>Ativar cache do sistema</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>Intervalo de atualização:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>Nomes de ficheiro excluídos</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>Suporte para nomes de domínio internacionalizados (IDN):</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>Lista branca para filtrar os valores do cabeçalho HTTP Host.
Para proteção contra ataques de DNS rebinding,
deve indicar os nomes de domínio utilizados pelo servidor da WebUI.

Utilize ';' para separar várias entradas. Pode utilizar o carácter universal '*'.</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>O certificado HTTPS não pode estar vazio</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>Especifique os IPs dos proxies reversos (ou sub-redes, ex.: 0.0.0.0/24) para utilizar o endereço do cliente encaminhado (cabeçalho X-Forwarded-For). Utilize ';' para separar várias entradas.</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>A chave HTTPS não pode estar vazia</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>Executar programa externo</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Ficheiros verificados</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>Ativar reencaminhamento de porta para o tracker incorporado:</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>Se estiver selecionado, as pesquisas de nomes de anfitrião são feitas através do proxy.</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Metadados recebidos</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Condição para parar torrent:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Exemplo: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>Base de dados SQLite (experimental)</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>Tipo de armazenamento de dados de retoma (necessário reiniciar):</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>Ficheiros de retoma rápida</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>Fazer cópia de segurança do ficheiro de registo após:</translation>
    </message>
    <message>
        <source>days</source>
        <translation>dias</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>Eliminar registos de cópias de segurança anteriores a:</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>Utilizar proxy para fins de BitTorrent</translation>
    </message>
    <message>
        <source>years</source>
        <translation>anos</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Guardar em:</translation>
    </message>
    <message>
        <source>months</source>
        <translation>meses</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>Memorizar definições de renomeação múltipla</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>Utilizar proxy para fins gerais</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>Utilizar proxy para fins de RSS</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>Tamanho do buffer do socket de envio [0: predefinição do sistema]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>Portas de saída (Máx) [0: desativado]:</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>Tamanho do buffer do socket de receção [0: predefinição do sistema]:</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Adicionar ao início da fila</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>Tempo limite para parar o tracker [0: desativado]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>Portas de saída (Mín) [0: desativado]:</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>Duração da concessão do UPnP [0: concessão permanente]:</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Limite de profundidade Bdecode:</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Limite do token Bdecode:</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>Quando o tempo total de seed atingir</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Nenhum(a))</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Caminho do executável Python (pode ser necessário reiniciar):</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>Repor o valor por defeito se estiver vazio</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>Efetuar pesquisa de nome de anfitrião através do proxy</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>Se o &amp;quot;modo misto&amp;quot; estiver ativado, os torrents I2P podem também obter pares de outras fontes que não o tracker e ligar-se a IPs normais, não fornecendo qualquer anonimização. Isso pode ser útil se o utilizador não estiver interessado na anonimização do I2P, mas ainda quiser se ligar a pares I2P.</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>Nós de arranque DHT:</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>Quando o tempo de seed inativo atingir</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>Modo misto</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>Limite de tamanho do ficheiro .torrent:</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>(Deteção automática se estiver vazio)</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>Manter ficheiros não selecionados na pasta ".unwanted"</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>Ativar Mark-of-the-Web (MOTW) para ficheiros transferidos (é necessário o macOS ou Windows):</translation>
    </message>
    <message>
        <source> sec</source>
        <translation> seg</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>Quantidade de saída I2P:</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>Quantidade de entrada I2P:</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>Threads de cálculo do hash:</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>Limite de utilização da memória física (RAM):</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>Utilizar WebUI alternativa</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>Intervalo de expiração da cache de disco:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>Comprimento de saída I2P:</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P (Experimental)</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>Tipo de E/S de disco (requer reinício):</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>O local alternativo dos ficheiros da interface web não pode estar em branco.</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>Cache do disco:</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>Write-through</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>Interface Web</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>A palavra-passe da interface web tem de ter pelo menos 6 caracteres.</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>Unir leituras e gravações:</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>Comprimento de entrada I2P:</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>O nome de utilizador da interface web deve ter pelo menos 3 caracteres.</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>Atraso de pedidos ao mesmo anfitrião:</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>Personalizar nome da instância da aplicação:</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>Esquema de cor:</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>Mostrar IP externo na barra de status</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>Trackers obtidos</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar eliminação de torrents</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>Ignorar erros SSL:</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Escuro</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>Eliminar ficheiros permanentemente</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>Utilizar cores alternadas para as linhas</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>Mostrar URL de anúncio completo na coluna Tracker</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>Lista de transferências</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>A porta de anúncio deve estar entre 0 e 65535.</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Claro</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>Adicionar automaticamente estes trackers às novas transferências:</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>A transferir torrents:</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>Iniciar / Parar torrent</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>Enviar e-mail de teste</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Torrents completos:</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>Ativar sinalizador de cookie seguro (requer ligação HTTPS ou localhost)</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Ação do duplo clique</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>Intervalo para gravar estatísticas:</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Exibe um diálogo de confirmação durante a eliminação de torrents</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>Executar ao concluir o torrent:</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>Tentativa de enviar e-mail. Verifique a sua caixa de entrada para confirmar</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>Adicionar automaticamente trackers a partir de URL às novas transferências:</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Modo de remoção de conteúdo do torrent:</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>Mover ficheiros para o lixo (se possível)</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Parar torrent</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>Utilizar os caminhos de 'Categoria' no 'Modo manual'</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>Lista de interface web alternativa</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>Executar ao adicionar o torrent:</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>Porta reportada aos trackers (necessário reiniciar) [0: porta de escuta]:</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>Idioma da interface do utilizador:</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>Unir trackers ao torrent existente</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation>Confirmar nova verificação do torrent:</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>Definições personalizadas da WebUI</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>As seguintes definições são apenas para a WebUI</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>Pread/pwrite simples</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Resolver o caminho de gravação relativo com base no caminho da categoria apropriada em vez do caminho predefinido</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Nenhuma ação</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>Ocultar filtro de estado zero</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>Ficheiros do registo</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>Ativar renderização de tabela otimizada (experimental)</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>Aviso: A palavra-passe é gravada sem encriptação</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>Intervalo de expiração do cache do resolvedor de nome de host interno</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>seg</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation>Regenerar chave API</translation>
    </message>
    <message>
        <source>Generate a key</source>
        <translation>Gerar uma chave</translation>
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation>Ao adicionar um torrent duplicado</translation>
    </message>
    <message>
        <source>Delete API key</source>
        <translation>Eliminar chave API</translation>
    </message>
    <message>
        <source>%M: Comment</source>
        <translation>%M: Comentário</translation>
    </message>
    <message>
        <source>Generate API key</source>
        <translation>Gerar chave API</translation>
    </message>
    <message>
        <source>Copied</source>
        <translation>Copiado</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Utilizador</translation>
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation>Repor seleção de filtros</translation>
    </message>
    <message>
        <source>API Key</source>
        <translation>Chave API</translation>
    </message>
    <message>
        <source>Copy API key</source>
        <translation>Copiar chave API</translation>
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation>Ponto de Código de Serviços Diferenciados (DSCP) para ligações a pares</translation>
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation>O nome de utilizador da WebUI não pode conter dois-pontos.</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>Formato da data:</translation>
    </message>
    <message>
        <source>Browser default</source>
        <translation>Predefinição do navegador</translation>
    </message>
    <message>
        <source>Localization</source>
        <translation>Localização</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>Compacta</translation>
    </message>
    <message>
        <source>Display density:</source>
        <translation>Densidade de apresentação:</translation>
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation>Acrescenta o texto ao título da janela para ajudar a distinguir instâncias do qBittorrent</translation>
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation>Resolver nomes de anfitrião dos pares:</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Bandeiras</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Ligação</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Evolução</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. download</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. upload</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Transferido</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Importância</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Ficheiros</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Banir par permanentemente</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Tem a certeza de que pretende banir permanentemente os pares selecionados?</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>Copiar IP: porta</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>País/Região</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>Adicionar pares...</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>Cliente de ID do par</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>Endereço IP:</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Mista</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Não fazer o download</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>Fontes HTTP</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Conteúdo</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Transferido:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Transferir</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Ativo há:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Temp. est. fim:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Enviado:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Sementes:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Vel. de transferência:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Vel. de envio:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Pares:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Limite de transferência:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Limite do envio:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Perdido:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Ligações:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informações</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Rácio de partilha:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Novo anúncio em:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Última vez que esteve completo:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Tamanho total:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Peças:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Criado por:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Adicionado em:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Terminado em:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Criado em:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Guardado em:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (tem %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 nesta sessão)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (máximo: %2)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (total: %2)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (média: %2)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrar ficheiros...</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (semeado durante %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>Informações de Hash v2:</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>Informações de Hash v1:</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Evolução:</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Utilizar expressões regulares</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nome do ficheiro</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>Nome do ficheiro + extensão</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>Enumerar ficheiros</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>Falha ao renomear: o ficheiro ou pasta já existe</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>Mudar seleção</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>Entrada de substituição</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>Extensão</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>Substituir tudo</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>Incluir ficheiros</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>Incluir pastas</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>Pesquisar ficheiros</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Diferenciar maiúsculas de minúsculas</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>Corresponder todas as ocorrências</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>Copiar URL da web seed</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>Opção de substituição</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>Editar URL da web seed...</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>URL de sementes da web:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>Proporção / Tempo ativo (em meses), indica o quão popular o torrent é</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>Popularidade:</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>Aplicar a que parte do nome do ficheiro</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>Remover web seed</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>Edição de sementes web</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>Adicionar web seeds...</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>Privado:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Disponibilidade:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Pasta monitorizada</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Sobrepor o local para guardar</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Pasta monitorizada</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Local por defeito para o 'Guardar'</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>Outros...</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Escreva a pasta aqui</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Estatísticas</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Estatísticas do utilizador</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Estatísticas de cache</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Ler os tops da cache:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Tempo médio em fila:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>Pares ligados:</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>Taxa de partilha global:</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>Downloads globais:</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>Desperdício da sessão:</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>Envios totais:</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>Tamanho total do buffer:</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Estatísticas de desempenho</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Tarefas I/O na fila:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Excesso de escrita em cache:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Excesso de leitura em cache:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Tamanho total da fila:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nós</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Tudo (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>A transferir (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>A semar (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Terminado(s) (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Ativo(s) (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Inativo(s) (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Com erros (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Tudo (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>A transferir (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>A semear (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Terminado(s) (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Ativo(s) (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Inativo(s) (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Com erros (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>Envio parado (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>Download parado (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>Download parado (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>Parado (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>Envio parado (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>Parado (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>A verificar (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>A verificar (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>A mover (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>A mover (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>Em execução (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>Parado (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>Parado (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>Em execução (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Remover torrents</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Sementes</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. download</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. upload</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Rácio</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Temp. est. fim</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Adicionado em</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Terminado em</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limite de transferências</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limite de uploads</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Transferido</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tempo ativo</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Guardar em</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Terminado(s)</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Limite do rácio</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Última vez que o ficheiro esteve completo</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última atividade</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamanho total</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Disponibilidade</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>Anunciar novamente em</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privado</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Evolução</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>Informação do Hash v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>Informação do Hash v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>Caminho do "Guardar em" incompleto</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>Popularidade</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Ícone de estado</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation>Enviado nesta sessão</translation>
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation>Descarregado nesta sessão</translation>
    </message>
    <message>
        <source>Created On</source>
        <translation>Criado em</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensagem</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>URL do tracker:</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>A atualizar...</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>A executar</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Inativo</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Ainda não contactado</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>Sementes</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Parado</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>Copiar URL do tracker</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>Editar URL do tracker...</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>A editar tracker</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>Leechers</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Remover tracker</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Restante</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Disponibilidade</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>Fila</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Prioridade dos downloads</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Evolução</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>Tamanho total</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>Vezes descarregado</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>Adicionar trackers...</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>Renomeado</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/endpoint de anúncio</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>Protocolo BT</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>Próximo anúncio</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation>Nível:</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Erro do tracker</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>Inacessível</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation>Forçar novo anúncio aos trackers selecionados</translation>
    </message>
    <message>
        <source>Min Announce</source>
        <translation>Anúncio mínimo</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>Forçar novo anúncio a todos os trackers</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de trackers a adicionar (um por linha):</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>Adicionar trackers</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 atrás</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Terminado(s)</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>A mover</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[F] A semear</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>A semear</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Em fila</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>Com erro</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[F] A transferir</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>A transferir os metadados</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>A verificar</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>Ficheiros em falta</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>Na fila de verificação</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>A transferir</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>A analisar dados</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>Parado</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (semeado durante %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[F] A transferir os metadados</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Parado</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Categorias</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>Recolher/expandir</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>Recolher/expandir categoria</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Limite de velocidade para o download dos torrents</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Limite de velocidade para o upload de torrents</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Limitar o rácio de partilha...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Limitar velocidade de upload...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Limitar velocidade de download...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover para cima</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover para baixo</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover para o início</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover para o fim</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Definir localização...</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Fazer o download da primeira e última peça primeiro</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Gestão automática do torrent</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Novo(a)...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Redefinir</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Forçar nova verificação</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Modo super semeador</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Fazer o download sequencialmente</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Nova categoria</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Definir localização</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Forçar reinício</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>Editar categoria</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>Etiquetas separadas por vírgulas:</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Ligação magnet</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>Remover tudo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Fila</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>Informações de hash v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>Informações do hash v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>ID do torrent</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>Exportar .torrent</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>Renomear ficheiros...</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>A renomear</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>Forçar início</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>O modo automático significa que várias propriedades do torrent (ex.: caminho de gravação) serão decididas pela categoria associada</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>Adicionar etiquetas</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation>Caminho do conteúdo</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Limite de rácio para o upload/download dos torrents</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Utilizar limite de partilha global</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Definir ausência de limite de partilha</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Definir o limite de partilha para</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>rácio</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>minutos totais</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>minutos inativos</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predefinido</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Remover torrent</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>Remover o torrent e o respetivo conteúdo</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Parar torrent</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Ativar super-seeding para o torrent</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation>Ação ao atingir o limite</translation>
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>Remover torrent(s)</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>Remover também os ficheiros de conteúdo</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Remover tracker</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Transferir a partir de URLs</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1 h e %2 m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1 d e %2 h</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 m</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1a %2d</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>O caminho de gravação encontra-se vazio</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>Caminho do plugin:</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>URL ou diretório local</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>Instalar plugin</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Aceitar</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>Sementes:</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>Todos os plugins</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Procura</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>Plugins de pesquisa...</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>Todas as categorias</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>Pesquisar em:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>Apenas nomes de torrents</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>Apenas ativo</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>fora de</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>Em tudo</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>Aumentar largura da janela para mostrar filtros adicionais</translation>
    </message>
    <message>
        <source>to</source>
        <translation>até</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>a mostrar</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>Clique em "Plugins de pesquisa..." na parte inferior da janela para instalar alguns.</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>Não existe nenhum plugin de busca instalado.</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>Selecionar categoria</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>Prefixo de tamanho mínimo</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>Inicie uma pesquisa acima.</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>Prefixo de tamanho máximo</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>Selecionar plugins</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>Instalar novo plugin</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>Pode obter novos plugins do mecanismo de pesquisa aqui:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>Plugins de pesquisa instalados:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Ativo</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Aviso: Certifique-se que cumpre as leis de direitos de autor do seu país ao fazer a transferência de torrents a partir de qualquer um destes motores de pesquisa.</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Pesquisar por atualizações</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>Plugins de procura</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>Sanguessugas</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>Semeadores</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>Publicado em</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>URL do motor de pesquisa</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>Motor</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Ativo</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Não</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>Adicionar pares</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>Lista de pares a adicionar (um IP por linha):</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formato: IPv4:porta / [IPv6]:porta</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>Nova etiqueta</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>Adicionar etiqueta...</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>Remover etiquetas não utilizadas</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>Nome de etiqueta inválido</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>Remover etiqueta</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Remover torrents</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>Sem etiqueta</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Tracker de erros:</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Acerca</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Fórum:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>Programador atual</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Página inicial:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>Grécia</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>Agradecimento especial</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Um cliente avançado de BitTorrent programado em C++, baseado em ferramentas QT e em 'libtorrent-rasterbar'.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>Acerca do qBittorrent</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>Tradutores</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>O qBittorrent foi criado com as seguintes bibliotecas:</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>Nacionalidade:</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>Software utilizado</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>A base de dados gratuita IP to Country Lite da DB-IP é utilizada para resolver os países dos pares. A base de dados está licenciada ao abrigo da licença Creative Commons Attribution 4.0 International</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Autores</translation>
    </message>
    <message>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>Mascote do qBittorrent</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>Ícone do qBittorrent</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>Todos os endereços</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>Todos os endereços IPv6</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>Todos os endereços IPv4</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descarregar</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>URL da página de descrição</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>Abrir página de descrição</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>Link para download</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>A pesquisa terminou</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>Ocorreu um erro durante a procura...</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>Fechar separador</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>A pesquisar...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Pesquisa abortada</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>Fechar todos os separadores</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation>Atualizar separador</translation>
    </message>
    <message>
        <source>Open download window</source>
        <translation>Abrir a janela de download</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation>Utilizar como texto de pesquisa</translation>
    </message>
    <message>
        <source>Stop search</source>
        <translation>Parar pesquisa</translation>
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>A renomear</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Escolha um novo nome para este feed RSS</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Por favor, escolha o nome da pasta</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Novo nome do feed:</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Atualizar tudo</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>Downloader de RSS...</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Marcar itens como lidos</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Atualizar todos os feeds</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Copiar URL do feed</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (duplo clique para fazer o download)</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>URL do feed:</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Nova pasta...</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Nova subscrição</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Atualizar</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Nome da pasta:</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>Introduza um URL de feed RSS</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>A obtenção de feeds RSS está desativada. Pode ativá-la nas definições da aplicação.</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>Confirmação de eliminação</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Tem a certeza de que pretende eliminar os feeds RSS selecionados?</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Nova subscrição...</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Fazer o download do torrent</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>Editar URL do feed...</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>Não foi possível atualizar o URL</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>O URL não foi alterado</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>O URL não pode estar vazio</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>Abrir ligação</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>Regras para transferir</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>Artigos RSS coincidentes</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* para igualar a zero ou mais caracteres</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation> irá corresponder a todos os artigos.</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>Regras para filtro de episódios: </translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>A transferência automática de torrents RSS está desativada agora! Pode ativá-la nas definições do programa.</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>Definição de regra</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Guardar em:</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>Utilizar expressões regulares</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Nome da nova regra</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>O filtro deve terminar com ponto e vírgula</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? para corresponder a qualquer carácter</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>Correspondência de artigos tendo por base o filtro de episódios.</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>Atribuir categoria:</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Modo regex: utilizar expressões regulares compatíveis com Perl</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>É utilizado como operador OR (OU)</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>Limpar episódios transferidos</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Os espaços em branco contam como operadores AND (E) (todas as palavras, qualquer ordem)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>Uma expressão com uma cláusula %1 vazia (ex. %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>Exemplo: </translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Adicionar nova regra...</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Deseja realmente limpar a lista de episódios transferidos da regra selecionada?</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>Deve conter:</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Limite infinito: &lt;b&gt;1x25-;&lt;/b&gt; corresponde os episódios 25 e superiores da temporada um, e a todos os episódios de temporadas posteriores</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>Guardar noutro diretório</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>Não deve conter:</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Um número: &lt;b&gt;1x25;&lt;/b&gt; corresponde ao episódio 25 da temporada um</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>São suportados três tipos de intervalos para episódios: </translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Tem a certeza de que quer remover as regras de transferência selecionadas?</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>Utilizar definições globais</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Intervalo normal: &lt;b&gt;1x25-40;&lt;/b&gt; corresponde aos episódios 25 a 40 da temporada um</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Por favor, escreva o novo nome da regra</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Alteração de nome de regra</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>O número de episódio tem de ser obrigatóriamente positivo</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation> corresponderá aos episódios 2, 5, 8 a 15, 30 e posteriores da primeira temporada</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Confirmação de eliminação de regra</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>Última correspondência: %1 dias atrás</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>Filtro de episódio:</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>Transferidor de RSS</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>O número de temporada tem de ser um valor positivo</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar regra aos feeds:</translation>
    </message>
    <message>
        <source> days</source>
        <translation> dias</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>Utilizar o 'Filtro inteligente de episódios'</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Se a ordem das palavras é importante utilize * em vez de um espaço em branco.</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Escreva o nome da nova regra para transferências.</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>Modo de caracteres universais: pode utilizar</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation> irá excluir todos os artigos.</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Eliminar regra</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>Ignorar ocorrências subsequentes para (0 para desativar)</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Mudar o nome da regra...</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>Última correspondência: desconhecida</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>Limpar os episódios transferidos...</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>O filtro inteligente de episódios irá verificar o número do episódio para prevenir transferir ficheiros duplicados.
Suporta os formatos: S01E01, 1x1, 2017.12.31 e 31.12.2017 (Suporte também para formatos de data - como um separador)</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Disposição do conteúdo do torrent:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Criar subpasta</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Não criar subpasta</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>Adicionar etiquetas:</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>Remover regra</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>Adicionar regra</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>Adicionar parado(s):</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation>Confirmação de limpeza dos episódios descarregados</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>Remover torrents</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>Sem tracker</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Iniciar torrents</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Remover tracker</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Parar torrents</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Erro do tracker</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation>Outro erro</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>Feeds RSS</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Por ler</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Bloqueado</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>a mostrar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecionar tudo</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Tipo de registo</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>Mensagens de informação</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>Mensagens de aviso</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>Filtrar registos</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>IPs bloqueados</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>de</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>Carimbo de data/hora</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>Limpar tudo</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensagem</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>Níveis de registo</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Motivo</translation>
    </message>
    <message>
        <source>item</source>
        <translation>item</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>Banido</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>Mensagens normais</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>Crítico</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>Mensagens críticas</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>items</source>
        <translation>itens</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Informação</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>Escolha um nível de registo...</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>Tem a certeza de que pretende remover o tracker %1 de todos os torrents?</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>Não foi possível editar a categoria</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>Não foi possível criar a categoria</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>Não foi possível definir a categoria</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>Caminho para guardar os torrents incompletos:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predefinido</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Nova categoria</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Guardar em:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>Usar outro caminho para os torrents incompletos:</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation>A categoria não existe</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>Domínio</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>Gerir cookies</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>Adicionar cookie</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>Expira a</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>Ativar a  gestão automática dos torrents</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>Tem a certeza que deseja ativar o gestor automático dos torrents para os torrents selecionados? Eles poderão ser realocados.</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Tem a certeza de que deseja reverificar o(s) torrent(s) selecionado(s)?</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>Confirmação de reverificação</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>Fechar separador</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>WebUI do qBittorrent</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Palavra-passe</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>É necessário o JavaScript! Deve ativar o JavaScript para a interface web de forma a poder funcionar corretamente</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Iniciar sessão</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>Resposta do servidor:</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>Não foi possível iniciar sessão. O servidor poderá estar inacessível.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nome de utilizador</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Palavra-passe ou nome de utilizador inválido.</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>Privado</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Origem</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Em fila</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>Não foi possível criar o torrent.</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>Torrent privado
                (não será distribuído na rede DHT)</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Não foi possível exportar o ficheiro torrent</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>Criar novo torrent</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Comentários:</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>Descarregar torrent</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Ícone de estado</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>URL de sementes da web:</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Falhou</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Concluído</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Definições</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>Mensagem de erro</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>Alinhar ao limite da peça para ficheiros maiores
                do que:</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>Selecionar ficheiro/pasta a partilhar:</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>Tamanho da peça</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Evolução</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>Terminado em</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>Híbrido</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>Não foi possível carregar as tarefas de criação de torrents</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>Otimizar
                    alinhamento</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>URLs do tracker:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>Tem a certeza de que pretende eliminar as tarefas selecionadas?</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>Criar torrent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>Iniciado em</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Web seeds</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>Iniciar
                seed
                imediatamente</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Formato do torrent:</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>Caminho de origem</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>Adicionado em</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>Em execução</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Criador de torrents</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>Origem:</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Tamanho da peça:</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Campos</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>Remover tarefa</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>Exportar torrent</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">Transferir</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Ligação magnet</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Adicionar ligações torrent</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Uma ligação por linha (são suportados ligações HTTP,  ligações magnet e info-hashes)</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URLs</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>Adicionar ligações torrent</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation>Limite:</translation>
    </message>
    <message>
        <source>Speed limit</source>
        <translation>Limite de velocidade</translation>
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>Limite de upload:</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>Limite de download:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation>Redimensionar tudo</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>Redimensionar</translation>
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation>Gerar uma chave API? Esta chave pode ser utilizada para interagir com a API do qBittorrent.</translation>
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation>Eliminar esta chave API? A chave atual deixará imediatamente de funcionar.</translation>
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation>Regenerar esta chave API? A chave atual deixará imediatamente de funcionar e será gerada uma nova chave.</translation>
    </message>
</context>
</TS>