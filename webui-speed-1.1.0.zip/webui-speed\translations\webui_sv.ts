<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">Om</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>Starta torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>Hoppa över hashkontroll</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Torrenthanteringsläge:</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>Innehållslayout:</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Skapa undermapp</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Skapa inte undermapp</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuell</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Mottagna metadata</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Kontrollerade filer</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>Stoppvillkor:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Inget</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Lägg till överst i kön</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Hämta i sekventiell ordning</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">Storlek:</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>Spara i</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Torrentinformation</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Sparsökväg:</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>Info-hash v1:</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>Byt namn på torrent</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation>Lägg till torrent</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>Inte tillgänglig</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Hög</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Torrentinställningar</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>Spara filer till platsen:</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>Ange som standardkategori</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>Begränsa sändningshastighet</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrera filer...</translation>
    </message>
    <message>
        <source>Add Torrent</source>
        <translation type="vanished">Lägg till torrent</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>Använd en annan sökväg för ofullständig torrent</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation>Spara som .torrent-fil</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Inte tillgängligt</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>Högsta</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Hämta inte</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Hämta första och sista delarna först</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation>Det gick inte att hämta torrentfilen</translation>
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>Info-hash v2:</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>Taggar:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Filer</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>Begränsa hämtningshastighet</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>Okategoriserad</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>Lägg till kategori...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>Ta bort kategori</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>Ta bort oanvända kategorier</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>Redigera kategori...</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>Lägg till underkategori...</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Starta torrenter</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stoppa torrenter</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>Avsluta qBittorrent</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Global gräns för sändningshastighet måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Global hämtningshastighetsgräns måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativ gräns för sändningshastighet måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativ hämtningshastighetsgräns måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Högst antal aktiva hämtningar måste vara större än -1.</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Högst antal aktiva sändningar måste vara större än -1.</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Högst antal aktiva torrenter måste vara större än -1.</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Högst antal anslutningar måste vara större än 0 eller inaktiverat.</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Högst antal anslutningar per torrent måste vara större än 0 eller inaktiverat.</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Högst antal sändningsplatser per torrent måste vara större än 0 eller inaktiverat.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Tillämpa</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Mer information</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>Information om certifikat</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Ange plats</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Måndag</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Tisdag</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Onsdag</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Torsdag</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Fredag</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lördag</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Söndag</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Logga ut</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>Det går inte att nå qBittorrent-klienten</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>Globalt antal sändningsplatser måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>Ogiltigt kategorinamn:\nAnvänd inga specialtecken i kategorinamnet.</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>Tröskeln för sändningshastighet måste vara större än 0.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>Ledigt diskutrymme: %1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>Torrentinaktivitetstidtagare måste vara större än 0.</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>Sparhantering</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>Hämtningshastighetsgränsen måste vara större än 0.</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>Öppna dokumentationen</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>Registrera för att hantera magnetlänkar...</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>Det går inte att lägga till jämlikar. Se till att du följer formatet IP:port.</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>Namnet kan inte vara tomt</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>Namnet är oförändrat</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>Det gick inte att uppdatera namnet</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>Porten som används för inkommande anslutningar måste vara mellan 0 och 65535.</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>Ursprunglig författare</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>Porten som används för webbgränssnittet måste vara mellan 1 och 65535.</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 har stängts</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript krävs! Du måste aktivera JavaScript för att webbgränssnittet ska fungera korrekt</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>Extern IP: inte tillgängligt</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>Exempel på omvänd proxyinställning</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>Det gick inte att kontakta qBittorrent</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>Kom ihåg valet</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>Är du säker på att du vill ta bort dessa %1 torrenter från överföringslistan?</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>Det går inte att ta bort torrenter.</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>Extern IP: %1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>Redigera webbdistribution</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>Är du säker på att du vill ta bort %1 från överföringslistan?</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>Det gick inte att ställa in automatisk torrenthantering för de valda torrenterna.</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>Det går inte att stoppa torrenter.</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>Det gick inte att hämta filen</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>Externa IP-adresser: %1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>Det går inte att återkontrollera torrenter.</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>Lista över webbdistributioner att lägga till (en per rad):</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>Det går inte att starta torrenter.</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>Lägg till webbdistributioner</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation>Det gick inte att ta bort API-nyckeln.</translation>
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>Gräns för distributionstid får inte ha ett negativt värde.</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>Gränsen för utdelningskvot får inte ha ett negativt värde.</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation>Intervallet för omsättning av jämlikar måste vara större än eller lika med 0.</translation>
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation>Det gick inte att tolka svaret.</translation>
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation>Det gick inte att rotera API-nyckeln.</translation>
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation>Jämlikeomsättningen måste vara mellan 0 och 100.</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation>Utestående minne vid kontroll av torrenter måste vara större än 0 och mindre än 1024.</translation>
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation>Det gick inte att läsa in programinställningarna, qBittorrent är förmodligen inte nåbar.</translation>
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation>Gränsvärdet för omsättning av jämlikar måste vara mellan 0 och 100.</translation>
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation>DSCP för jämlikar måste vara mellan 0 och 255.</translation>
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation>Det gick inte att spara inställningarna, qBittorrent är förmodligen inte nåbart.</translation>
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation>Det gick inte att lägga till torrenter.</translation>
    </message>
    <message>
        <source>Error:</source>
        <translation>Fel:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Verktyg</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visa</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>Alternativ...</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>Översta verktygsfältet</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>Statusfält</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>Hastighet i titelfältet</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>Donera!</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Statistik</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>Lägg till torrentfil...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>Dokumentation</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>Lägg till torrentlänk...</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>Global hastighetsgräns för sändning</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>Global hastighetsgräns för hämtning</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Är du säker på att du vill avsluta qBittorrent?</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>Alternativa hastighetsgränser</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>Sökmotor</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>Filtrera torrentlista...</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>Överföringar</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>Flytta fram i kön</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>Flytta fram i kön</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>Längst bak i kön</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>Flytta till slutet av kön</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>Längst fram i kön</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>Flytta bak i kön</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>Flytta bak i kön</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>Flytta till början av kön</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>Din webbläsare stöder inte den här funktionen</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>För att använda den här funktionen måste WebUI nås via HTTPS</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>Anslutningsstatus: Bakom brandvägg</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>Anslutningsstatus: Ansluten</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>Alternativa hastighetsgränser: Av</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>Ikon för hämtningshastighet</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>Alternativa hastighetsgränser: På</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>Ikon för sändningshastighet</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>Anslutningsstatus: Frånkopplad</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS-läsare</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>Filtersidofält</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>Körningslogg</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>Logg</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[N: %1, U: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>Filtrera efter:</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>Sparsökväg</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>Använd reguljärt uttryck</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>Vill du starta alla torrenter?</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Starta</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>Hantera kakor...</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Det går inte att exportera torrentfil</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>Vill du stoppa alla torrenter?</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>Starta alla</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>Stoppa alla</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrentskapare</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation>Filtrera flödesobjekt...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Hämtningar</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Anslutning</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Hastighet</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>E-postavisering när hämtningen är klar</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP-filtrering</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Schemalägg användning av alternativa hastighetsgränser</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrentkö</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Webbgränssnitt (fjärrstyrning)</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>IP-adress:</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>Serverdomäner:</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Använd HTTPS i stället för HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Kringgå autentisering för klienter på localhost</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Kringgå autentisering för klienter i tillåtna IP-undernät</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>Uppdatera mitt dynamiska domännamn</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>Behåll ofullständiga torrenter i:</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>Kopiera .torrent-filer till:</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Kopiera .torrent-filer för slutförda hämtningar till:</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>Förallokera diskutrymme för alla filer</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Lägg till ändelsen .!qB till ofullständiga filer</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>Lägg automatiskt till torrenter från:</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP-server:</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Den här servern kräver en säker anslutning (SSL)</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Autentisering</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Användarnamn:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP och μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>Lyssningsport</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>Port som används för inkommande anslutningar:</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Använd UPnP / NAT-PMP-portomdirigering från min router</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>Anslutningsgränser</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>Högst antal anslutningar per torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>Högst antal anslutningar globalt:</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Högst antal sändningsplatser per torrent:</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>Högst antal sändningsplatser globalt:</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>Proxyserver</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>Värd:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>Använd proxy för jämlikeanslutningar</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Filtersökväg (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>Manuellt förbjudna IP-adresser...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>Tillämpa på spårare</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>Globala hastighetsgränser</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>Sändning:</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>Hämtning:</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>Alternativa hastighetsgränser</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Från:</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Till:</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>När:</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>Varje dag</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>Vardagar</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>Helger</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>Inställningar för hastighetsgränser</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>Tillämpa hastighetsgräns på protokollöverhead</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Tillämpa hastighetsgräns för µTP-protokoll</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Integritet</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Aktivera DHT (decentraliserat nätverk) för att hitta fler jämlikar</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Aktivera jämlikeutbyte (PeX) för att hitta fler jämlikar</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Aktivera upptäckt av lokala jämlikar för att hitta fler jämlikar</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>Krypteringsläge:</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>Kräv kryptering</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>Inaktivera kryptering</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>Aktivera anonymt läge</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>Högst antal aktiva hämtningar:</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>Högst antal aktiva sändningar:</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>Högst antal aktiva torrenter:</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>Räkna inte långsamma torrenter med dessa gränser</translation>
    </message>
    <message>
        <source>then</source>
        <translation>därefter</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Använd UPnP / NAT-PMP för att vidarebefordra porten från min router</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>Certifikat:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Nyckel:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrera</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>Domännamn:</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parametrar som stöds (skiftlägeskänsliga):</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N: Torrentnamn</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L: Kategori</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Innehållssökväg (samma som root-sökväg för flerfilig torrent)</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Root-sökväg (första torrentundermappsökväg)</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D: Sparsökväg</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C: Antal filer</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrentstorlek (byte)</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T: Aktuell spårare</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>Tips: Inkapsla parametern med citattecken för att undvika att text skärs av vid blanktecknet (t. ex. "%N")</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minuter</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>Aktivera skydd mot klickkapning</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Aktivera skydd mot förfalskning av förfrågningar mellan webbplatser (CSRF)</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>Ta bort .torrent-filer efteråt</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>Hämtningshastighetsgräns:</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>Sändningshastighetsgräns:</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>Byt aktuellt lösenord</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>Standardsparsökväg:</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>Starta inte hämtningen automatiskt</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>Växla torrent till manuellt läge</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>När torrentkategorin ändras:</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>Flytta påverkade torrenter</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Tillämpa hastighetsgräns för LAN-jämlikar</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 betyder obegränsad</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>Flytta torrent</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>När standardsparsökvägen ändras:</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>Aktivera validering av värdrubrik</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Säkerhet</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>När kategorins sparsökväg ändras:</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>sekunder</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Växla påverkade torrenter till manuellt läge</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>Filplats:</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuellt</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Torrentinaktivitetstidtagare:</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>Standardläge för torrenthantering:</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>När en torrent läggs till</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>Algoritm för blandat μTP-/TCP-läge:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>Baserat på sändningshastighet</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Taggar (separerade med kommatecken)</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Storlek på socket-kön:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Aktivera superdistribution för torrent</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>Föredra TCP</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>Utestående minne vid kontroll av torrenter:</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>Anti-leech</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>När kvoten når</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>Tillåt flera anslutningar från samma IP-adress:</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>Filpoolstorlek:</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>Alla gränssnitt</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>Annonsera alltid till alla nivåer:</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>Port för inbäddad spårare:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>Snabbaste sändning</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>Ta bort torrent och dess filer</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>qBittorrent-avsnitt</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>Skicka buffertvattenstämpelsfaktor:</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>libtorrent-avsnitt</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>Återkontrollera torrenter vid slutförning:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>Tillåt kryptering</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>Skicka förslag på sändningsdelar:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>Aktivera inbäddad spårare:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Ta bort torrent</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>Asynkrona in/ut-trådar:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>Skicka buffertvattenstämpel:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Proportionell jämlike (stryper TCP)</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>Fasta platser</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <source>min</source>
        <translation>min</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>Strypningsalgoritm för sändning:</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>Distributionsgränser</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>Round Robin</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>Beteende för sändningsplatser:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>Skicka låg buffertvattenstämpel:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>Intervall för att spara återupptagningsdata:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>Annonsera alltid till alla spårare i en nivå:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>Sessionstidsgräns:</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>Slå upp jämlikarnas länder:</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>förbud för:</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>Förbjud klient efter upprepade misslyckanden:</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Rubrik: värdepar, en per rad</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>Lägg till anpassade HTTP-rubriker</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>Filter:</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>Aktivera hämtning av RSS-flöden</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>Procenttröskelandel av jämlikeomsättning:</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Automatisk RSS-torrenthämtare</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>Nätverksgränssnitt:</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS-läsare</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>Redigera regler för automatisk hämtning...</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Hämta REPACK-/PROPER-avsnitt</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>Uppdateringsintervall för flöden:</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>Procentandel för bortkoppling av jämlikeomsättning:</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>Högst antal artiklar per flöde:</translation>
    </message>
    <message>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>Intervall för bortkoppling av jämlikeomsättning:</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>Valfri IP-adress att binda till:</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>Tillåt inte anslutning till jämlikar på privilegierade portar:</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Aktivera automatisk hämtning av RSS-torrenter</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>Smart RSS-avsnittsfilter</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>Validera HTTPS-certifikat för spårare:</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>Jämlikeanslutningsprotokoll:</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Layout för torrentinnehåll:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Skapa undermapp</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Ursprunglig</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Skapa inte undermapp</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>Utgående anslutningar per sekund:</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>Slumpmässig</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: Torrent-ID</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>Återannonsera alla spårare när IP eller port ändrats:</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>Lista över betrodda proxyer:</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>Aktivera stöd för omvänd proxy</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J: Info-hash v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: Info-hash v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>IP-adress rapporterad till spårare (kräver omstart):</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Ange 0 för att låta systemet välja en ledig port</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>Begränsning av förfalskning av förfrågningar på serversidan (SSRF):</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>Diskköstorlek:</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>Logga prestandavarningar</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>Högst antal utestående förfrågningar till en enskild jämlike:</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>Max aktiva torrentkontroller:</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>Minnesmappade filer</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>POSIX-kompatibel</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>Den styr det interna tillståndsuppdateringsintervallet som i sin tur kommer att påverka användargränssnittsuppdateringar</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>Läsläge för disk-I/O:</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>Inaktivera OS-cache</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>Skrivläge för disk-I/O:</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>Använd affinitet för delar:</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>Högst antal samtidiga HTTP-annonseringar:</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>Aktivera OS-cache</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>Uppdateringsintervall:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>Exkluderade filnamn</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>Stöd internationaliserade domännamn (IDN):</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>Vitlista för filtrering av HTTP-värdrubrikvärden.
För att försvara dig mot DNS-återbindingsattack, bör du lägga in
domännamn som används av webbanvändargränssnittsservern.

Använd ";" för att dela upp i flera poster. Du kan använda jokertecknet "*".</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>HTTPS-certifikatet ska inte vara tomt</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>Ange IP-adresser för omvänd proxy (eller undernät, t.ex. 0.0.0.0/24) för att använda vidarebefordrad klientadress (X-Forwarded-For-rubrik). Använd ';' för att dela upp flera poster.</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>HTTPS-nyckeln ska inte vara tom</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>Kör externt program</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>Kontrollerade filer</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>Aktivera portvidarebefordran för inbäddad spårare:</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>Om markerat görs värdnamnsuppslag via proxyn.</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>Mottagna metadata</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Torrentstoppvillkor:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Inget</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Exempel: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>SQLite-databas (experimentell)</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>Lagringstyp för återupptagningsdata (kräver omstart):</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>Fastresume-filer</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>Säkerhetskopiera loggfilen efter:</translation>
    </message>
    <message>
        <source>days</source>
        <translation>dagar</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Beteende</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>Ta bort säkerhetskopieringsloggar äldre än:</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>Använd proxy för BitTorrent-ändamål</translation>
    </message>
    <message>
        <source>years</source>
        <translation>år</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Sparsökväg:</translation>
    </message>
    <message>
        <source>months</source>
        <translation>månader</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>Kom ihåg inställningarna för flera namnbyten</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>Använd proxy för allmänna ändamål</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>Använd proxy för RSS-ändamål</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>Storlek på socketens sändningsbuffert [0: systemstandard]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>Utgående portar (max) [0: inaktiverat]:</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>Storlek på socketens mottagningsbuffert [0: systemstandard]:</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>Lägg till överst i kön</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>Stopptidsgräns för spårare [0: inaktiverat]:</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>Utgående portar (min) [0: inaktiverat]:</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>UPnP-leasetid [0: permanent lease]:</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Bdecode-djupgräns:</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Bdecode-tokengräns:</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>När totala distributionstiden når</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(Ingen)</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Sökväg till körbar Python-fil (kan kräva omstart):</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>Återställ till standard om den är tom</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>Utför värdnamnsuppslagning via proxy</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>Om &amp;quot;blandat läge&amp;quot; är aktiverat, tillåts I2P-torrenter att även få jämlikar från andra källor än spåraren och ansluta till vanliga IP-adresser, utan att ge någon anonymisering. Detta kan vara användbart om användaren inte är intresserad av anonymisering av I2P, men ändå vill kunna ansluta till I2P-jämlikar.</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>DHT-bootstrapnoder:</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>När den inaktiva distributionstiden når</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>Blandat läge</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>Storleksgräns för .torrent-filer:</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>(Identifiera automatiskt om tomt)</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>Behåll omarkerade filer i mappen ".unwanted"</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>Aktivera Mark-of-the-Web (MOTW) för hämtade filer (kräver macOS eller Windows):</translation>
    </message>
    <message>
        <source> sec</source>
        <translation> sek</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>I2P utgående kvantitet:</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>I2P inkommande kvantitet:</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>Hashtrådar:</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>Användningsgräns för fysiskt minne (RAM):</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>Använd alternativt webbgränssnitt</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>Utgångsintervall för diskcache:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>I2P utgående längd:</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P (experimentell)</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>Disk-I/O-typ (kräver omstart):</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>Den alternativa platsen för webbanvändargränssnittsfiler får inte vara tom.</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>Diskcache:</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>Genomskrivning</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>Webbgränssnitt</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>Lösenordet för webbanvändargränssnittet måste vara minst 6 tecken långt.</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>Coalesce läser &amp;amp; skriver:</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>I2P inkommande längd:</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>Användarnamnet för webbanvändargränssnittet måste vara minst 3 tecken långt.</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>Fördröjning mellan förfrågningar till samma värd:</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>Anpassa programinstansens namn:</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>Färgschema:</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>Visa extern IP i statusfältet</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>Hämtade spårare</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>Bekräfta borttagning av torrenter</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>Ignorera SSL-fel:</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Mörk</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>Ta bort filerna permanent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>Använd alternerande radfärger</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>Visa fullständig annonseringsadress i spårarskolumnen</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>Överföringslista</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>Annonseringsporten måste vara mellan 0 och 65535.</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Ljus</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>Lägg automatiskt till dessa spårare till nya hämtningar:</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>Hämtar torrenter:</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>Starta / stoppa torrent</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>Skicka e-posttest</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>Slutförda torrenter:</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>Aktivera säkerhetsflaggan för kakor (kräver HTTPS eller localhost-anslutning)</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>Åtgärd vid dubbelklick</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>Spara statistikintervall:</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Visar en bekräftelsedialogruta när du tar bort torrenter</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>Kör på slutförd torrent:</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>Försökte skicka e-post. Kontrollera din inkorg för att bekräfta att det lyckades</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>Lägg automatiskt till spårare från URL till nya hämtningar:</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Läge för borttagning av torrentinnehåll:</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>Flytta filer till papperskorgen (om möjligt)</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Stoppa torrent</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>Använd kategorisökvägar i manuellt läge</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>Lista över alternativa WebUI</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>Kör på tillagd torrent:</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>Port rapporterad till spårare (kräver omstart) [0: lyssningsport]:</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>Språk för användargränssnitt:</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>Slå samman spårare till befintlig torrent</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation>Bekräfta återkontroll av torrent:</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>Anpassade webbanvändargränssnitt-inställningar</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>Följande inställningar är endast för webbanvändargränssittet</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>Enkel pread/pwrite</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Lös relativ sparsökväg mot lämplig kategorisökväg istället för standardsökväg</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>Ingen åtgärd</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>Dölj nollstatusfilter automatiskt</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Gränssnitt</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>Loggfiler</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>Aktivera optimerad rendering av tabeller (experimentell)</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>Observera: Lösenordet sparas okrypterat</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>Utgångsintervall för cache för intern värdnamnsresolver</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>sek</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation>Rotera API-nyckel</translation>
    </message>
    <message>
        <source>Generate a key</source>
        <translation>Generera en nyckel</translation>
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation>När en duplicerad torrent läggs till</translation>
    </message>
    <message>
        <source>Delete API key</source>
        <translation>Ta bort API-nyckel</translation>
    </message>
    <message>
        <source>%M: Comment</source>
        <translation>%M: Kommentar</translation>
    </message>
    <message>
        <source>Generate API key</source>
        <translation>Generera API-nyckel</translation>
    </message>
    <message>
        <source>Copied</source>
        <translation>Kopierad</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Användare</translation>
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation>Återställ filterval</translation>
    </message>
    <message>
        <source>API Key</source>
        <translation>API-nyckel</translation>
    </message>
    <message>
        <source>Copy API key</source>
        <translation>Kopiera API-nyckel</translation>
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation>Differentierad tjänstekodpunkt (DSCP) för anslutningar till jämlikar</translation>
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation>Användarnamnet för webbgränssnittet får inte innehålla kolon.</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>Datumformat:</translation>
    </message>
    <message>
        <source>Browser default</source>
        <translation>Webbläsarstandard</translation>
    </message>
    <message>
        <source>Localization</source>
        <translation>Lokalisering</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>Kompakt</translation>
    </message>
    <message>
        <source>Display density:</source>
        <translation>Skärmdensitet:</translation>
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation>Den lägger till texten i fönsterrubriken för att hjälpa till att skilja qBittorrent-instanser åt</translation>
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation>Slå upp jämlikevärdnamn:</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Flaggor</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>Anslutning</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Framsteg</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Hämtningshastighet</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Sändningshastighet</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Hämtat</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Skickat</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>Relevans</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Filer</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>Förbjud jämliken permanent</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Är du säker på att du vill permanent förbjuda de valda jämlikarna?</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>Kopiera IP:port</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>Land/region</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>Lägg till jämlikar...</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>Jämlikens klient-ID</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>IP/adress</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Hög</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Högsta</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Blandat</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>Hämta inte</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Spårare</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Jämlikar</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP-källor</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Innehåll</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>Hämtat:</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>Överföring</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tid aktiv:</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>Slutförs om:</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>Skickat:</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>Distributioner:</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>Hämtningshastighet:</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>Sändningshastighet:</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>Jämlikar:</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>Hämtningsgräns:</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>Sändningsgräns:</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>Spill:</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>Anslutningar:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>Delningskvot:</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>Annonseras igen om:</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>Senast sedd fullständig:</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>Total storlek:</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>Delar:</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>Skapad av:</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>Tillagd:</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>Slutförd:</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>Skapad:</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>Sparsökväg:</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (har %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 denna session)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 max)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 totalt)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 genomsnitt)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>Filtrera filer...</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (distribuerad i %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>Info-hash v2:</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>Info-hash v1:</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Inte tillgängligt</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Framsteg:</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>Använd reguljära uttryck</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Filnamn</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>Filnamn + filändelse</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>Räkna upp filer</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>Det gick inte att byta namn: fil eller mapp finns redan</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>Växla val</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>Ersättningsinmatning</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Ersätt</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>Filändelse</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>Ersätt alla</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>Inkludera filer</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>Inkludera mappar</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>Sök filer</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>Skiftlägeskänsliga</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>Matcha alla händelser</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>Kopiera URL för webbdistribution</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>Ersätt alternativ</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>Redigera URL för webbdistribution...</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>URL för webbdistribution:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>Kvot / aktiv tid (i månader), indikerar hur populär torrenten är</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>Popularitet:</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>Tillämpa på vilken filnamnsdel</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>Ta bort webbdistribution</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>Redigering av webbdistribution</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>Lägg till webbdistribution...</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>Privat:</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>Tillgängligt:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>Övervakad mapp</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>Åsidosatt sparningsplats</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>Övervakad mapp</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>Standard sparningsplats</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>Annan...</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>Ange mapp här</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>Statistik</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>Användarstatistik</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>Cachestatistik</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>Träffar i läscache:</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>Genomsnittlig kötid:</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>Anslutna jämlikar:</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>Alla tiders delningskvot:</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>Alla tiders hämtning:</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>Sessionsspill:</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>Alla tiders sändning:</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>Total bufferstorlek:</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>Prestandastatistik</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>Köade in/ut-jobb:</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>Överbelastad skrivcache:</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>Överbelastad läscache:</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>Total köstorlek:</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 noder</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Alla (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>Hämtar (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>Distribuerar (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>Slutförda (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>Aktiva (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>Inaktiva (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>Fallerande (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>Alla (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>Hämtar (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>Distribuerar (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>Slutförda (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>Aktiva (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>Inaktiva (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>Fallerande (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>Avstannade sändningar (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>Avstannade hämtningar (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>Avstannade hämtningar (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>Avstannade (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>Avstannade sändningar (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>Avstannade (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>Kontrollerar (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>Kontrollerar (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>Flyttar (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>Flyttar (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>Körs (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>Stoppade (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>Stoppade (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>Körs (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Starta torrenter</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stoppa torrenter</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Storlek</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Distributioner</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Jämlikar</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Hämtningshastighet</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Sändningshastighet</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Kvot</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Slutförs om</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Tillagd</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Slutförd</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Spårare</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Hämtningsgräns</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Sändningsgräns</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Hämtat</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Skickat</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Återstår</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tid aktiv</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Sparsökväg</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Slutförd</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Kvotgräns</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Senast sedd fullständig</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Senaste aktivitet</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Total storlek:</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Tillgänglighet</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>Annonseras igen om</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>Privat</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Framsteg</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>Info-hash v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>Info-hash v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>Ofullständig sparsökväg</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>Popularitet</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Statusikon</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation>Skickat denna session</translation>
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation>Hämtat denna session</translation>
    </message>
    <message>
        <source>Created On</source>
        <translation>Skapad:</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>Jämlikar</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Meddelande</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>Spårar-URL:</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>Uppdaterar...</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>Arbetar</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Inaktiverad</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>Inte ännu kontaktad</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Inte tillgängligt</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>Distributioner</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>Arbetar inte</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>Kopiera URL för spårare</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>Ändra spårar-URL...</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>Redigera spårare</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>Reciprokörer</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Ta bort spårare</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>Återstår</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>Tillgänglighet</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>Nivå</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>Hämtningsprioritet</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Framsteg</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>Total storlek</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>Antal hämtningar</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>Lägg till spårare...</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>Omdöpt</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/annonseringsslutpunkt</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>BT-protokoll</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>Nästa annonsering</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation>Nivå:</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Spårarfel</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>Onåbar</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation>Tvinga återannonsera till valda spårare</translation>
    </message>
    <message>
        <source>Min Announce</source>
        <translation>Minimal annonsering</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>Tvinga återannonsera till alla spårare</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista över spårare att lägga till (en per rad):</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>Lägg till spårare</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 sedan</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Klar</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>Flyttar</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[T] Distribuerar</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>Distribuerar</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Köar</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>Fallerande</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[T] Hämtar</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>Hämtar metadata</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>Kontrollerar</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>Filer saknas</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>Köar för kontroll</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Hämtar</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>Kontrollerar återupptagningsdata</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>Avstannad</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (distribuerad i %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[T] Hämtar metadata</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>Stoppad</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Inte tillgängligt</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Spårare</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>Komprimera/expandera</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>Komprimera/expandera kategori</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Hastighetsgräns för torrenthämtning</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Hastighetsgräns för torrentsändning</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Byt namn</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>Begränsa delningskvot...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>Begränsa sändningshastighet...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>Begränsa hämtningshastighet...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Flytta upp</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Flytta ner</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Flytta överst</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Flytta nederst</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>Ange plats...</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>Hämta första och sista delarna först</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>Automatisk torrenthantering</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Ny...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Återställ</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>Tvinga återkontroll</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>Superdistributionsläge</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>Hämta i sekventiell ordning</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>Ange plats</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>Tvinga återannonsera</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>Redigera kategori</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>Kommaseparerade taggar:</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnetlänk</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>Ta bort alla</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Kö</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Lägg till...</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>Info-hash v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>Info-hash v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>Torrent-ID</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>Exportera .torrent</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>Byt namn på filer...</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>Byter namn</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>Tvinga start</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Plats:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>I automatiskt läge bestäms olika torrentegenskaper, till exempel sparsökvägen, av den tillhörande kategorin.</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Starta</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nytt namn:</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>Lägg till taggar</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation>Innehållssökväg</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Gränser för sändning/hämtning</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>Använd global delningsgräns</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>Ange ingen delningsgräns</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>Ställ in delningsgräns till</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>kvot</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>minuter totalt</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>minuter inaktiv</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>Ta bort torrent</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>Ta bort torrenten och dess innehåll</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>Stoppa torrent</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>Aktivera superdistribution för torrent</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation>Åtgärd när gränsen är nådd</translation>
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>Ta även bort innehållsfilerna</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Ta bort spårare</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>Hämta från URL:er</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Okänd</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 min</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 min</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1å %2d</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>Sparsökväg är tom</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>Insticksmodulsökväg:</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>URL eller lokal mapp</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>Installera insticksmodul</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>Distributioner:</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>Alla insticksmoduler</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>Sökinsticksmoduler...</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>Alla kategorier</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>Sök i:</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>Endast torrentnamn</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>Endast aktiverade</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>av</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>Överallt</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>Öka fönsterbredden för att visa ytterligare filter</translation>
    </message>
    <message>
        <source>to</source>
        <translation>till</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultat</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>visar</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>Klicka på knappen "Sök insticksmoduler..." längst ner till höger i fönstret för att installera några.</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>Det finns inga sökinsticksmoduler installerade.</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>Välj kategori</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>Min storlek prefix</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>Starta en sökning ovan.</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>Prefix för maxstorlek</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>Välj insticksmoduler</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>Avinstallera</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>Installera ny insticksmodul</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>Du kan skaffa nya sökmotorinsticksmoduler här:</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>Installerade sökinsticksmoduler:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiverad</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Varning: Var noga med att följa ditt lands upphovsrättslagar när du hämtar torrenter från någon av dessa sökmotorer.</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Sök efter uppdateringar</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>Sökinsticksmoduler</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>Reciprokörer</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>Distributörer</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>Publicerad den</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>Motor-URL</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>Motor</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiverad</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>Lägg till jämlikar</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>Lista över jämlikar att lägga till (en IP per rad):</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>Ny tagg</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>Lägg till tagg...</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>Tagg:</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>Ta bort oanvända taggar</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>Ogiltigt taggnamn</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>Ta bort tagg</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Starta torrenter</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stoppa torrenter</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>Utan taggar</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Felrapporter:</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>Forum:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-post:</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>Nuvarande underhållare</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>Webbplats:</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>Grekland</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>Särskilt tack</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>En avancerad BitTorrent-klient programmerad i C++, baserad på Qt-ramverket och libtorrent-rasterbar.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>Om qBittorrent</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>Översättare</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent byggdes med följande bibliotek:</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>Nationalitet:</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>Programvara som används</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>Den kostnadsfria databasen IP to Country Lite från DB-IP används för att fastställa vilka länder jämlikarna finns i. Databasen är licensierad enligt Creative Commons Erkännande 4.0 Internationell.</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Författare</translation>
    </message>
    <message>
        <source>France</source>
        <translation>Frankrike</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>qBittorrent-maskot</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>qBittorrent-ikon</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>Alla adresser</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>Alla IPv6-adresser</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>Alla IPv4-adresser</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Hämta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>Beskrivningssidans URL</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>Öppna beskrivningssidan</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>Hämtningslänk</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>Sökningen är klar</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>Ett fel uppstod under sökningen...</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>Stäng flik</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>Söker...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>Sökningen avbruten</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>Stäng alla flikar</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation>Uppdatera flik</translation>
    </message>
    <message>
        <source>Open download window</source>
        <translation>Öppna hämtningsfönstret</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation>Använd som söktext</translation>
    </message>
    <message>
        <source>Stop search</source>
        <translation>Stoppa sökning</translation>
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>Byter namn</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>Nytt namn:</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>Datum: </translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Välj ett nytt namn för detta RSS-flöde</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>Välj ett mappnamn</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>Nytt flödesnamn:</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>Uppdatera alla</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS-hämtare...</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>Markera poster som lästa</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>Uppdatera alla flöden</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>Kopiera flödets URL</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrenter: (dubbelklicka för att hämta)</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>Öppna nyhets-URL</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>Flödets URL:</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>Ny mapp...</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>Ny prenumeration</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>Mappnamn:</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>Ange en RSS-flödes-URL</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>Hämtning av RSS-flöden är nu inaktiverad. Du kan aktivera den i programinställningarna.</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>Borttagningsbekräftelse</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Är du säker på att du vill ta bort valda RSS-flöden?</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>Ny prenumeration...</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>Hämta torrent</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>Redigera flödes-URL...</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>Det går inte att uppdatera URL</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>URL är oförändrad</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>URL får inte vara tom</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>Öppna länk</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Upphovsman: </translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>Hämtningsregler</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>Matchande RSS-artiklar</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* matchar noll eller flera valfria tecken</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation> kommer att matcha alla artiklar.</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>Regler för avsnittsfilter:</translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Automatisk hämtning av RSS-torrenter är inaktiverad nu! Du kan aktivera den i programinställningar.</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>Regeldefinition</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>Spara till:</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>Använd reguljära uttryck</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>Namn på ny regel</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>Filtret måste avslutas med semikolon</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? matchar ett valfritt tecken</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>Matchar artiklar baserat på avsnittsfilter.</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>Tilldela kategori:</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regex-läge: använd Perl-kompatibla reguljära uttryck</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>| används som OR-operatör</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>Rensa hämtade avsnitt</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Mellanslag räknas som AND-operatorer (alla ord, valfri ordning)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>Ett uttryck med en tom %1-klausul (t.ex. %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>Exempel: </translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>Lägg till ny regel...</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Är du säker på att du vill rensa listan över hämtade avsnitt för den valda regeln?</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>Måste innehålla:</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Oändligt intervall: &lt;b&gt;1x25-;&lt;/b&gt; matchar avsnitt 25 och uppåt för säsong ett, och alla avsnitt av senare säsonger</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>Spara till en annan mapp</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>Får inte innehålla:</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Ensamma siffror: &lt;b&gt;1x25;&lt;/b&gt; matchar avsnitt 25 av säsong ett</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>Tre intervalltyper för avsnitt stöds: </translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Är du säker på att du vill ta bort de valda hämtningsreglerna?</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>Använd globala inställningar</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Vanligt intervall: &lt;b&gt;1x25-40;&lt;/b&gt; matchar avsnitt 25 till 40 i säsong ett</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>Ange det nya regelnamnet</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>Regelnamnbyte</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>Avsnittnummer är ett obligatoriskt positivt värde</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation> kommer att matcha avsnitten 2, 5, 8 till 15, 30 och framåt av säsong ett</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>Bekräfta borttagning av regel</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>Senaste matchning: %1 dagar sedan</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>Avsnittsfilter:</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>RSS-hämtare</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Säsongnummer är ett obligatoriskt värde som inte är noll</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>Tillämpa regel på flöden:</translation>
    </message>
    <message>
        <source> days</source>
        <translation> dagar</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>Använd smart avsnittsfilter</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Om ordföljden är viktig, använd * istället för blanksteg.</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>Ange namnet på den nya hämtningsregeln.</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>Jokerteckenläge: du kan använda</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation> kommer att utesluta alla artiklar.</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>Ta bort regel</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>Ignorera efterföljande matchningar för (0 för att inaktivera)</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>Byt namn på regel...</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>Senaste matchning: Okänd</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>Rensa hämtade avsnitt...</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>Smart avsnittsfilter kommer att kontrollera avsnittets nummer för att förhindra hämtning av dubbletter.
Stöder formaten: S01E01, 1x1, 2017.12.31 och 31.12.2017 (datumformatet stöder även - som avskiljare)</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Layout för torrentinnehåll:</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>Skapa undermapp</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>Skapa inte undermapp</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>Lägg till taggar:</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>Ta bort regel</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>Lägg till regel</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>Lägg till stoppad:</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation>Bekräftelse på att rensa hämtade avsnitt</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>Utan spårare</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>Starta torrenter</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>Ta bort spårare</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>Stoppa torrenter</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Spårarfel</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation>Annat fel</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS-flöden</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Oläst</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>Blockerad</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>visar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Loggtyp</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Rensa</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>Informationsmeddelanden</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>Varningsmeddelanden</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>Filtrera loggar</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>Blockerade IP-adresser</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>av</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>Tidsstämpel</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>Rensa alla</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Meddelande</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>Loggnivåer:</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Orsak</translation>
    </message>
    <message>
        <source>item</source>
        <translation>post</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>Bannad</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>Normala meddelanden</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>Kritisk</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>Kritiska meddelanden</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>items</source>
        <translation>poster</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultat</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>Välj loggnivå...</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>Är du säker på att du vill ta bort spåraren %1 från alla torrenter?</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>Det går inte att redigera kategori</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>Det går inte att skapa kategori</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>Det går inte att ange kategori</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>Sparsökväg för ofullständiga torrenter:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>Sparsökväg:</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Sökväg:</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>Använd en annan sökväg för ofullständiga torrenter:</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation>Kategorin finns inte</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>Domän</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>Hantera kakor</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>Lägg till kaka</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>Utgångsdatum</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Sökväg</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>Aktivera automatisk torrenthantering</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>Är du säker på att du vill aktivera automatisk torrenthantering för de valda torrenterna? De kan komma att flyttas.</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Är du säker på att du vill kontrollera den valda torrenten/de valda torrenterna igen?</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>Bekräftelse på återkontroll</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>Stäng flik</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>qBittorrent-webbanvändargränssnitt</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript krävs! Du måste aktivera JavaScript för att webbgränssnittet ska fungera korrekt</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Inloggning</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>Serversvar:</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>Det går inte att logga in, servern går förmodligen inte att nå.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Användarnamn</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>Felaktigt användarnamn eller lösenord.</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>Privat</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Källa</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>Köar</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>Det gick inte att skapa torrent.</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>Privat
                torrent (distribueras inte på DHT-nätverk)</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>Det går inte att exportera torrentfil</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>Skapa ny torrent</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Kommentarer:</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>Hämta torrent</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>Statusikon</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>URL:er för webbdistribution:</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Misslyckades</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Färdig</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>Felmeddelande</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>Justera till delgränsen för filer större
                än:</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>Välj fil/mapp att dela:</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>Delstorlek</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Framsteg</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>Slutförd</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>Hybrid</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>Det går inte att läsa in åtgärder för skapande av torrent</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>Optimera
                    justering</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Inte tillgängligt</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>URL:er för spårare:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>Är du säker på att du vill ta bort valda åtgärder?</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>Sökväg:</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>Skapa torrent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>Startad</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Webbdistribution</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>Börja
                distribuera
                direkt</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Torrentformat:</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>Källsökväg</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>Tillagd</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>Kör</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>Torrentskapare</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>Källa:</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Spårare</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>Delstorlek:</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>Fält</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>Ta bort åtgärd</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>Exportera torrent</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">Hämta</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>Magnetlänk</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>Lägg till torrentlänkar</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>En länk per rad (HTTP-länkar, magnetlänkar och info-hashar stöds)</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URLer</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>Lägg till torrentlänkar</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation>Gräns:</translation>
    </message>
    <message>
        <source>Speed limit</source>
        <translation>Hastighetsgräns</translation>
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>Sändningsgräns:</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>Hämtningsgräns:</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation>Storleksändra alla</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>Storleksändra</translation>
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation>Generera en API-nyckel? Denna nyckel kan användas för att interagera med qBittorrents API.</translation>
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation>Ta bort denna API-nyckel? Den aktuella nyckel kommer omedelbart att sluta fungera.</translation>
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation>Rotera denna API-nyckel? Den aktuella nyckeln kommer omedelbart att sluta fungera och en ny nyckel kommer att genereras.</translation>
    </message>
</context>
</TS>