<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh">
<context>
    <name>AboutDlg</name>
    <message>
        <source>About</source>
        <translation type="vanished">关于</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <source>Category:</source>
        <translation>分类：</translation>
    </message>
    <message>
        <source>Start torrent</source>
        <translation>开始 Torrent</translation>
    </message>
    <message>
        <source>Skip hash check</source>
        <translation>跳过哈希校验</translation>
    </message>
    <message>
        <source>Torrent Management Mode:</source>
        <translation>Torrent 管理模式：</translation>
    </message>
    <message>
        <source>Content layout:</source>
        <translation>内容布局：</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>原始</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>创建子文件夹</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>不创建子文件夹</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>手动</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>已收到元数据</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>文件已被检查</translation>
    </message>
    <message>
        <source>Stop condition:</source>
        <translation>停止条件：</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>添加到队列顶部</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>按顺序下载</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="vanished">大小：</translation>
    </message>
    <message>
        <source>Save at</source>
        <translation>保存在</translation>
    </message>
    <message>
        <source>Torrent information</source>
        <translation>Torrent 信息</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>保存路径：</translation>
    </message>
    <message>
        <source>Info hash v1:</source>
        <translation>信息哈希值 v1：</translation>
    </message>
    <message>
        <source>Rename torrent</source>
        <translation>重命名 torrent</translation>
    </message>
    <message>
        <source>Add torrent</source>
        <translation>添加种子</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>不可用</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <source>High</source>
        <translation>高</translation>
    </message>
    <message>
        <source>Torrent settings</source>
        <translation>Torrent 设置</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>正常</translation>
    </message>
    <message>
        <source>Save files to location:</source>
        <translation>保存文件到：</translation>
    </message>
    <message>
        <source>Set as default category</source>
        <translation>设置为默认分类</translation>
    </message>
    <message>
        <source>Limit upload rate</source>
        <translation>限制上传速率</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>过滤文件...</translation>
    </message>
    <message>
        <source>Add Torrent</source>
        <translation type="vanished">添加种子</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrent</source>
        <translation>对不完整的 Torrent 使用另一个路径</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>日期：</translation>
    </message>
    <message>
        <source>Save as .torrent file</source>
        <translation>保存为 .torrent 文件</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation>最高</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>不下载</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>先下载首尾文件块</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>注释：</translation>
    </message>
    <message>
        <source>Unable to download torrent file</source>
        <translation>无法下载 torrent 文件</translation>
    </message>
    <message>
        <source>Info hash v2:</source>
        <translation>信息哈希值 v2：</translation>
    </message>
    <message>
        <source>Tags:</source>
        <translation>标签：</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Limit download rate</source>
        <translation>限制下载速率</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 free</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>%1 needed · %2 free</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>Uncategorized</source>
        <translation>未分类</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <source>Add category...</source>
        <translation>添加分类...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation>移除分类</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation>移除未使用的分类</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>新建分类</translation>
    </message>
    <message>
        <source>Edit category...</source>
        <translation>编辑分类...</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>删除 Torrent</translation>
    </message>
    <message>
        <source>Add subcategory...</source>
        <translation>添加子分类...</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>启动 torrent</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>停止 torrent</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <source>Exit qBittorrent</source>
        <translation>退出 qBittorrent</translation>
    </message>
    <message>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>全局上传速度限制必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>全局下载速度限制必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>备用上传速度限制必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>备用下载速度限制必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>最大同时下载数必须大于 -1。</translation>
    </message>
    <message>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>最大同时上传数必须大于 -1。</translation>
    </message>
    <message>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>最大同时活动 torrent 必须大于 -1。</translation>
    </message>
    <message>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>最大连接数限制必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>每个 torrent 的最大连接数限制必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>每个 torrent 上传窗口数上限必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>更多信息</translation>
    </message>
    <message>
        <source>Information about certificates</source>
        <translation>证书信息</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>更改保存位置</translation>
    </message>
    <message>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周一</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周二</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周三</translation>
    </message>
    <message>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周四</translation>
    </message>
    <message>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周五</translation>
    </message>
    <message>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周六</translation>
    </message>
    <message>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>周日</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>注销</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>qBittorrent client is not reachable</source>
        <translation>无法访问 qBittorrent 客户端</translation>
    </message>
    <message>
        <source>Global number of upload slots limit must be greater than 0 or disabled.</source>
        <translation>全局上传窗口数上限必须大于 0 或禁用。</translation>
    </message>
    <message>
        <source>Invalid category name:\nPlease do not use any special characters in the category name.</source>
        <translation>无效的分类名：\n在分类名中请不要使用特殊字符。</translation>
    </message>
    <message>
        <source>Upload rate threshold must be greater than 0.</source>
        <translation>上传速率阈值必须大于 0。</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation>剩余磁盘空间：%1</translation>
    </message>
    <message>
        <source>Torrent inactivity timer must be greater than 0.</source>
        <translation>Torrent 非活动计时器必须大于 0。</translation>
    </message>
    <message>
        <source>Saving Management</source>
        <translation>保存管理</translation>
    </message>
    <message>
        <source>Download rate threshold must be greater than 0.</source>
        <translation>下载速率阈值必须大于 0。</translation>
    </message>
    <message>
        <source>Open documentation</source>
        <translation>打开文档</translation>
    </message>
    <message>
        <source>Register to handle magnet links...</source>
        <translation>注册以处理磁力链...</translation>
    </message>
    <message>
        <source>Unable to add peers. Please ensure you are adhering to the IP:port format.</source>
        <translation>无法添加对等节点。请确认你的格式符合 IP:端口 格式。</translation>
    </message>
    <message>
        <source>Name cannot be empty</source>
        <translation>名称不能为空</translation>
    </message>
    <message>
        <source>Name is unchanged</source>
        <translation>名称未改变</translation>
    </message>
    <message>
        <source>Failed to update name</source>
        <translation>更新名称失败</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>The port used for incoming connections must be between 0 and 65535.</source>
        <translation>用于传入连接的端口必须介于 0 和 65535 之间。</translation>
    </message>
    <message>
        <source>Original author</source>
        <translation>原始作者</translation>
    </message>
    <message>
        <source>The port used for the WebUI must be between 1 and 65535.</source>
        <translation>用于 WebUI 的端口必选在 1 和 65535 之间</translation>
    </message>
    <message>
        <source>%1 has been shutdown</source>
        <translation>%1 已被关闭</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript 是必需的！要让 WebUI 正确工作，你必须启用 JavaScript</translation>
    </message>
    <message>
        <source>External IP: N/A</source>
        <translation>外部 IP：N/A</translation>
    </message>
    <message>
        <source>Reverse proxy setup examples</source>
        <translation>反向代理设置示例</translation>
    </message>
    <message>
        <source>Could not contact qBittorrent</source>
        <translation>无法联系 qBittorrent</translation>
    </message>
    <message>
        <source>Remember choice</source>
        <translation>记住选择</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these %1 torrents from the transfer list?</source>
        <translation>您确定要从传输列表中删除这 %1 个 Torrent 吗？</translation>
    </message>
    <message>
        <source>Unable to delete torrents.</source>
        <translation>无法删除 torrents。</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>External IP: %1%2</source>
        <translation>外部 IP：%1%2</translation>
    </message>
    <message>
        <source>Edit web seed</source>
        <translation>编辑 web 种子</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from the transfer list?</source>
        <translation>您确定要从传输列表中删除 “%1” 吗？</translation>
    </message>
    <message>
        <source>Unable to set Auto Torrent Management for the selected torrents.</source>
        <translation>无法为所选 Torrent 设置自动 Torrent 管理。</translation>
    </message>
    <message>
        <source>Unable to stop torrents.</source>
        <translation>无法停止 torrents。</translation>
    </message>
    <message>
        <source>Unable to download file</source>
        <translation>无法下载文件</translation>
    </message>
    <message>
        <source>External IPs: %1, %2</source>
        <translation>外部 IP：%1, %2</translation>
    </message>
    <message>
        <source>Unable to recheck torrents.</source>
        <translation>无法重新校验 torrent。</translation>
    </message>
    <message>
        <source>List of web seeds to add (one per line):</source>
        <translation>添加 web 种子到列表（每行一个）：</translation>
    </message>
    <message>
        <source>Unable to start torrents.</source>
        <translation>无法开始 torrents。</translation>
    </message>
    <message>
        <source>Add web seeds</source>
        <translation>添加 web 种子</translation>
    </message>
    <message>
        <source>Unable to delete API key.</source>
        <translation>无法删除 API 密钥。</translation>
    </message>
    <message>
        <source>Seeding time limit must not have a negative value.</source>
        <translation>做种时间限制不能为负值</translation>
    </message>
    <message>
        <source>Share ratio limit must not have a negative value.</source>
        <translation>分享率限制不能为负值</translation>
    </message>
    <message>
        <source>Peer turnover interval must be greater than or equal to 0.</source>
        <translation>对等节点周转间隔必须大于等于 0</translation>
    </message>
    <message>
        <source>Unable to parse response.</source>
        <translation>无法解析响应</translation>
    </message>
    <message>
        <source>Unable to rotate API key.</source>
        <translation>无法重置 API key</translation>
    </message>
    <message>
        <source>Peer turnover must be between 0 and 100.</source>
        <translation>对等节点周转截止时间必须在 0 到 100 之间</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents must be greater than 0 and less than 1024.</source>
        <translation>检查种子时的剩余内存必须大于 0 并小于 1024</translation>
    </message>
    <message>
        <source>Unable to load program preferences, qBittorrent is probably unreachable.</source>
        <translation>无法加载程序首选项，可能无法抵达 qBittorrent</translation>
    </message>
    <message>
        <source>Peer turnover cutoff must be between 0 and 100.</source>
        <translation>对等节点周转截止时间必须在 0 到 100 之间。</translation>
    </message>
    <message>
        <source>Peer DSCP must be between 0 and 255.</source>
        <translation>对等节点 DSCP 必须在 0 到 255 之间。</translation>
    </message>
    <message>
        <source>Unable to save preferences, qBittorrent is probably unreachable.</source>
        <translation>无法保存偏好设置，qBittorrent 可能无法访问。</translation>
    </message>
    <message>
        <source>Unable to add torrents.</source>
        <translation>无法添加种子文件。</translation>
    </message>
    <message>
        <source>Error:</source>
        <translation>错误：</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <source>Options...</source>
        <translation>选项...</translation>
    </message>
    <message>
        <source>Top Toolbar</source>
        <translation>顶部工具栏</translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation>状态栏</translation>
    </message>
    <message>
        <source>Speed in Title Bar</source>
        <translation>在标题栏显示速度</translation>
    </message>
    <message>
        <source>Donate!</source>
        <translation>捐赠</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>统计</translation>
    </message>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>Add Torrent File...</source>
        <translation>添加 Torrent 文件...</translation>
    </message>
    <message>
        <source>Documentation</source>
        <translation>帮助文档</translation>
    </message>
    <message>
        <source>Add Torrent Link...</source>
        <translation>添加 Torrent 链接...</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <source>Global Upload Speed Limit</source>
        <translation>全局上传速度限制</translation>
    </message>
    <message>
        <source>Global Download Speed Limit</source>
        <translation>全局下载速度限制</translation>
    </message>
    <message>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>您确定要退出 qBittorrent 吗？</translation>
    </message>
    <message>
        <source>Alternative speed limits</source>
        <translation>备用速率限制</translation>
    </message>
    <message>
        <source>Search Engine</source>
        <translation>搜索引擎</translation>
    </message>
    <message>
        <source>Filter torrent list...</source>
        <translation>过滤 torrent 列表...</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>Transfers</source>
        <translation>传输</translation>
    </message>
    <message>
        <source>Move up in the queue</source>
        <translation>在队列中向上移动</translation>
    </message>
    <message>
        <source>Move Up Queue</source>
        <translation>向上移动队列</translation>
    </message>
    <message>
        <source>Bottom of Queue</source>
        <translation>队列底部</translation>
    </message>
    <message>
        <source>Move to the bottom of the queue</source>
        <translation>移动到队列底部</translation>
    </message>
    <message>
        <source>Top of Queue</source>
        <translation>队列顶部</translation>
    </message>
    <message>
        <source>Move Down Queue</source>
        <translation>向下移动队列</translation>
    </message>
    <message>
        <source>Move down in the queue</source>
        <translation>在队列中向下移动</translation>
    </message>
    <message>
        <source>Move to the top of the queue</source>
        <translation>移动到队列顶部</translation>
    </message>
    <message>
        <source>Your browser does not support this feature</source>
        <translation>您的浏览器不支持此功能</translation>
    </message>
    <message>
        <source>To use this feature, the WebUI needs to be accessed over HTTPS</source>
        <translation>要使用此功能，WebUI 需要通过 HTTPS 访问</translation>
    </message>
    <message>
        <source>Connection status: Firewalled</source>
        <translation>连接状态：有防火墙</translation>
    </message>
    <message>
        <source>Connection status: Connected</source>
        <translation>连接状态：连接正常</translation>
    </message>
    <message>
        <source>Alternative speed limits: Off</source>
        <translation>备用速度限制：关闭</translation>
    </message>
    <message>
        <source>Download speed icon</source>
        <translation>下载速度图标</translation>
    </message>
    <message>
        <source>Alternative speed limits: On</source>
        <translation>备用速度限制：开启</translation>
    </message>
    <message>
        <source>Upload speed icon</source>
        <translation>上传速度图标</translation>
    </message>
    <message>
        <source>Connection status: Disconnected</source>
        <translation>连接状态：断开连接</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS 阅读器</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Filters Sidebar</source>
        <translation>筛选器侧边栏</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Execution Log</source>
        <translation>执行日志</translation>
    </message>
    <message>
        <source>Log</source>
        <translation>日志</translation>
    </message>
    <message>
        <source>[D: %1, U: %2]</source>
        <translation>[D: %1, U: %2]</translation>
    </message>
    <message>
        <source>Filter by:</source>
        <translation>过滤依据：</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation>保存路径</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <source>Use regular expression</source>
        <translation>使用正则表达式</translation>
    </message>
    <message>
        <source>Would you like to start all torrents?</source>
        <translation>你要启动所有 torrent 吗？</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>启动</translation>
    </message>
    <message>
        <source>Manage Cookies...</source>
        <translation>管理 Cookies...</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>无法导出 torrent 文件</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Would you like to stop all torrents?</source>
        <translation>你要停止所有 torrent 吗？</translation>
    </message>
    <message>
        <source>Start All</source>
        <translation>全部启动</translation>
    </message>
    <message>
        <source>Stop All</source>
        <translation>全部停止</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>制作 Torrent</translation>
    </message>
    <message>
        <source>Filter feed items...</source>
        <translation>筛选源条目...</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>下载</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>连接</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <source>Email notification upon download completion</source>
        <translation>下载完成时发送电子邮件通知</translation>
    </message>
    <message>
        <source>IP Filtering</source>
        <translation>IP 过滤</translation>
    </message>
    <message>
        <source>Schedule the use of alternative rate limits</source>
        <translation>计划备用速度限制的启用时间</translation>
    </message>
    <message>
        <source>Torrent Queueing</source>
        <translation>Torrent 排队</translation>
    </message>
    <message>
        <source>Web User Interface (Remote control)</source>
        <translation>Web 用户界面（远程控制）</translation>
    </message>
    <message>
        <source>IP address:</source>
        <translation>IP 地址：</translation>
    </message>
    <message>
        <source>Server domains:</source>
        <translation>服务器域名：</translation>
    </message>
    <message>
        <source>Use HTTPS instead of HTTP</source>
        <translation>使用 HTTPS 而不是 HTTP</translation>
    </message>
    <message>
        <source>Bypass authentication for clients on localhost</source>
        <translation>对本地主机上的客户端跳过身份验证</translation>
    </message>
    <message>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>对 IP 子网白名单中的客户端跳过身份验证</translation>
    </message>
    <message>
        <source>Update my dynamic domain name</source>
        <translation>更新我的动态域名</translation>
    </message>
    <message>
        <source>Keep incomplete torrents in:</source>
        <translation>保存未完成的 torrent 到：</translation>
    </message>
    <message>
        <source>Copy .torrent files to:</source>
        <translation>复制 .torrent 文件到：</translation>
    </message>
    <message>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>复制下载完成的 .torrent 文件到：</translation>
    </message>
    <message>
        <source>Pre-allocate disk space for all files</source>
        <translation>为所有文件预分配磁盘空间</translation>
    </message>
    <message>
        <source>Append .!qB extension to incomplete files</source>
        <translation>为不完整的文件添加扩展名 .!qB</translation>
    </message>
    <message>
        <source>Automatically add torrents from:</source>
        <translation>自动从此处添加 torrent：</translation>
    </message>
    <message>
        <source>SMTP server:</source>
        <translation>SMTP 服务器：</translation>
    </message>
    <message>
        <source>This server requires a secure connection (SSL)</source>
        <translation>该服务器需要安全链接（SSL）</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>验证</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>用户名：</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>密码：</translation>
    </message>
    <message>
        <source>TCP and μTP</source>
        <translation>TCP 和 μTP</translation>
    </message>
    <message>
        <source>Listening Port</source>
        <translation>监听端口</translation>
    </message>
    <message>
        <source>Port used for incoming connections:</source>
        <translation>用于传入连接的端口：</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>使用我的路由器的 UPnP / NAT-PMP 端口转发</translation>
    </message>
    <message>
        <source>Connections Limits</source>
        <translation>连接限制</translation>
    </message>
    <message>
        <source>Maximum number of connections per torrent:</source>
        <translation>每 torrent 最大连接数：</translation>
    </message>
    <message>
        <source>Global maximum number of connections:</source>
        <translation>全局最大连接数：</translation>
    </message>
    <message>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>每个 torrent 上传窗口数上限：</translation>
    </message>
    <message>
        <source>Global maximum number of upload slots:</source>
        <translation>全局上传窗口数上限：</translation>
    </message>
    <message>
        <source>Proxy Server</source>
        <translation>代理服务器</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>类型：</translation>
    </message>
    <message>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation>主机：</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>端口：</translation>
    </message>
    <message>
        <source>Use proxy for peer connections</source>
        <translation>使用代理服务器进行用户连接</translation>
    </message>
    <message>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>过滤规则路径 (.dat, .p2p, .p2b)：</translation>
    </message>
    <message>
        <source>Manually banned IP addresses...</source>
        <translation>手动屏蔽 IP 地址...</translation>
    </message>
    <message>
        <source>Apply to trackers</source>
        <translation>匹配 tracker</translation>
    </message>
    <message>
        <source>Global Rate Limits</source>
        <translation>全局速度限制</translation>
    </message>
    <message>
        <source>Upload:</source>
        <translation>上传：</translation>
    </message>
    <message>
        <source>Download:</source>
        <translation>下载：</translation>
    </message>
    <message>
        <source>Alternative Rate Limits</source>
        <translation>备用速度限制</translation>
    </message>
    <message>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>从：</translation>
    </message>
    <message>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>到：</translation>
    </message>
    <message>
        <source>When:</source>
        <translation>时间：</translation>
    </message>
    <message>
        <source>Every day</source>
        <translation>每天</translation>
    </message>
    <message>
        <source>Weekdays</source>
        <translation>工作日</translation>
    </message>
    <message>
        <source>Weekends</source>
        <translation>周末</translation>
    </message>
    <message>
        <source>Rate Limits Settings</source>
        <translation>设置速度限制</translation>
    </message>
    <message>
        <source>Apply rate limit to transport overhead</source>
        <translation>对传送总开销进行速度限制</translation>
    </message>
    <message>
        <source>Apply rate limit to µTP protocol</source>
        <translation>对 µTP 协议进行速度限制</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>隐私</translation>
    </message>
    <message>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>启用 DHT (去中心化网络) 以找到更多用户</translation>
    </message>
    <message>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>启用用户交换 (PeX) 以找到更多用户</translation>
    </message>
    <message>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>启用本地用户发现以找到更多用户</translation>
    </message>
    <message>
        <source>Encryption mode:</source>
        <translation>加密模式：</translation>
    </message>
    <message>
        <source>Require encryption</source>
        <translation>强制加密</translation>
    </message>
    <message>
        <source>Disable encryption</source>
        <translation>禁用加密</translation>
    </message>
    <message>
        <source>Enable anonymous mode</source>
        <translation>启用匿名模式</translation>
    </message>
    <message>
        <source>Maximum active downloads:</source>
        <translation>最大活动的下载数：</translation>
    </message>
    <message>
        <source>Maximum active uploads:</source>
        <translation>最大活动的上传数：</translation>
    </message>
    <message>
        <source>Maximum active torrents:</source>
        <translation>最大活动的 torrent 数：</translation>
    </message>
    <message>
        <source>Do not count slow torrents in these limits</source>
        <translation>慢速 torrent 不计入限制内</translation>
    </message>
    <message>
        <source>then</source>
        <translation>然后</translation>
    </message>
    <message>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>使用我的路由器的 UPnP / NAT-PMP 功能来转发端口</translation>
    </message>
    <message>
        <source>Certificate:</source>
        <translation>证书：</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>密钥：</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>注册</translation>
    </message>
    <message>
        <source>Domain name:</source>
        <translation>域名：</translation>
    </message>
    <message>
        <source>Supported parameters (case sensitive):</source>
        <translation>支持的参数（区分大小写）：</translation>
    </message>
    <message>
        <source>%N: Torrent name</source>
        <translation>%N：Torrent 名称</translation>
    </message>
    <message>
        <source>%L: Category</source>
        <translation>%L：分类</translation>
    </message>
    <message>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F：内容路径（与多文件 torrent 的根目录相同）</translation>
    </message>
    <message>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R：根目录（第一个 torrent 的子目录路径）</translation>
    </message>
    <message>
        <source>%D: Save path</source>
        <translation>%D：保存路径</translation>
    </message>
    <message>
        <source>%C: Number of files</source>
        <translation>%C：文件数</translation>
    </message>
    <message>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z：Torrent 大小（字节）</translation>
    </message>
    <message>
        <source>%T: Current tracker</source>
        <translation>%T：当前 tracker</translation>
    </message>
    <message>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., "%N")</source>
        <translation>提示：使用引号将参数扩起以防止文本被空白符分割（例如："%N"）</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>分钟</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <source>Enable clickjacking protection</source>
        <translation>启用“点击劫持”保护</translation>
    </message>
    <message>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>启用跨站请求伪造 (CSRF) 保护</translation>
    </message>
    <message>
        <source>Delete .torrent files afterwards</source>
        <translation>完成后删除 .torrent 文件</translation>
    </message>
    <message>
        <source>Download rate threshold:</source>
        <translation>下载速度阈值：</translation>
    </message>
    <message>
        <source>Upload rate threshold:</source>
        <translation>上传速度阈值：</translation>
    </message>
    <message>
        <source>Change current password</source>
        <translation>修改当前密码</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Default Save Path:</source>
        <translation>默认保存路径：</translation>
    </message>
    <message>
        <source>Do not start the download automatically</source>
        <translation>不要自动开始下载</translation>
    </message>
    <message>
        <source>Switch torrent to Manual Mode</source>
        <translation>切换 Torrent 到手动模式</translation>
    </message>
    <message>
        <source>When Torrent Category changed:</source>
        <translation>当 Torrent 分类修改时：</translation>
    </message>
    <message>
        <source>Relocate affected torrents</source>
        <translation>重新定位受影响的 Torrent</translation>
    </message>
    <message>
        <source>Apply rate limit to peers on LAN</source>
        <translation>对本地网络用户进行速度限制</translation>
    </message>
    <message>
        <source>0 means unlimited</source>
        <translation>0 为无限制</translation>
    </message>
    <message>
        <source>Relocate torrent</source>
        <translation>重新定位 Torrent</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation>当默认保存路径修改时：</translation>
    </message>
    <message>
        <source>Enable Host header validation</source>
        <translation>启用 Host header 属性验证</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>验证</translation>
    </message>
    <message>
        <source>When Category Save Path changed:</source>
        <translation>当分类保存路径修改时：</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>秒</translation>
    </message>
    <message>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>切换受影响的 torrent 至手动模式</translation>
    </message>
    <message>
        <source>Files location:</source>
        <translation>文件路径：</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>手动</translation>
    </message>
    <message>
        <source>Torrent inactivity timer:</source>
        <translation>Torrent 非活动计时器：</translation>
    </message>
    <message>
        <source>Default Torrent Management Mode:</source>
        <translation>默认 Torrent 管理模式：</translation>
    </message>
    <message>
        <source>When adding a torrent</source>
        <translation>添加 torrent 时</translation>
    </message>
    <message>
        <source>μTP-TCP mixed mode algorithm:</source>
        <translation>μTP-TCP 混合模式策略:</translation>
    </message>
    <message>
        <source>Upload rate based</source>
        <translation>基于上传速度</translation>
    </message>
    <message>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G：标签（以逗号分隔）</translation>
    </message>
    <message>
        <source>Socket backlog size:</source>
        <translation>Socket backlog 大小:</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>为 torrent 启用超级做种</translation>
    </message>
    <message>
        <source>Prefer TCP</source>
        <translation>优先使用 TCP</translation>
    </message>
    <message>
        <source>Outstanding memory when checking torrents:</source>
        <translation>校验时内存使用扩增量:</translation>
    </message>
    <message>
        <source>Anti-leech</source>
        <translation>反吸血</translation>
    </message>
    <message>
        <source>When ratio reaches</source>
        <translation>当分享率达到</translation>
    </message>
    <message>
        <source>Allow multiple connections from the same IP address:</source>
        <translation>允许来自同一 IP 地址的多个连接:</translation>
    </message>
    <message>
        <source>File pool size:</source>
        <translation>文件池大小:</translation>
    </message>
    <message>
        <source>Any interface</source>
        <translation>任意网络接口</translation>
    </message>
    <message>
        <source>Always announce to all tiers:</source>
        <translation>总是向所有等级的 Tracker 汇报:</translation>
    </message>
    <message>
        <source>Embedded tracker port:</source>
        <translation>内置 tracker 端口:</translation>
    </message>
    <message>
        <source>Fastest upload</source>
        <translation>最快上传</translation>
    </message>
    <message>
        <source>Remove torrent and its files</source>
        <translation>删除 torrent 及所属文件</translation>
    </message>
    <message>
        <source>qBittorrent Section</source>
        <translation>qBittorrent 相关</translation>
    </message>
    <message>
        <source>Send buffer watermark factor:</source>
        <translation>发送缓冲区增长系数:</translation>
    </message>
    <message>
        <source>libtorrent Section</source>
        <translation>libtorrent 相关</translation>
    </message>
    <message>
        <source>Recheck torrents on completion:</source>
        <translation>完成后重新校验 Torrent:</translation>
    </message>
    <message>
        <source>Allow encryption</source>
        <translation>允许加密</translation>
    </message>
    <message>
        <source>Send upload piece suggestions:</source>
        <translation>发送分块上传建议:</translation>
    </message>
    <message>
        <source>Enable embedded tracker:</source>
        <translation>启用内置 Tracker:</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>删除 torrent</translation>
    </message>
    <message>
        <source>Asynchronous I/O threads:</source>
        <translation>异步 I/O 线程数:</translation>
    </message>
    <message>
        <source>Send buffer watermark:</source>
        <translation>发送缓冲区上限:</translation>
    </message>
    <message>
        <source>Peer proportional (throttles TCP)</source>
        <translation>按对等节点比重（抑制 TCP）</translation>
    </message>
    <message>
        <source>Fixed slots</source>
        <translation>固定窗口数</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>高级</translation>
    </message>
    <message>
        <source>min</source>
        <translation>分钟</translation>
    </message>
    <message>
        <source>Upload choking algorithm:</source>
        <translation>上传连接策略:</translation>
    </message>
    <message>
        <source>Seeding Limits</source>
        <translation>做种限制</translation>
    </message>
    <message>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <source>Round-robin</source>
        <translation>轮流上传</translation>
    </message>
    <message>
        <source>Upload slots behavior:</source>
        <translation>上传窗口策略:</translation>
    </message>
    <message>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Send buffer low watermark:</source>
        <translation>发送缓冲区下限:</translation>
    </message>
    <message>
        <source>Save resume data interval:</source>
        <translation>保存恢复数据间隔:</translation>
    </message>
    <message>
        <source>Always announce to all trackers in a tier:</source>
        <translation>总是向同级的所有 Tracker 汇报:</translation>
    </message>
    <message>
        <source>Session timeout:</source>
        <translation>会话超时：</translation>
    </message>
    <message>
        <source>Resolve peer countries:</source>
        <translation>解析对等节点所在国家：</translation>
    </message>
    <message>
        <source>ban for:</source>
        <translation>禁止：</translation>
    </message>
    <message>
        <source>Ban client after consecutive failures:</source>
        <translation>连续失败后禁止客户端：</translation>
    </message>
    <message>
        <source>Header: value pairs, one per line</source>
        <translation>Header: value 值对，每行一个</translation>
    </message>
    <message>
        <source>Add custom HTTP headers</source>
        <translation>添加自定义 HTTP headers</translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation>过滤器：</translation>
    </message>
    <message>
        <source>Enable fetching RSS feeds</source>
        <translation>启用获取 RSS 订阅</translation>
    </message>
    <message>
        <source>Peer turnover threshold percentage:</source>
        <translation>对等节点进出阈值百分比：</translation>
    </message>
    <message>
        <source>RSS Torrent Auto Downloader</source>
        <translation>RSS Torrent 自动下载器</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Network interface:</source>
        <translation>网络接口：</translation>
    </message>
    <message>
        <source>RSS Reader</source>
        <translation>RSS 阅读器</translation>
    </message>
    <message>
        <source>Edit auto downloading rules...</source>
        <translation>修改自动下载规则...</translation>
    </message>
    <message>
        <source>Download REPACK/PROPER episodes</source>
        <translation>下载 REPACK/PROPER 版剧集</translation>
    </message>
    <message>
        <source>Feeds refresh interval:</source>
        <translation>RSS 订阅源更新间隔：</translation>
    </message>
    <message>
        <source>Peer turnover disconnect percentage:</source>
        <translation>对等节点进出断开百分比：</translation>
    </message>
    <message>
        <source>Maximum number of articles per feed:</source>
        <translation>每个订阅源文章数目最大值：</translation>
    </message>
    <message>
        <source> min</source>
        <translation> 分钟</translation>
    </message>
    <message>
        <source>Peer turnover disconnect interval:</source>
        <translation>对等节点进出断开间隔：</translation>
    </message>
    <message>
        <source>Optional IP address to bind to:</source>
        <translation>绑定到的可选 IP 地址：</translation>
    </message>
    <message>
        <source>Disallow connection to peers on privileged ports:</source>
        <translation>禁止连接到特权端口上的 对等节点：</translation>
    </message>
    <message>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>启用 RSS Torrent 自动下载</translation>
    </message>
    <message>
        <source>RSS Smart Episode Filter</source>
        <translation>RSS 智能剧集过滤器</translation>
    </message>
    <message>
        <source>Validate HTTPS tracker certificate:</source>
        <translation>验证 HTTPS tracker 证书：</translation>
    </message>
    <message>
        <source>Peer connection protocol:</source>
        <translation>对等节点连接协议：</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Torrent 内容布局：</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>创建子文件夹</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>原始</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>不创建子文件夹</translation>
    </message>
    <message>
        <source>Outgoing connections per second:</source>
        <translation>每秒传出连接数：</translation>
    </message>
    <message>
        <source>Random</source>
        <translation>随机</translation>
    </message>
    <message>
        <source>%K: Torrent ID</source>
        <translation>%K: Torrent ID</translation>
    </message>
    <message>
        <source>Reannounce to all trackers when IP or port changed:</source>
        <translation>当 IP 或端口更改时，重新通知所有 trackers：</translation>
    </message>
    <message>
        <source>Trusted proxies list:</source>
        <translation>受信任的代理列表：</translation>
    </message>
    <message>
        <source>Enable reverse proxy support</source>
        <translation>启用反向代理支持</translation>
    </message>
    <message>
        <source>%J: Info hash v2</source>
        <translation>%J：信息哈希值 v2</translation>
    </message>
    <message>
        <source>%I: Info hash v1</source>
        <translation>%I: 信息哈希值 v1</translation>
    </message>
    <message>
        <source>IP address reported to trackers (requires restart):</source>
        <translation>IP 地址已报告给 Trackers (需要重启)</translation>
    </message>
    <message>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>设为 0，让系统选择一个未使用的端口</translation>
    </message>
    <message>
        <source>Server-side request forgery (SSRF) mitigation:</source>
        <translation>服务器端请求伪造（SSRF）攻击缓解：</translation>
    </message>
    <message>
        <source>Disk queue size:</source>
        <translation>磁盘队列大小：</translation>
    </message>
    <message>
        <source>Log performance warnings</source>
        <translation>记录性能警报</translation>
    </message>
    <message>
        <source>Maximum outstanding requests to a single peer:</source>
        <translation>单一 对等节点的最大未完成请求：</translation>
    </message>
    <message>
        <source>Max active checking torrents:</source>
        <translation>最大活跃检查 Torrent 数：</translation>
    </message>
    <message>
        <source>Memory mapped files</source>
        <translation>内存映射文件</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>POSIX-compliant</source>
        <translation>遵循 POSIX</translation>
    </message>
    <message>
        <source>It controls the internal state update interval which in turn will affect UI updates</source>
        <translation>它控制内部状态更新间隔，此间隔会影响用户界面更新</translation>
    </message>
    <message>
        <source>Disk IO read mode:</source>
        <translation>磁盘 IO 读取模式</translation>
    </message>
    <message>
        <source>Disable OS cache</source>
        <translation>禁用操作系统缓存</translation>
    </message>
    <message>
        <source>Disk IO write mode:</source>
        <translation>磁盘 IO 写入模式</translation>
    </message>
    <message>
        <source>Use piece extent affinity:</source>
        <translation>启用相连文件块下载模式：</translation>
    </message>
    <message>
        <source>Max concurrent HTTP announces:</source>
        <translation>最大并行 HTTP 汇报：</translation>
    </message>
    <message>
        <source>Enable OS cache</source>
        <translation>启用操作系统缓存</translation>
    </message>
    <message>
        <source>Refresh interval:</source>
        <translation>刷新间隔</translation>
    </message>
    <message>
        <source>ms</source>
        <translation>毫秒</translation>
    </message>
    <message>
        <source>Excluded file names</source>
        <translation>排除的文件名</translation>
    </message>
    <message>
        <source>Support internationalized domain name (IDN):</source>
        <translation>支持国际化域名（IDN）：</translation>
    </message>
    <message>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use ';' to split multiple entries. Can use wildcard '*'.</source>
        <translation>白名单用于过滤 HTTP 头的 Host 参数。
为了预防 DNS 反向绑定攻击，
您应当指定供 Web UI 使用的域名。

使用 ';' 区分不同的输入。可以使用通配符 '*'。</translation>
    </message>
    <message>
        <source>HTTPS certificate should not be empty</source>
        <translation>HTTPS 证书不能为空</translation>
    </message>
    <message>
        <source>Specify reverse proxy IPs (or subnets, e.g. 0.0.0.0/24) in order to use forwarded client address (X-Forwarded-For header). Use ';' to split multiple entries.</source>
        <translation>指定反向代理 IP（或子网，如 0.0.0.0/24）以使用转发的客户端地址（X-Forwarded-For 标头）。使用 “;” 符号分割多个条目。</translation>
    </message>
    <message>
        <source>HTTPS key should not be empty</source>
        <translation>HTTPS 密钥不能为空</translation>
    </message>
    <message>
        <source>Run external program</source>
        <translation>运行外部程序</translation>
    </message>
    <message>
        <source>Files checked</source>
        <translation>文件已被检查</translation>
    </message>
    <message>
        <source>Enable port forwarding for embedded tracker:</source>
        <translation>对嵌入的 tracker 启用端口转发</translation>
    </message>
    <message>
        <source>If checked, hostname lookups are done via the proxy.</source>
        <translation>勾选后将通过代理查找主机名</translation>
    </message>
    <message>
        <source>Metadata received</source>
        <translation>已收到元数据</translation>
    </message>
    <message>
        <source>Torrent stop condition:</source>
        <translation>Torrent 停止条件：</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>示例：172.17.32.0/24，fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <source>SQLite database (experimental)</source>
        <translation>SQLite 数据库（实验性功能）</translation>
    </message>
    <message>
        <source>Resume data storage type (requires restart):</source>
        <translation>恢复数据存储类型（需要重新启动）：</translation>
    </message>
    <message>
        <source>Fastresume files</source>
        <translation>快速恢复文件</translation>
    </message>
    <message>
        <source>Backup the log file after:</source>
        <translation>当大于指定大小时备份日志文件：</translation>
    </message>
    <message>
        <source>days</source>
        <translation>天</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>行为</translation>
    </message>
    <message>
        <source>Delete backup logs older than:</source>
        <translation>删除早于指定时间的备份日志文件：</translation>
    </message>
    <message>
        <source>Use proxy for BitTorrent purposes</source>
        <translation>对 BitTorrent 目的使用代理</translation>
    </message>
    <message>
        <source>years</source>
        <translation>年</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>保存路径：</translation>
    </message>
    <message>
        <source>months</source>
        <translation>月</translation>
    </message>
    <message>
        <source>Remember Multi-Rename settings</source>
        <translation>记住多重命名设置</translation>
    </message>
    <message>
        <source>Use proxy for general purposes</source>
        <translation>对常规目的使用代理</translation>
    </message>
    <message>
        <source>Use proxy for RSS purposes</source>
        <translation>对 RSS 目的使用代理</translation>
    </message>
    <message>
        <source>Socket send buffer size [0: system default]:</source>
        <translation>套接字发送缓存大小 [0: 系统默认值]：</translation>
    </message>
    <message>
        <source>Outgoing ports (Max) [0: disabled]:</source>
        <translation>传出端口（上限）[0: 禁用]：</translation>
    </message>
    <message>
        <source>Socket receive buffer size [0: system default]:</source>
        <translation>套接字接收缓存大小 [0: 系统默认值]：</translation>
    </message>
    <message>
        <source>Add to top of queue</source>
        <translation>添加到队列顶部</translation>
    </message>
    <message>
        <source>Stop tracker timeout [0: disabled]:</source>
        <translation>停止 tracker 超时 [0: 禁用]：</translation>
    </message>
    <message>
        <source>Outgoing ports (Min) [0: disabled]:</source>
        <translation>传出端口 (下限) [0: 禁用]:</translation>
    </message>
    <message>
        <source>UPnP lease duration [0: permanent lease]:</source>
        <translation>UPnP 租期 [0：永久 ]：</translation>
    </message>
    <message>
        <source>Bdecode depth limit:</source>
        <translation>Bdecode 深度限制</translation>
    </message>
    <message>
        <source>Bdecode token limit:</source>
        <translation>Bdecode 令牌限制</translation>
    </message>
    <message>
        <source>When total seeding time reaches</source>
        <translation>达到总做种时间时</translation>
    </message>
    <message>
        <source>(None)</source>
        <translation>(无)</translation>
    </message>
    <message>
        <source>Python executable path (may require restart):</source>
        <translation>Python 可执行文件路径（可能需要重启）：</translation>
    </message>
    <message>
        <source>Resets to default if empty</source>
        <translation>如果为空，则重置为默认值</translation>
    </message>
    <message>
        <source>Perform hostname lookup via proxy</source>
        <translation>通过代理查找主机名</translation>
    </message>
    <message>
        <source>If &amp;quot;mixed mode&amp;quot; is enabled, I2P torrents are allowed to also get peers from other sources than the tracker, and connect to regular IPs, not providing any anonymization. This may be useful if the user is not interested in the anonymization of I2P, but still wants to be able to connect to I2P peers.</source>
        <translation>如启用 “混合模式”，则 I2P Torrent 也被允许从 Tracker 之外的来源获得对等节点，并连接到正常的 IP 地址，这样的结果不提供任何的匿名性。对 I2P 匿名性不在意，但让仍希望能连接到 I2P 对等节点的用户来说，此模式会有用处。</translation>
    </message>
    <message>
        <source>DHT bootstrap nodes:</source>
        <translation>DHT Bootstrap 节点：</translation>
    </message>
    <message>
        <source>When inactive seeding time reaches</source>
        <translation>达到不活跃做种时间时</translation>
    </message>
    <message>
        <source>Mixed mode</source>
        <translation>混合模式</translation>
    </message>
    <message>
        <source>.torrent file size limit:</source>
        <translation>.torrent 文件大小限制</translation>
    </message>
    <message>
        <source>(Auto detect if empty)</source>
        <translation>（假如为空，自动检测）</translation>
    </message>
    <message>
        <source>Keep unselected files in ".unwanted" folder</source>
        <translation>将未选中的文件保留在 ".unwanted" 文件夹中</translation>
    </message>
    <message>
        <source>Enable Mark-of-the-Web (MOTW) for downloaded files (require macOS or Windows):</source>
        <translation>开启已下载文件 Mark-of-the-Web (MOTW)（需要 macOS 或 Windows 系统）：</translation>
    </message>
    <message>
        <source> sec</source>
        <translation>秒</translation>
    </message>
    <message>
        <source>I2P outbound quantity:</source>
        <translation>I2P 传出量：</translation>
    </message>
    <message>
        <source>I2P inbound quantity:</source>
        <translation>I2P 传入量：</translation>
    </message>
    <message>
        <source>Hashing threads:</source>
        <translation>散列线程</translation>
    </message>
    <message>
        <source>Physical memory (RAM) usage limit:</source>
        <translation>物理内存（RAM）使用限制：</translation>
    </message>
    <message>
        <source>Use alternative WebUI</source>
        <translation>使用备选 WebUI</translation>
    </message>
    <message>
        <source>Disk cache expiry interval:</source>
        <translation>磁盘缓存到期间隔:</translation>
    </message>
    <message>
        <source>I2P outbound length:</source>
        <translation>I2P 传出长度：</translation>
    </message>
    <message>
        <source>I2P (Experimental)</source>
        <translation>I2P（实验性）</translation>
    </message>
    <message>
        <source>Disk IO type (requires restart):</source>
        <translation>磁盘 IO 类型（需要重启）</translation>
    </message>
    <message>
        <source>The alternative WebUI files location cannot be blank.</source>
        <translation>备选的 WebUI 文件位置不能为空</translation>
    </message>
    <message>
        <source>Disk cache:</source>
        <translation>磁盘缓存:</translation>
    </message>
    <message>
        <source>Write-through</source>
        <translation>连续写入</translation>
    </message>
    <message>
        <source>WebUI</source>
        <translation>WebUI</translation>
    </message>
    <message>
        <source>The WebUI password must be at least 6 characters long.</source>
        <translation>WebUI 密码长度至少为6个字符</translation>
    </message>
    <message>
        <source>Coalesce reads &amp;amp; writes:</source>
        <translation>合并读取 &amp;amp;写入：</translation>
    </message>
    <message>
        <source>I2P inbound length:</source>
        <translation>I2P 传入长度：</translation>
    </message>
    <message>
        <source>The WebUI username must be at least 3 characters long.</source>
        <translation>WebUI 用户名长度至少为3个字符</translation>
    </message>
    <message>
        <source>Same host request delay:</source>
        <translation>相同的主机请求延迟：</translation>
    </message>
    <message>
        <source>Customize application instance name:</source>
        <translation>定制程序实例名</translation>
    </message>
    <message>
        <source>Color scheme:</source>
        <translation>配色方案：</translation>
    </message>
    <message>
        <source>Show external IP in status bar</source>
        <translation>在状态栏展示外部 IP</translation>
    </message>
    <message>
        <source>Fetched trackers</source>
        <translation>获取 tracker</translation>
    </message>
    <message>
        <source>Confirm when deleting torrents</source>
        <translation>删除 Torrent 时提示确认</translation>
    </message>
    <message>
        <source>Ignore SSL errors:</source>
        <translation>忽略 SSL 错误：</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>深色</translation>
    </message>
    <message>
        <source>Delete files permanently</source>
        <translation>永久删除文件</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Use alternating row colors</source>
        <translation>使用交替的行颜色</translation>
    </message>
    <message>
        <source>Display full announce URL in the Tracker column</source>
        <translation>在Tracker 栏目展示完整的公告URL</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation>网址：</translation>
    </message>
    <message>
        <source>Transfer list</source>
        <translation>传输列表</translation>
    </message>
    <message>
        <source>The announce port must be between 0 and 65535.</source>
        <translation>公告端口必须为 0 到 65535 之间。</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <source>Automatically append these trackers to new downloads:</source>
        <translation>自动附加这些 tracker 到新下载：</translation>
    </message>
    <message>
        <source>Downloading torrents:</source>
        <translation>正在下载的 torrent：</translation>
    </message>
    <message>
        <source>Start / stop torrent</source>
        <translation>开始 / 停止 torrent</translation>
    </message>
    <message>
        <source>Send test email</source>
        <translation>发送测试邮件</translation>
    </message>
    <message>
        <source>Completed torrents:</source>
        <translation>完成的 torrent：</translation>
    </message>
    <message>
        <source>Enable cookie Secure flag (requires HTTPS or localhost connection)</source>
        <translation>启用 cookie 安全标志（需要 HTTPS或本地连接）</translation>
    </message>
    <message>
        <source>Action on double-click</source>
        <translation>双击执行操作</translation>
    </message>
    <message>
        <source>Save statistics interval:</source>
        <translation>保存统计数据间隔：</translation>
    </message>
    <message>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>删除 Torrent 时显示确认对话框</translation>
    </message>
    <message>
        <source>Run on torrent finished:</source>
        <translation>torrent 完成时运行：</translation>
    </message>
    <message>
        <source>Attempted to send email. Check your inbox to confirm success</source>
        <translation>已尝试发送邮件。检查你的收件箱确认是否发送成功</translation>
    </message>
    <message>
        <source>Automatically append trackers from URL to new downloads:</source>
        <translation>自动添加 URL 中的 trackers 到新的下载：</translation>
    </message>
    <message>
        <source>Torrent content removing mode:</source>
        <translation>Torrent 内容删除模式：</translation>
    </message>
    <message>
        <source>Move files to trash (if possible)</source>
        <translation>移动文件到回收站（如果可能）</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>停止 torrent</translation>
    </message>
    <message>
        <source>Use Category paths in Manual Mode</source>
        <translation>在手动模式下使用分类路径</translation>
    </message>
    <message>
        <source>List of alternative WebUI</source>
        <translation>备选 WebUI 列表</translation>
    </message>
    <message>
        <source>Run on torrent added:</source>
        <translation>新增 Torrent 时运行：</translation>
    </message>
    <message>
        <source>Port reported to trackers (requires restart) [0: listening port]:</source>
        <translation>报告给 trackers的端口（需要重启）[0：监听端口]:</translation>
    </message>
    <message>
        <source>User interface language:</source>
        <translation>用户界面语言：</translation>
    </message>
    <message>
        <source>Merge trackers to existing torrent</source>
        <translation>合并 tracker 到现有 torrent</translation>
    </message>
    <message>
        <source>Confirm torrent recheck:</source>
        <translation> Torrent 重新校验确认：</translation>
    </message>
    <message>
        <source>Custom WebUI settings</source>
        <translation>自定义 WebUI 设置</translation>
    </message>
    <message>
        <source>Following settings are WebUI only</source>
        <translation>以下设置仅适用于 WebUI</translation>
    </message>
    <message>
        <source>Simple pread/pwrite</source>
        <translation>简单预读/预写</translation>
    </message>
    <message>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>根据适当的分类路径而不是默认路径解析相对的保存路径</translation>
    </message>
    <message>
        <source>No action</source>
        <translation>不执行操作</translation>
    </message>
    <message>
        <source>Auto hide zero status filters</source>
        <translation>自动隐藏零状态过滤器</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>界面</translation>
    </message>
    <message>
        <source>Log Files</source>
        <translation>日志文件</translation>
    </message>
    <message>
        <source>Enable optimized table rendering (experimental)</source>
        <translation>启用优化的表格渲染（实验性）</translation>
    </message>
    <message>
        <source>Note: The password is saved unencrypted</source>
        <translation>注意：密码以非加密形式保存</translation>
    </message>
    <message>
        <source>Internal hostname resolver cache expiry interval</source>
        <translation>内部主机名解析器缓存过期间隔</translation>
    </message>
    <message>
        <source>sec</source>
        <translation>秒</translation>
    </message>
    <message>
        <source>Rotate API key</source>
        <translation>重置 API key</translation>
    </message>
    <message>
        <source>Generate a key</source>
        <translation>生成密钥</translation>
    </message>
    <message>
        <source>When adding a duplicate torrent</source>
        <translation>添加重复种子时</translation>
    </message>
    <message>
        <source>Delete API key</source>
        <translation>删除 API 密钥</translation>
    </message>
    <message>
        <source>%M: Comment</source>
        <translation>%M：注释</translation>
    </message>
    <message>
        <source>Generate API key</source>
        <translation>生成 API 密钥</translation>
    </message>
    <message>
        <source>Copied</source>
        <translation>已复制</translation>
    </message>
    <message>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>Reset filter selection</source>
        <translation>重置筛选器选择</translation>
    </message>
    <message>
        <source>API Key</source>
        <translation>API 密钥</translation>
    </message>
    <message>
        <source>Copy API key</source>
        <translation>复制 API 密钥</translation>
    </message>
    <message>
        <source>Differentiated Services Code Point (DSCP) for connections to peers</source>
        <translation>与对等节点连接的区分服务代码点 (DSCP)</translation>
    </message>
    <message>
        <source>The WebUI username must not contain a colon.</source>
        <translation>WebUI 用户名不得包含冒号。</translation>
    </message>
    <message>
        <source>Date format:</source>
        <translation>日期格式：</translation>
    </message>
    <message>
        <source>Browser default</source>
        <translation>浏览器默认</translation>
    </message>
    <message>
        <source>Localization</source>
        <translation>本地化</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>紧凑</translation>
    </message>
    <message>
        <source>Display density:</source>
        <translation>显示密度：</translation>
    </message>
    <message>
        <source>It appends the text to the window title to help distinguish qBittorrent instances</source>
        <translation>它将文本附加到窗口标题来区分不同的 qBittorrent 实例</translation>
    </message>
    <message>
        <source>Resolve peer host names:</source>
        <translation>解析对等主机名：</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>标志</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>连接</translation>
    </message>
    <message>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>客户端</translation>
    </message>
    <message>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>进度</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>下载速度</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>上传速度</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>已下载</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>已上传</translation>
    </message>
    <message>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don't.</comment>
        <translation>文件关联</translation>
    </message>
    <message>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>文件</translation>
    </message>
    <message>
        <source>Ban peer permanently</source>
        <translation>永久禁止用户</translation>
    </message>
    <message>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>您确定要永久禁止所选的用户吗？</translation>
    </message>
    <message>
        <source>Copy IP:port</source>
        <translation>复制 IP:端口</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>国家/地区</translation>
    </message>
    <message>
        <source>Add peers...</source>
        <translation>添加对等节点...</translation>
    </message>
    <message>
        <source>Peer ID Client</source>
        <translation>对等节点 ID 客户端</translation>
    </message>
    <message>
        <source>IP/Address</source>
        <translation>IP/地址</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>正常</translation>
    </message>
    <message>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>较高</translation>
    </message>
    <message>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>最高</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>混合的</translation>
    </message>
    <message>
        <source>Do not download</source>
        <translation>不下载</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <source>General</source>
        <translation>普通</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>HTTP Sources</source>
        <translation>HTTP 源</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>内容</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Downloaded:</source>
        <translation>已下载：</translation>
    </message>
    <message>
        <source>Transfer</source>
        <translation>传输</translation>
    </message>
    <message>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>活动时间：</translation>
    </message>
    <message>
        <source>ETA:</source>
        <translation>剩余时间：</translation>
    </message>
    <message>
        <source>Uploaded:</source>
        <translation>已上传：</translation>
    </message>
    <message>
        <source>Seeds:</source>
        <translation>种子：</translation>
    </message>
    <message>
        <source>Download Speed:</source>
        <translation>下载速度：</translation>
    </message>
    <message>
        <source>Upload Speed:</source>
        <translation>上传速度：</translation>
    </message>
    <message>
        <source>Peers:</source>
        <translation>用户：</translation>
    </message>
    <message>
        <source>Download Limit:</source>
        <translation>下载限制：</translation>
    </message>
    <message>
        <source>Upload Limit:</source>
        <translation>上传限制：</translation>
    </message>
    <message>
        <source>Wasted:</source>
        <translation>已丢弃：</translation>
    </message>
    <message>
        <source>Connections:</source>
        <translation>连接：</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>注释：</translation>
    </message>
    <message>
        <source>Share Ratio:</source>
        <translation>分享率：</translation>
    </message>
    <message>
        <source>Reannounce In:</source>
        <translation>下次汇报：</translation>
    </message>
    <message>
        <source>Last Seen Complete:</source>
        <translation>最后完整可见：</translation>
    </message>
    <message>
        <source>Total Size:</source>
        <translation>总大小：</translation>
    </message>
    <message>
        <source>Pieces:</source>
        <translation>区块：</translation>
    </message>
    <message>
        <source>Created By:</source>
        <translation>创建：</translation>
    </message>
    <message>
        <source>Added On:</source>
        <translation>添加于：</translation>
    </message>
    <message>
        <source>Completed On:</source>
        <translation>完成于：</translation>
    </message>
    <message>
        <source>Created On:</source>
        <translation>创建于：</translation>
    </message>
    <message>
        <source>Save Path:</source>
        <translation>保存路径：</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>从不</translation>
    </message>
    <message>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (已完成 %3)</translation>
    </message>
    <message>
        <source>%1 (%2 this session)</source>
        <translation>%1 (本次会话 %2)</translation>
    </message>
    <message>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (最大 %2)</translation>
    </message>
    <message>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (总计 %2)</translation>
    </message>
    <message>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (平均 %2)</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <source>Filter files...</source>
        <translation>过滤文件...</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>重命名...</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (已做种 %2)</translation>
    </message>
    <message>
        <source>Info Hash v2:</source>
        <translation>信息哈希值 v2：</translation>
    </message>
    <message>
        <source>Info Hash v1:</source>
        <translation>信息哈希值 v1：</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>进度：</translation>
    </message>
    <message>
        <source>Use regular expressions</source>
        <translation>使用正则表达式</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Filename + Extension</source>
        <translation>文件名+扩展名</translation>
    </message>
    <message>
        <source>Enumerate Files</source>
        <translation>枚举文件</translation>
    </message>
    <message>
        <source>Rename failed: file or folder already exists</source>
        <translation>重命名失败：文件或文件夹已存在</translation>
    </message>
    <message>
        <source>Toggle Selection</source>
        <translation>切换所选</translation>
    </message>
    <message>
        <source>Replacement Input</source>
        <translation>替换输入</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>替换</translation>
    </message>
    <message>
        <source>Extension</source>
        <translation>扩展名</translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation>替换全部</translation>
    </message>
    <message>
        <source>Include files</source>
        <translation>包含文件</translation>
    </message>
    <message>
        <source>Include folders</source>
        <translation>包含文件夹</translation>
    </message>
    <message>
        <source>Search Files</source>
        <translation>搜索文件</translation>
    </message>
    <message>
        <source>Case sensitive</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <source>Match all occurrences</source>
        <translation>匹配所有出现</translation>
    </message>
    <message>
        <source>Copy web seed URL</source>
        <translation>复制 Web 种子 URL</translation>
    </message>
    <message>
        <source>Replace option</source>
        <translation>替换选项</translation>
    </message>
    <message>
        <source>Edit web seed URL...</source>
        <translation>编辑 Web 种子 URL...</translation>
    </message>
    <message>
        <source>Web seed URL:</source>
        <translation>Web 种子 URL：</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>Ratio / Time Active (in months), indicates how popular the torrent is</source>
        <translation>分享率/活跃时间（月份为单位），表明 torrent 的流行度</translation>
    </message>
    <message>
        <source>Popularity:</source>
        <translation>流行度：</translation>
    </message>
    <message>
        <source>Apply to which filename part</source>
        <translation>应用于文件名的哪个部分</translation>
    </message>
    <message>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <source>Remove web seed</source>
        <translation>移除 Web 种子</translation>
    </message>
    <message>
        <source>Web seed editing</source>
        <translation>编辑 Web 种子</translation>
    </message>
    <message>
        <source>Add web seeds...</source>
        <translation>添加 web 种子...</translation>
    </message>
    <message>
        <source>Private:</source>
        <translation>私密：</translation>
    </message>
    <message>
        <source>Availability:</source>
        <translation>可用性：</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <source>Monitored Folder</source>
        <translation>监控文件夹</translation>
    </message>
    <message>
        <source>Override Save Location</source>
        <translation>覆盖保存位置</translation>
    </message>
    <message>
        <source>Monitored folder</source>
        <translation>监控文件夹</translation>
    </message>
    <message>
        <source>Default save location</source>
        <translation>默认保存位置</translation>
    </message>
    <message>
        <source>Other...</source>
        <translation>其他...</translation>
    </message>
    <message>
        <source>Type folder here</source>
        <translation>在此处输入文件夹</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <source>Statistics</source>
        <translation>统计</translation>
    </message>
    <message>
        <source>User statistics</source>
        <translation>用户统计</translation>
    </message>
    <message>
        <source>Cache statistics</source>
        <translation>缓存统计</translation>
    </message>
    <message>
        <source>Read cache hits:</source>
        <translation>读缓存次数：</translation>
    </message>
    <message>
        <source>Average time in queue:</source>
        <translation>在队列的平均时间：</translation>
    </message>
    <message>
        <source>Connected peers:</source>
        <translation>连接用户：</translation>
    </message>
    <message>
        <source>All-time share ratio:</source>
        <translation>历史分享率：</translation>
    </message>
    <message>
        <source>All-time download:</source>
        <translation>历史下载：</translation>
    </message>
    <message>
        <source>Session waste:</source>
        <translation>本次对话丢弃：</translation>
    </message>
    <message>
        <source>All-time upload:</source>
        <translation>历史上传：</translation>
    </message>
    <message>
        <source>Total buffer size:</source>
        <translation>总缓冲大小：</translation>
    </message>
    <message>
        <source>Performance statistics</source>
        <translation>性能统计</translation>
    </message>
    <message>
        <source>Queued I/O jobs:</source>
        <translation>队列的 I/O 任务：</translation>
    </message>
    <message>
        <source>Write cache overload:</source>
        <translation>写入缓存超负荷：</translation>
    </message>
    <message>
        <source>Read cache overload:</source>
        <translation>读取缓存超负荷：</translation>
    </message>
    <message>
        <source>Total queued size:</source>
        <translation>总队列大小：</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>DHT: %1 nodes</source>
        <translation>DHT：%1 结点</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>全部 (0)</translation>
    </message>
    <message>
        <source>Downloading (0)</source>
        <translation>下载 (0)</translation>
    </message>
    <message>
        <source>Seeding (0)</source>
        <translation>做种 (0)</translation>
    </message>
    <message>
        <source>Completed (0)</source>
        <translation>完成 (0)</translation>
    </message>
    <message>
        <source>Active (0)</source>
        <translation>活动 (0)</translation>
    </message>
    <message>
        <source>Inactive (0)</source>
        <translation>空闲 (0)</translation>
    </message>
    <message>
        <source>Errored (0)</source>
        <translation>错误 (0)</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <translation>全部 (%1)</translation>
    </message>
    <message>
        <source>Downloading (%1)</source>
        <translation>下载 (%1)</translation>
    </message>
    <message>
        <source>Seeding (%1)</source>
        <translation>做种 (%1)</translation>
    </message>
    <message>
        <source>Completed (%1)</source>
        <translation>完成 (%1)</translation>
    </message>
    <message>
        <source>Active (%1)</source>
        <translation>活动 (%1)</translation>
    </message>
    <message>
        <source>Inactive (%1)</source>
        <translation>空闲 (%1)</translation>
    </message>
    <message>
        <source>Errored (%1)</source>
        <translation>错误 (%1)</translation>
    </message>
    <message>
        <source>Stalled Uploading (%1)</source>
        <translation>上传已暂停 (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (%1)</source>
        <translation>下载已暂停 (%1)</translation>
    </message>
    <message>
        <source>Stalled Downloading (0)</source>
        <translation>暂停下载 (0)</translation>
    </message>
    <message>
        <source>Stalled (0)</source>
        <translation>暂停 (0)</translation>
    </message>
    <message>
        <source>Stalled Uploading (0)</source>
        <translation>上传已暂停 (0)</translation>
    </message>
    <message>
        <source>Stalled (%1)</source>
        <translation>暂停 (%1)</translation>
    </message>
    <message>
        <source>Checking (%1)</source>
        <translation>正在检查 (%1)</translation>
    </message>
    <message>
        <source>Checking (0)</source>
        <translation>正在检查 (0)</translation>
    </message>
    <message>
        <source>Moving (%1)</source>
        <translation>正在移动 (%1)</translation>
    </message>
    <message>
        <source>Moving (0)</source>
        <translation>正在移动 (0)</translation>
    </message>
    <message>
        <source>Running (0)</source>
        <translation>正运行 (0)</translation>
    </message>
    <message>
        <source>Stopped (0)</source>
        <translation>已停止 (0)</translation>
    </message>
    <message>
        <source>Stopped (%1)</source>
        <translation>已停止 (%1)</translation>
    </message>
    <message>
        <source>Running (%1)</source>
        <translation>正运行 (%1)</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>删除 Torrent</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>启动 torrent</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>停止 torrent</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>名称</translation>
    </message>
    <message>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>选定大小</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>状态</translation>
    </message>
    <message>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>种子</translation>
    </message>
    <message>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>用户</translation>
    </message>
    <message>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>下载速度</translation>
    </message>
    <message>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>上传速度</translation>
    </message>
    <message>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>比率</translation>
    </message>
    <message>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>剩余时间</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>分类</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>添加于</translation>
    </message>
    <message>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>完成于</translation>
    </message>
    <message>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>下载限制</translation>
    </message>
    <message>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>上传限制</translation>
    </message>
    <message>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>已下载</translation>
    </message>
    <message>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>已上传</translation>
    </message>
    <message>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>剩余</translation>
    </message>
    <message>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>有效时间</translation>
    </message>
    <message>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>保存路径</translation>
    </message>
    <message>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>完成</translation>
    </message>
    <message>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>比率限制</translation>
    </message>
    <message>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>最后完整可见</translation>
    </message>
    <message>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>最后活动</translation>
    </message>
    <message>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>总大小</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>可用性</translation>
    </message>
    <message>
        <source>Reannounce In</source>
        <translation>下次重新汇报</translation>
    </message>
    <message>
        <source>Private</source>
        <translation>私密</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <source>Info Hash v2</source>
        <translation>信息哈希值 v2</translation>
    </message>
    <message>
        <source>Info Hash v1</source>
        <translation>信息哈希值 v1</translation>
    </message>
    <message>
        <source>Incomplete Save Path</source>
        <translation>保存路径不完整</translation>
    </message>
    <message>
        <source>Popularity</source>
        <translation>流行度</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>状态图标</translation>
    </message>
    <message>
        <source>Session Uploaded</source>
        <translation>会话已上传</translation>
    </message>
    <message>
        <source>Session Downloaded</source>
        <translation>会话已下载</translation>
    </message>
    <message>
        <source>Created On</source>
        <translation>创建于</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Peers</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>消息</translation>
    </message>
    <message>
        <source>Tracker URL:</source>
        <translation>Tracker URL：</translation>
    </message>
    <message>
        <source>Updating...</source>
        <translation>更新...</translation>
    </message>
    <message>
        <source>Working</source>
        <translation>工作</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>禁用</translation>
    </message>
    <message>
        <source>Not contacted yet</source>
        <translation>未联系</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Seeds</source>
        <translation>种子</translation>
    </message>
    <message>
        <source>Not working</source>
        <translation>未工作</translation>
    </message>
    <message>
        <source>Copy tracker URL</source>
        <translation>复制 tracker URL</translation>
    </message>
    <message>
        <source>Edit tracker URL...</source>
        <translation>编辑 tracker URL...</translation>
    </message>
    <message>
        <source>Tracker editing</source>
        <translation>编辑 Tracker</translation>
    </message>
    <message>
        <source>Leeches</source>
        <translation>下载</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>移除 tracker</translation>
    </message>
    <message>
        <source>Remaining</source>
        <translation>剩余</translation>
    </message>
    <message>
        <source>Availability</source>
        <translation>可用性</translation>
    </message>
    <message>
        <source>Tier</source>
        <translation>层级</translation>
    </message>
    <message>
        <source>Download Priority</source>
        <translation>下载优先级</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <source>Total Size</source>
        <translation>总大小</translation>
    </message>
    <message>
        <source>Times Downloaded</source>
        <translation>下载次数</translation>
    </message>
    <message>
        <source>Add trackers...</source>
        <translation>添加 Tracker...</translation>
    </message>
    <message>
        <source>Renamed</source>
        <translation>已重命名</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>原始</translation>
    </message>
    <message>
        <source>URL/Announce Endpoint</source>
        <translation>URL/Announce 端点</translation>
    </message>
    <message>
        <source>BT Protocol</source>
        <translation>BT 协议</translation>
    </message>
    <message>
        <source>Next Announce</source>
        <translation>下一个 Announce</translation>
    </message>
    <message>
        <source>Tier:</source>
        <translation>层级：</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Tracker 错误</translation>
    </message>
    <message>
        <source>Unreachable</source>
        <translation>无法连接</translation>
    </message>
    <message>
        <source>Force reannounce to selected tracker(s)</source>
        <translation>强制重新宣告所选中的 tracker 服务器</translation>
    </message>
    <message>
        <source>Min Announce</source>
        <translation>最小 Announce</translation>
    </message>
    <message>
        <source>Force reannounce to all trackers</source>
        <translation>强制向所有 Tracker 重新汇报</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <source>List of trackers to add (one per line):</source>
        <translation>要添加的 tracker 列表（每行一个）：</translation>
    </message>
    <message>
        <source>Add trackers</source>
        <translation>添加 Tracker</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 前</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>完成</translation>
    </message>
    <message>
        <source>Moving</source>
        <translation>移动中</translation>
    </message>
    <message>
        <source>[F] Seeding</source>
        <translation>[F] 做种</translation>
    </message>
    <message>
        <source>Seeding</source>
        <translation>做种</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>排队</translation>
    </message>
    <message>
        <source>Errored</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>[F] Downloading</source>
        <translation>[F] 下载</translation>
    </message>
    <message>
        <source>Downloading metadata</source>
        <translation>下载元数据</translation>
    </message>
    <message>
        <source>Checking</source>
        <translation>校验</translation>
    </message>
    <message>
        <source>Missing Files</source>
        <translation>丢失文件</translation>
    </message>
    <message>
        <source>Queued for checking</source>
        <translation>排队等待校验</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>下载</translation>
    </message>
    <message>
        <source>Checking resume data</source>
        <translation>校验恢复数据</translation>
    </message>
    <message>
        <source>Stalled</source>
        <translation>等待</translation>
    </message>
    <message>
        <source>%1 (seeded for %2)</source>
        <translation>%1 (已做种 %2)</translation>
    </message>
    <message>
        <source>[F] Downloading metadata</source>
        <translation>[F] 下载元数据</translation>
    </message>
    <message>
        <source>Stopped</source>
        <translation>已停止</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>分类</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Collapse/expand</source>
        <translation>折叠/展开</translation>
    </message>
    <message>
        <source>Collapse/expand category</source>
        <translation>折叠/展开分类</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <source>Torrent Download Speed Limiting</source>
        <translation>Torrent 下载速度限制</translation>
    </message>
    <message>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Torrent 上传速度限制</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <source>Limit share ratio...</source>
        <translation>限制分享率...</translation>
    </message>
    <message>
        <source>Limit upload rate...</source>
        <translation>限制上传速度...</translation>
    </message>
    <message>
        <source>Limit download rate...</source>
        <translation>限制下载速度...</translation>
    </message>
    <message>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>上移</translation>
    </message>
    <message>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>下移</translation>
    </message>
    <message>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>移至顶部</translation>
    </message>
    <message>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>移至底部</translation>
    </message>
    <message>
        <source>Set location...</source>
        <translation>更改保存位置...</translation>
    </message>
    <message>
        <source>Download first and last pieces first</source>
        <translation>先下载首尾文件块</translation>
    </message>
    <message>
        <source>Automatic Torrent Management</source>
        <translation>自动 Torrent 管理</translation>
    </message>
    <message>
        <source>Category</source>
        <translation>分类</translation>
    </message>
    <message>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>新分类...</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>重置</translation>
    </message>
    <message>
        <source>Force recheck</source>
        <translation>强制重新校验</translation>
    </message>
    <message>
        <source>Super seeding mode</source>
        <translation>超级做种模式</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>重命名...</translation>
    </message>
    <message>
        <source>Download in sequential order</source>
        <translation>按顺序下载</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>新分类</translation>
    </message>
    <message>
        <source>Set location</source>
        <translation>更改保存位置</translation>
    </message>
    <message>
        <source>Force reannounce</source>
        <translation>强制重新汇报</translation>
    </message>
    <message>
        <source>Edit Category</source>
        <translation>编辑分类</translation>
    </message>
    <message>
        <source>Comma-separated tags:</source>
        <translation>标签（以逗号分隔）：</translation>
    </message>
    <message>
        <source>Tags</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>磁力链接</translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation>删除全部</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>队列</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>添加...</translation>
    </message>
    <message>
        <source>Info hash v1</source>
        <translation>信息哈希值 v1</translation>
    </message>
    <message>
        <source>Info hash v2</source>
        <translation>信息哈希值 v2</translation>
    </message>
    <message>
        <source>Torrent ID</source>
        <translation>Torrent ID</translation>
    </message>
    <message>
        <source>Export .torrent</source>
        <translation>导出 .torrent</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Rename Files...</source>
        <translation>重命名文件...</translation>
    </message>
    <message>
        <source>Renaming</source>
        <translation>重命名</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>注释</translation>
    </message>
    <message>
        <source>Force Start</source>
        <translation>强制启动</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>路径：</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>自动模式表示不同的 torrent 的配置信息（例如保存路径）将由相关的分类决定</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>启动</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>新名称：</translation>
    </message>
    <message>
        <source>Add tags</source>
        <translation>添加标签</translation>
    </message>
    <message>
        <source>Content Path</source>
        <translation>内容路径</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Torrent 上传/下载率限制</translation>
    </message>
    <message>
        <source>Use global share limit</source>
        <translation>使用全局分享限制</translation>
    </message>
    <message>
        <source>Set no share limit</source>
        <translation>设置为无分享限制</translation>
    </message>
    <message>
        <source>Set share limit to</source>
        <translation>设置分享限制为</translation>
    </message>
    <message>
        <source>ratio</source>
        <translation>比率</translation>
    </message>
    <message>
        <source>total minutes</source>
        <translation>总分钟</translation>
    </message>
    <message>
        <source>inactive minutes</source>
        <translation>不活跃分钟</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>Remove torrent</source>
        <translation>删除 torrent</translation>
    </message>
    <message>
        <source>Remove torrent and its content</source>
        <translation>删除 torrent 及其内容</translation>
    </message>
    <message>
        <source>Stop torrent</source>
        <translation>停止 torrent</translation>
    </message>
    <message>
        <source>Enable super seeding for torrent</source>
        <translation>为 torrent 启用超级做种</translation>
    </message>
    <message>
        <source>Action when the limit is reached</source>
        <translation>达到限制时采取的操作</translation>
    </message>
</context>
<context>
    <name>about</name>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <source>Remove torrent(s)</source>
        <translation>移除 Torrent</translation>
    </message>
    <message>
        <source>Also remove the content files</source>
        <translation>同时删除已下载的文件</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>移除 tracker</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <source>Download from URLs</source>
        <translation>从 URL 下载</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1 小时 %2 分钟</translation>
    </message>
    <message>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1 天 %2 小时</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>未知</translation>
    </message>
    <message>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 分钟</translation>
    </message>
    <message>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 分钟</translation>
    </message>
    <message>
        <source>%1y %2d</source>
        <translation>%1 年 %2 天</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <source>Save path is empty</source>
        <translation>保存路径为空</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Plugin path:</source>
        <translation>插件路径：</translation>
    </message>
    <message>
        <source>URL or local directory</source>
        <translation>URL 或本地目录</translation>
    </message>
    <message>
        <source>Install plugin</source>
        <translation>安装插件</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SearchEngineWidget</name>
    <message>
        <source>Seeds:</source>
        <translation>种子：</translation>
    </message>
    <message>
        <source>All plugins</source>
        <translation>所有插件</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>大小：</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>Search plugins...</source>
        <translation>搜索插件...</translation>
    </message>
    <message>
        <source>All categories</source>
        <translation>所有分类</translation>
    </message>
    <message>
        <source>Search in:</source>
        <translation>在以下范围搜索：</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>过滤器</translation>
    </message>
    <message>
        <source>Torrent names only</source>
        <translation>仅 Torrent 名称</translation>
    </message>
    <message>
        <source>Only enabled</source>
        <translation>仅启用的</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>，总计</translation>
    </message>
    <message>
        <source>Everywhere</source>
        <translation>任意位置</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Increase window width to display additional filters</source>
        <translation>增加窗口宽度以显示其他过滤器</translation>
    </message>
    <message>
        <source>to</source>
        <translation>到</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>结果</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>显示</translation>
    </message>
    <message>
        <source>Click the "Search plugins..." button at the bottom right of the window to install some.</source>
        <translation>单击窗口底部右侧的“搜索插件...“按钮安装一些</translation>
    </message>
    <message>
        <source>There aren't any search plugins installed.</source>
        <translation>未安装任何搜索插件</translation>
    </message>
    <message>
        <source>Select category</source>
        <translation>选择分类</translation>
    </message>
    <message>
        <source>Min size prefix</source>
        <translation>最小文件体积</translation>
    </message>
    <message>
        <source>Start a search above.</source>
        <translation>在上方启动搜索。</translation>
    </message>
    <message>
        <source>Max size prefix</source>
        <translation>最大文件体积</translation>
    </message>
    <message>
        <source>Select plugins</source>
        <translation>选择插件</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <source>Uninstall</source>
        <translation>卸载</translation>
    </message>
    <message>
        <source>Install new plugin</source>
        <translation>安装新插件</translation>
    </message>
    <message>
        <source>You can get new search engine plugins here:</source>
        <translation>你可以在这里获取新的搜索引擎插件：</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>Installed search plugins:</source>
        <translation>已安装的搜索插件：</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>启用</translation>
    </message>
    <message>
        <source>Warning: Be sure to comply with your country's copyright laws when downloading torrents from any of these search engines.</source>
        <translation>警告：在下载来自这些搜索引擎的 torrent 时，请确认它符合您所在国家的版权法。</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>检查更新</translation>
    </message>
    <message>
        <source>Search plugins</source>
        <translation>搜索插件</translation>
    </message>
</context>
<context>
    <name>SearchResultsTable</name>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <source>Leechers</source>
        <translation>下载</translation>
    </message>
    <message>
        <source>Seeders</source>
        <translation>做种</translation>
    </message>
    <message>
        <source>Published On</source>
        <translation>发布于</translation>
    </message>
    <message>
        <source>Engine URL</source>
        <translation>引擎 URL</translation>
    </message>
    <message>
        <source>Engine</source>
        <translation>引擎</translation>
    </message>
</context>
<context>
    <name>SearchPluginsTable</name>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>启用</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>No</source>
        <translation>否</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Add Peers</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <source>List of peers to add (one IP per line):</source>
        <translation>要添加的用户列表（每行一个 IP）：</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>格式：IPv4:端口 / [IPv6]:端口</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <source>New Tag</source>
        <translation>新标签</translation>
    </message>
    <message>
        <source>Add tag...</source>
        <translation>添加标签...</translation>
    </message>
    <message>
        <source>Tag:</source>
        <translation>标签：</translation>
    </message>
    <message>
        <source>Remove unused tags</source>
        <translation>删除未使用的标签</translation>
    </message>
    <message>
        <source>Invalid tag name</source>
        <translation>无效标签名</translation>
    </message>
    <message>
        <source>Remove tag</source>
        <translation>删除标签</translation>
    </message>
    <message>
        <source>Remove torrents</source>
        <translation>移除 Torrent</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>启动 torrent</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>停止 torrent</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>Untagged</source>
        <translation>无标签</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Bug Tracker:</source>
        <translation>Bug 跟踪：</translation>
    </message>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>Forum:</source>
        <translation>论坛：</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>E-mail：</translation>
    </message>
    <message>
        <source>Current maintainer</source>
        <translation>目前的维护者</translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation>主页：</translation>
    </message>
    <message>
        <source>Greece</source>
        <translation>希腊</translation>
    </message>
    <message>
        <source>Special Thanks</source>
        <translation>致谢</translation>
    </message>
    <message>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>一个基于 Qt 工具箱和 libtorrent-rasterbar 并用 C++ 编写的高级 BitTorrent 客户端。</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>姓名：</translation>
    </message>
    <message>
        <source>About qBittorrent</source>
        <translation>关于 qBittorrent</translation>
    </message>
    <message>
        <source>License</source>
        <translation>许可证</translation>
    </message>
    <message>
        <source>Translators</source>
        <translation>译者</translation>
    </message>
    <message>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent 的构建使用了以下库：</translation>
    </message>
    <message>
        <source>Nationality:</source>
        <translation>国籍：</translation>
    </message>
    <message>
        <source>Software Used</source>
        <translation>使用的软件</translation>
    </message>
    <message>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>由 DB-IP 提供的免费 IP to Country Lite 数据库，用于解析对等节点所在的国家。该数据库已根据知识共享署名 4.0 国际许可协议获得许可</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>France</source>
        <translation>法国</translation>
    </message>
    <message>
        <source>qBittorrent Mascot</source>
        <translation>qBittorrent 吉祥物</translation>
    </message>
    <message>
        <source>qBittorrent icon</source>
        <translation>qBittorrent 图标</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>All addresses</source>
        <translation>所有地址</translation>
    </message>
    <message>
        <source>All IPv6 addresses</source>
        <translation>所有 IPv6 地址</translation>
    </message>
    <message>
        <source>All IPv4 addresses</source>
        <translation>所有 IPv4 地址</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>下载</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Description page URL</source>
        <translation>描述页 URL</translation>
    </message>
    <message>
        <source>Open description page</source>
        <translation>打开描述页</translation>
    </message>
    <message>
        <source>Download link</source>
        <translation>下载链接</translation>
    </message>
    <message>
        <source>Search has finished</source>
        <translation>搜索已完成</translation>
    </message>
    <message>
        <source>An error occurred during search...</source>
        <translation>搜索期间发生错误...</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>关闭标签</translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation>搜索...</translation>
    </message>
    <message>
        <source>Search aborted</source>
        <translation>搜索中止</translation>
    </message>
    <message>
        <source>Close all tabs</source>
        <translation>关闭所有标签</translation>
    </message>
    <message>
        <source>Refresh tab</source>
        <translation>刷新标签页</translation>
    </message>
    <message>
        <source>Open download window</source>
        <translation>打开下载窗口</translation>
    </message>
    <message>
        <source>Use as search text</source>
        <translation>用作搜索关键词</translation>
    </message>
    <message>
        <source>Stop search</source>
        <translation>停止搜索</translation>
    </message>
    <message>
        <source>Open shared download window</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate download windows</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <source>Renaming</source>
        <translation>重命名</translation>
    </message>
    <message>
        <source>New name:</source>
        <translation>新名称：</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <source>Date: </source>
        <translation>日期：</translation>
    </message>
    <message>
        <source>Please choose a new name for this RSS feed</source>
        <translation>请重命名该 RSS 订阅源</translation>
    </message>
    <message>
        <source>Please choose a folder name</source>
        <translation>请指定文件夹名</translation>
    </message>
    <message>
        <source>New feed name:</source>
        <translation>新订阅源名称：</translation>
    </message>
    <message>
        <source>Update all</source>
        <translation>更新所有</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>RSS Downloader...</source>
        <translation>RSS 下载器...</translation>
    </message>
    <message>
        <source>Mark items read</source>
        <translation>标记为已读</translation>
    </message>
    <message>
        <source>Update all feeds</source>
        <translation>更新所有订阅</translation>
    </message>
    <message>
        <source>Copy feed URL</source>
        <translation>复制订阅源 URL</translation>
    </message>
    <message>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrent：（双击下载）</translation>
    </message>
    <message>
        <source>Open news URL</source>
        <translation>打开新闻 URL</translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation>重命名...</translation>
    </message>
    <message>
        <source>Feed URL:</source>
        <translation>订阅源 URL：</translation>
    </message>
    <message>
        <source>New folder...</source>
        <translation>新建文件夹...</translation>
    </message>
    <message>
        <source>New subscription</source>
        <translation>新 RSS 订阅</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation>文件夹名：</translation>
    </message>
    <message>
        <source>Please type a RSS feed URL</source>
        <translation>请输入一个 RSS 订阅地址</translation>
    </message>
    <message>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>获取 RSS 订阅功能已被禁用！您可以在应用程序的设置中开启它。</translation>
    </message>
    <message>
        <source>Deletion confirmation</source>
        <translation>确认删除</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>您确定要删除所选的 RSS 订阅吗？</translation>
    </message>
    <message>
        <source>New subscription...</source>
        <translation>新建订阅...</translation>
    </message>
    <message>
        <source>Download torrent</source>
        <translation>下载 torrent</translation>
    </message>
    <message>
        <source>Edit feed URL...</source>
        <translation>编辑源 URL...</translation>
    </message>
    <message>
        <source>Unable to update URL</source>
        <translation>无法更新 URL</translation>
    </message>
    <message>
        <source>URL is unchanged</source>
        <translation>URL 未更改</translation>
    </message>
    <message>
        <source>URL cannot be empty</source>
        <translation>URL 不能为空</translation>
    </message>
    <message>
        <source>Open link</source>
        <translation>打开链接</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>作者：</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <source>Download Rules</source>
        <translation>下载规则</translation>
    </message>
    <message>
        <source>Matching RSS Articles</source>
        <translation>匹配 RSS 文章</translation>
    </message>
    <message>
        <source>* to match zero or more of any characters</source>
        <translation>* —— 匹配 0 个或多个任意字符</translation>
    </message>
    <message>
        <source> will match all articles.</source>
        <translation> 将匹配所有文章。</translation>
    </message>
    <message>
        <source>Episode filter rules: </source>
        <translation>剧集过滤器规则：</translation>
    </message>
    <message>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>自动下载 RSS torrent 功能已被禁用！您可以在应用程序的设置中开启它。</translation>
    </message>
    <message>
        <source>Rule Definition</source>
        <translation>规则定义</translation>
    </message>
    <message>
        <source>Save to:</source>
        <translation>保存到：</translation>
    </message>
    <message>
        <source>Use Regular Expressions</source>
        <translation>使用正则表达式</translation>
    </message>
    <message>
        <source>New rule name</source>
        <translation>新规则名称</translation>
    </message>
    <message>
        <source>Filter must end with semicolon</source>
        <translation>过滤规则必须以分号结束</translation>
    </message>
    <message>
        <source>? to match any single character</source>
        <translation>? —— 匹配任意单个字符</translation>
    </message>
    <message>
        <source>Matches articles based on episode filter.</source>
        <translation>使用剧集过滤器匹配文章。</translation>
    </message>
    <message>
        <source>Assign Category:</source>
        <translation>指定分类：</translation>
    </message>
    <message>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>正则模式：使用兼容 Perl 的正则表达式</translation>
    </message>
    <message>
        <source>| is used as OR operator</source>
        <translation>| —— "或" 运算符</translation>
    </message>
    <message>
        <source>Clear downloaded episodes</source>
        <translation>清空已下载剧集</translation>
    </message>
    <message>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>空格 —— "与" 运算符 (所有关键词，任意顺序)</translation>
    </message>
    <message>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <translation>将 %1 符号的一侧留空的表达式 (例如 %2)</translation>
    </message>
    <message>
        <source>Example: </source>
        <translation>示例：</translation>
    </message>
    <message>
        <source>Add new rule...</source>
        <translation>添加新规则...</translation>
    </message>
    <message>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>您确定要清空所选规则下的已下载剧集列表吗？</translation>
    </message>
    <message>
        <source>Must Contain:</source>
        <translation>必须包含：</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>无限范围：&lt;b&gt;1x25-;&lt;/b&gt; 匹配第 1 季的第 25 集及之后的集数，以及之后所有季度的集数</translation>
    </message>
    <message>
        <source>Save to a Different Directory</source>
        <translation>保存到其他目录</translation>
    </message>
    <message>
        <source>Must Not Contain:</source>
        <translation>必须不含：</translation>
    </message>
    <message>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>单个数字：&lt;b&gt;1x25;&lt;/b&gt; 匹配第 1 季的第 25 集</translation>
    </message>
    <message>
        <source>Three range types for episodes are supported: </source>
        <translation>支持 3 种集数范围写法：</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>您确定要删除所选的下载规则吗？</translation>
    </message>
    <message>
        <source>Use global settings</source>
        <translation>使用全局设定</translation>
    </message>
    <message>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>正常范围：&lt;b&gt;1x25-40;&lt;/b&gt; 匹配第 1 季的第 25 至 40 集</translation>
    </message>
    <message>
        <source>Please type the new rule name</source>
        <translation>请输入新的规则名称</translation>
    </message>
    <message>
        <source>Rule renaming</source>
        <translation>重命名规则</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>总是</translation>
    </message>
    <message>
        <source>Episode number is a mandatory positive value</source>
        <translation>集数必须是正数</translation>
    </message>
    <message>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <translation> 可匹配第 1 季的第 2 集、第 5 集、第 8 至 15 集、第 30 集及之后的集数</translation>
    </message>
    <message>
        <source>Rule deletion confirmation</source>
        <translation>删除规则时提示确认</translation>
    </message>
    <message>
        <source>Last Match: %1 days ago</source>
        <translation>上次匹配：%1 天前</translation>
    </message>
    <message>
        <source>Episode Filter:</source>
        <translation>剧集过滤器：</translation>
    </message>
    <message>
        <source>Rss Downloader</source>
        <translation>RSS 下载器</translation>
    </message>
    <message>
        <source>Season number is a mandatory non-zero value</source>
        <translation>季数必须是非零数</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>从不</translation>
    </message>
    <message>
        <source>Apply Rule to Feeds:</source>
        <translation>对以下订阅源应用规则：</translation>
    </message>
    <message>
        <source> days</source>
        <translation> 天</translation>
    </message>
    <message>
        <source>Use Smart Episode Filter</source>
        <translation>使用智能剧集过滤器</translation>
    </message>
    <message>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>如果要区分关键词顺序，请使用 * 替代空格。</translation>
    </message>
    <message>
        <source>Please type the name of the new download rule.</source>
        <translation>请输入新的下载规则的名称。</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use</source>
        <translation>通配符模式：您可以使用——</translation>
    </message>
    <message>
        <source> will exclude all articles.</source>
        <translation> 将排除所有文章。</translation>
    </message>
    <message>
        <source>Delete rule</source>
        <translation>删除规则</translation>
    </message>
    <message>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <translation>忽略指定时间后的匹配项（0 = 禁用）</translation>
    </message>
    <message>
        <source>Rename rule...</source>
        <translation>重命名规则...</translation>
    </message>
    <message>
        <source>Last Match: Unknown</source>
        <translation>上次匹配：未知</translation>
    </message>
    <message>
        <source>Clear downloaded episodes...</source>
        <translation>清空已下载剧集...</translation>
    </message>
    <message>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>智能剧集过滤器会检查剧集编号以避免重复下载。
支持格式：S01E01，1x1，2017.12.31，31.12.2017（日期格式也支持“-”分隔符）</translation>
    </message>
    <message>
        <source>Torrent content layout:</source>
        <translation>Torrent 内容布局：</translation>
    </message>
    <message>
        <source>Create subfolder</source>
        <translation>创建子文件夹</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>原始</translation>
    </message>
    <message>
        <source>Don't create subfolder</source>
        <translation>不创建子文件夹</translation>
    </message>
    <message>
        <source>Add Tags:</source>
        <translation>添加标签：</translation>
    </message>
    <message>
        <source>Remove rule</source>
        <translation>移除规则</translation>
    </message>
    <message>
        <source>Add rule</source>
        <translation>增加规则</translation>
    </message>
    <message>
        <source>Add Stopped:</source>
        <translation>添加已停止的：</translation>
    </message>
    <message>
        <source>Clear downloaded episodes confirmation</source>
        <translation>清除已下载剧集确认</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <source>Remove torrents</source>
        <translation>移除 Torrent</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>Trackerless</source>
        <translation>没有 Tracker</translation>
    </message>
    <message>
        <source>Start torrents</source>
        <translation>启动 torrent</translation>
    </message>
    <message>
        <source>Remove tracker</source>
        <translation>移除 tracker</translation>
    </message>
    <message>
        <source>Stop torrents</source>
        <translation>停止 torrent</translation>
    </message>
    <message>
        <source>Tracker error</source>
        <translation>Tracker 错误</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Other error</source>
        <translation>其他错误</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <source>RSS feeds</source>
        <translation>RSS 订阅列表</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>未读</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <source>General</source>
        <translation>普通</translation>
    </message>
    <message>
        <source>Blocked</source>
        <translation>被封禁</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>showing</source>
        <translation>显示</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>日志类型</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Information Messages</source>
        <translation>通知消息</translation>
    </message>
    <message>
        <source>Warning Messages</source>
        <translation>警告信息</translation>
    </message>
    <message>
        <source>Filter logs</source>
        <translation>过滤日志</translation>
    </message>
    <message>
        <source>Blocked IPs</source>
        <translation>被封禁的 IP</translation>
    </message>
    <message>
        <source>out of</source>
        <translation>中的</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Timestamp</source>
        <translation>时间戳</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>清除全部</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>消息</translation>
    </message>
    <message>
        <source>Log Levels:</source>
        <translation>日志级别：</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>理由</translation>
    </message>
    <message>
        <source>item</source>
        <translation>项目</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Banned</source>
        <translation>已封锁</translation>
    </message>
    <message>
        <source>Normal Messages</source>
        <translation>一般消息</translation>
    </message>
    <message>
        <source>Critical</source>
        <translation>关键</translation>
    </message>
    <message>
        <source>Critical Messages</source>
        <translation>严重信息</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>正常</translation>
    </message>
    <message>
        <source>items</source>
        <translation>项目</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>结果</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Choose a log level...</source>
        <translation>选择日志级别...</translation>
    </message>
</context>
<context>
    <name>TrackersFilterWidget</name>
    <message>
        <source>Are you sure you want to remove tracker %1 from all torrents?</source>
        <translation>你确定要从所有 Torrent 删除 Tracker "%1"吗？</translation>
    </message>
</context>
<context>
    <name>Category</name>
    <message>
        <source>Unable to edit category</source>
        <translation>无法编辑分类</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Unable to create category</source>
        <translation>无法创建分类</translation>
    </message>
    <message>
        <source>Unable to set category</source>
        <translation>无法设置分类</translation>
    </message>
    <message>
        <source>Save path for incomplete torrents:</source>
        <translation>保存不完整 Torrent 的路径：</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation>新分类</translation>
    </message>
    <message>
        <source>Save path:</source>
        <translation>保存路径：</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation>分类：</translation>
    </message>
    <message>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>路径：</translation>
    </message>
    <message>
        <source>Use another path for incomplete torrents:</source>
        <translation>对不完整的 Torrent 使用另一个路径：</translation>
    </message>
    <message>
        <source>Category does not exist</source>
        <translation>分类不存在</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Domain</source>
        <translation>域名</translation>
    </message>
    <message>
        <source>Manage Cookies</source>
        <translation>管理</translation>
    </message>
    <message>
        <source>Add Cookie</source>
        <translation>添加 Cookie</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Expiration Date</source>
        <translation>过期时间</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>路径</translation>
    </message>
</context>
<context>
    <name>confirmAutoTMMDialog</name>
    <message>
        <source>Enable automatic torrent management</source>
        <translation>启用自动 Torrent 管理</translation>
    </message>
    <message>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>你确定要为选定的 Torrent 启用自动 Torrent 管理吗？它们可能会被移动到新位置。</translation>
    </message>
</context>
<context>
    <name>confirmRecheckDialog</name>
    <message>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>您确定要重新校验所选的 Torrent 吗？</translation>
    </message>
    <message>
        <source>Recheck confirmation</source>
        <translation>确认重新校验</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>Close tab</source>
        <translation>关闭标签</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <source>qBittorrent WebUI</source>
        <translation>qBittorrent WebUI</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>JavaScript Required! You must enable JavaScript for the WebUI to work properly</source>
        <translation>JavaScript 是必需的！要让 WebUI 正确工作，你必须启用 JavaScript</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>登录</translation>
    </message>
    <message>
        <source>Server response:</source>
        <translation>服务器响应：</translation>
    </message>
    <message>
        <source>Unable to log in, server is probably unreachable.</source>
        <translation>登录失败，服务器可能无法访问。</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>用户名</translation>
    </message>
    <message>
        <source>Invalid Username or Password.</source>
        <translation>无效的用户名或密码。</translation>
    </message>
</context>
<context>
    <name>TorrentCreator</name>
    <message>
        <source>Private</source>
        <translation>私密</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>来源</translation>
    </message>
    <message>
        <source>Queued</source>
        <translation>排队</translation>
    </message>
    <message>
        <source>Unable to create torrent.</source>
        <translation>无法创建 Torrent。</translation>
    </message>
    <message>
        <source>Private
                torrent (Won't distribute on DHT network)</source>
        <translation>私有 torrent 文件（不会在 DHT 网络上分发）</translation>
    </message>
    <message>
        <source>Unable to export torrent file</source>
        <translation>无法导出 torrent 文件</translation>
    </message>
    <message>
        <source>Create New Torrent</source>
        <translation>制作新 Torrent</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>注释：</translation>
    </message>
    <message>
        <source>Download Torrent</source>
        <translation>下载 Torrent</translation>
    </message>
    <message>
        <source>Status Icon</source>
        <translation>状态图标</translation>
    </message>
    <message>
        <source>Web seed URLs:</source>
        <translation>Web 种子 URL：</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>失败了</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>注释</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>完成了</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Error Message</source>
        <translation>错误消息</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <source>Align to piece boundary for files larger
                than:</source>
        <translation>大于下列数值的文件启用文件块边界对齐：</translation>
    </message>
    <message>
        <source>Select file/folder to share:</source>
        <translation>选择要分享的文件/文件夹：</translation>
    </message>
    <message>
        <source>Piece Size</source>
        <translation>文件块大小</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <source>Completed On</source>
        <translation>完成于</translation>
    </message>
    <message>
        <source>Hybrid</source>
        <translation>混合</translation>
    </message>
    <message>
        <source>Unable to load torrent creation tasks</source>
        <translation>无法加载 Torrent 创建任务</translation>
    </message>
    <message>
        <source>Optimize
                    alignment</source>
        <translation>对齐优化</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Tracker URLs:</source>
        <translation>Tracker URL：</translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected tasks?</source>
        <translation>确定要删除所选任务吗？</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation>路径：</translation>
    </message>
    <message>
        <source>Create Torrent</source>
        <translation>制作 Torrent</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Started On</source>
        <translation>开始于</translation>
    </message>
    <message>
        <source>Web Seeds</source>
        <translation>Web Seeds</translation>
    </message>
    <message>
        <source>Start
                seeding
                immediately</source>
        <translation>立即开始做种</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>Torrent format:</source>
        <translation>Torrent 格式：</translation>
    </message>
    <message>
        <source>Source Path</source>
        <translation>源路径</translation>
    </message>
    <message>
        <source>Added On</source>
        <translation>添加于</translation>
    </message>
    <message>
        <source>Running</source>
        <translation>运行中</translation>
    </message>
    <message>
        <source>Torrent Creator</source>
        <translation>制作 Torrent</translation>
    </message>
    <message>
        <source>Source:</source>
        <translation>源：</translation>
    </message>
    <message>
        <source>Trackers</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <source>Piece size:</source>
        <translation>分块大小：</translation>
    </message>
    <message>
        <source>Fields</source>
        <translation>字段</translation>
    </message>
    <message>
        <source>Remove Task</source>
        <translation>删除任务</translation>
    </message>
    <message>
        <source>Export Torrent</source>
        <translation>导出 Torrent</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <source>Download</source>
        <translation type="vanished">下载</translation>
    </message>
    <message>
        <source>Magnet link</source>
        <translation>磁力链接</translation>
    </message>
    <message>
        <source>Add torrent links</source>
        <translation>添加 torrent 链接</translation>
    </message>
    <message>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>每行一个链接（支持 HTTP 链接，磁力链接和哈希值）</translation>
    </message>
    <message>
        <source>URLs</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Add Torrent Links</source>
        <translation>添加 Torrent 链接</translation>
    </message>
    <message>
        <source>Add Torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Add %1 torrents</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>All torrents will use a single options dialog. Check below to configure each one separately.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <source>Open separate dialog for each torrent</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>SpeedLimit</name>
    <message>
        <source>Limit:</source>
        <translation>限制：</translation>
    </message>
    <message>
        <source>Speed limit</source>
        <translation>速度限制</translation>
    </message>
    <message>
        <source>Upload limit:</source>
        <translation>上传限制：</translation>
    </message>
    <message>
        <source>Download limit:</source>
        <translation>下载限制：</translation>
    </message>
    <message>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>ListWidget</name>
    <message>
        <source>Resize All</source>
        <translation>调整所有项目的大小</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>调整大小</translation>
    </message>
</context>
<context>
    <name>confirmRotateAPIKeyDialog</name>
    <message>
        <source>Generate an API key? This key can be used to interact with qBittorrent's API.</source>
        <translation>生成 API key 吗？这枚 key 可用于和 qBittorrent 的 API 互动。</translation>
    </message>
    <message>
        <source>Delete this API key? The current key will immediately stop working.</source>
        <translation>删除此 API key 吗？当前 key 会立即停止工作。</translation>
    </message>
    <message>
        <source>Rotate this API key? The current key will immediately stop working and a new key will be generated.</source>
        <translation>重置该 API key 吗？当前 key 会立即停止工作，会生成新 key。</translation>
    </message>
</context>
</TS>